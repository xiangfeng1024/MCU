import sensor, image, time, math, pyb, lcd
from pyb import UART
from pyb import LED
usart3=UART(1,115200)
usart3.init(115200, bits=8, parity=None, stop=1)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((8,0,270,224))
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking
sensor.skip_frames(time = 2000)
#lcd.init()
clock = time.clock()

LED(3).on()

Mode=0
red =(91, 100, -6, 47, -11, 31)#(68, 100, 5, 46, -1, 18)
red2=(42, 73, 7, 65, -6, 36)
l =(76, 100, -30, 5, -4, 19)
la=(58, 76, -49, -22, 16, 37)

def UART_Out(Dian):
    data = bytearray([0xb3, 0xb3, int(Dian[0]), int(Dian[1]), int(Dian[2]), 0x5b])
    usart3.write(data)


while(True):
    clock.tick()
    flag=0
    img = sensor.snapshot().lens_corr(strength = 1.8)
    colormax=[]
    r_blobs = img.find_blobs([red], x_stride =2,y_stride =2,area_threshold =10,pixels_threshold =100 )
    if r_blobs:
        if r_blobs[0].roundness()>0.8:
            img.draw_rectangle(r_blobs[0].rect(),color =(255,0,0))
            print(r_blobs)
            colorxy=[r_blobs[0].cx(),r_blobs[0].cy(),0x02]
            flag=1
            UART_Out(colorxy)

    else:
        red2_blobs = img.find_blobs([red2], x_stride =2,y_stride =2,area_threshold =2,pixels_threshold =15)
        if red2_blobs:
            if red2_blobs[0].roundness()>0.75:
                img.draw_rectangle(red2_blobs[0].rect(),color =(255,0,0))
                print(red2_blobs)
                colorxy=[red2_blobs[0].cx(),red2_blobs[0].cy(),0x02]
                flag=1
                UART_Out(colorxy)
    if flag==0:
        colorxy=[0x01,0x01,0x05]
        UART_Out(colorxy)

    img.draw_string(0,0,"fps:%d"%(int(clock.fps())),color = (255, 255, 0), scale = 2)
    #lcd.display(img)
