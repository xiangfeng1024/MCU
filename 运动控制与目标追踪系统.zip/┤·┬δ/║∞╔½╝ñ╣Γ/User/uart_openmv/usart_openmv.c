#include "usart_openmv.h"

uint8_t RedCxInit,RedCyInit;
uint8_t JuXing[4][2];
uint8_t BianKuang[5][2];
uint8_t Task3_BianKuang[5][2];
uint8_t BuffSize=14;
uint8_t RedCx,RedCy;
uint8_t k_flag;
uint8_t Kuang;


static void USART2_Init(uint32_t a)
{
	GPIO_InitTypeDef GPIO_InitStructure;                           
	USART_InitTypeDef USART_InitStructure;                
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);     
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE); 
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;                
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;              
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;          
	GPIO_Init(GPIOA, &GPIO_InitStructure);      
	
	USART_InitStructure.USART_BaudRate = a;     
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;    
	USART_InitStructure.USART_StopBits = USART_StopBits_1;         
	USART_InitStructure.USART_Parity = USART_Parity_No ;           
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; 
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2, &USART_InitStructure);               
	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);	         	
	USART_Cmd(USART2, ENABLE);	                             
}

/*****************************************
�������ܣ�Openmv�Ĵ��ڳ�ʼ��
��ڲ�������
����  ֵ���� 
******************************************/
void Openmv_Init(void)
{
	USART2_Init(115200);
}

/******************************************
�������ܣ���Openmv���յ�Э������н���
��ڲ�����ԭʼЭ���
����  ֵ��0����������Э�������ȷ
					1��������ȷ����Ҫ���յ�����
*******************************************/
static int Openmv_data_parse(int *pack)
{
	if(pack[0] != 0xb3) 									return 0;
	if(pack[1] != 0xb3) 									return 0;
	if(pack[BuffSize-1] != 0x5b)  return 0;
	return 1;
}

/******************************************
�������ܣ�����2�ж�
��ڲ�����
����  ֵ���� 
����    ������Э���
*******************************************/
void USART2_IRQHandler(void)
{                                                                                     
	int a;
	static u8 i=0;
	static u8 dataFlag=0;
	static int Openmv_data_buff[13]={0};
	
	if(USART_GetITStatus(USART2,USART_IT_RXNE)!=RESET)	//�����ж�
	{
		USART_ClearFlag(USART2,USART_FLAG_TC);	//������������ ������
		a=USART_ReceiveData(USART2);	//��ȡ���յ�����Ϣ
		if(dataFlag==0 && a==0xb3) //�ж�֡ͷ
		{
			dataFlag=1;
			i=0;
		}
	
		if(dataFlag==1)  //���յ�֡ͷ����ʼ��������        
		{
			Openmv_data_buff[i]=a;
			if(i < (BuffSize-1) ) i++;
			else  //���ݽ����꣬��ʼУ��
			{
				dataFlag=0;
				i=0;
				if(Openmv_data_parse(Openmv_data_buff))  //У��ɹ�����Ҫ���յ�����
				{
					if(BuffSize==12)
					{
						Kuang=Openmv_data_buff[2];
						JuXing[0][0]=Openmv_data_buff[3];
						JuXing[0][1]=Openmv_data_buff[4];
						JuXing[1][0]=Openmv_data_buff[5];
						JuXing[1][1]=Openmv_data_buff[6];
						JuXing[2][0]=Openmv_data_buff[7];
						JuXing[2][1]=Openmv_data_buff[8];
						JuXing[3][0]=Openmv_data_buff[9];
						JuXing[3][1]=Openmv_data_buff[10];
					}
					else if(BuffSize==5)
					{
						RedCx=Openmv_data_buff[2];
						RedCy=Openmv_data_buff[3];
						k_flag=1;
					}
					else if(BuffSize==14)
					{
						if(Openmv_data_buff[12]==0x02)
						{
							BianKuang[0][0]=Openmv_data_buff[2];
							BianKuang[0][1]=Openmv_data_buff[3];
							BianKuang[1][0]=Openmv_data_buff[4];
							BianKuang[1][1]=Openmv_data_buff[5];
							BianKuang[2][0]=Openmv_data_buff[6];
							BianKuang[2][1]=Openmv_data_buff[7];
							BianKuang[3][0]=Openmv_data_buff[8];
							BianKuang[3][1]=Openmv_data_buff[9];
							BianKuang[4][0]=Openmv_data_buff[10];
							BianKuang[4][1]=Openmv_data_buff[11];
						}
						else if(Openmv_data_buff[12]==0x03)
						{
							Task3_BianKuang[0][0]=Openmv_data_buff[2];
							Task3_BianKuang[0][1]=Openmv_data_buff[3];
							Task3_BianKuang[1][0]=Openmv_data_buff[4];
							Task3_BianKuang[1][1]=Openmv_data_buff[5];
							Task3_BianKuang[2][0]=Openmv_data_buff[6];
							Task3_BianKuang[2][1]=Openmv_data_buff[7];
							Task3_BianKuang[3][0]=Openmv_data_buff[8];
							Task3_BianKuang[3][1]=Openmv_data_buff[9];
							Task3_BianKuang[4][0]=Openmv_data_buff[10];
							Task3_BianKuang[4][1]=Openmv_data_buff[11];
						}
					}
				}
			}
		}
	}
}

