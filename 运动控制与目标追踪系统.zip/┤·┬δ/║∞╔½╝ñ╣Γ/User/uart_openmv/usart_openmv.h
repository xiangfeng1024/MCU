#ifndef __USART_OPENMV_h
#define __USART_OPENMV_h

#include "system.h"

#define 	Openmv_DATA_SIZE  12
#define   OpenmvMode1Pick  {(USART_SendData(USART2,0x01));BuffSize=5;}
#define   OpenmvMode2Pick  {(USART_SendData(USART2,0x04));BuffSize=14;}
#define   OpenmvMode5Pick  {(USART_SendData(USART2,0x05));BuffSize=14;}
#define   OpenmvMode4Pick  {(USART_SendData(USART2,0x02));BuffSize=12;}

extern uint8_t Kuang;
extern uint8_t k_flag;
extern uint8_t RedCxInit,RedCyInit;
extern uint8_t RedCx,RedCy;
extern uint8_t BuffSize;
extern uint8_t JuXing[4][2];
extern uint8_t BianKuang[5][2];
extern uint8_t Task3_BianKuang[5][2];

void Openmv_Init(void);

#endif
