#ifndef _PID_H
#define _PID_H

#include "system.h"

extern struct PID Serx,Sery;

struct PID
{
	float kp;
	float ki;
	float kd;
	
	float err;
	float err_last;
	float err_last_dev;
	float err_last_dev_last;
	float err_last_dev_lastdev;
	float err_add;
	
	float ki_p;
	
	float out;
};

float Erect_pid(struct PID* para,float hope, float now);
void PID_Init(void);

#endif


