#include "pid.h"

struct PID Serx,Sery;

//λ��ʽPID����
void PID_Init(void)
{
	Serx.kp=0.075;
//	Serx.ki=0.1;
	
	Sery.kp=-0.075;
//	Sery.ki=-0.1;
}

//λ��ʽPID
float Erect_pid(struct PID* para,float hope, float now)
{
	(*para).err = now - hope;
	
	(*para).err_last_dev = (*para).err - (*para).err_last;
	
	(*para).out = (*para).kp*(*para).err + (*para).kd*(*para).err_last_dev + (*para).ki*(*para).err_add;
	
	(*para).err_last =  (*para).err;
	
	(*para).err_add+=(*para).err;
	
	return (*para).out;
}


