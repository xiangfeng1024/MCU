#ifndef _MOTORY_H
#define _MOTORY_H

#include "system.h"

#define SERVOS_X        1           	//X����
#define SERVOS_Y        2           	//Y����

#define SERVOS_XInit        3110           	//X����
#define SERVOS_YInit        2351           	//Y����

void PWM_Init_TIM8(uint16_t Psc,uint16_t arr);
u16 Fabs(int p);
void Servos_Write(u8 ID, u16 Out);
void Servos_Init(void);
void ServosLimit(float* PWMx, float* PWMy);

#endif



