#ifndef _LED_H
#define _LED_H

#include "system.h"

#define LED_RED        PAout(1)  
#define LED_BLUE     	 PCout(5)
#define LED_GREEN      PAout(5)

void LED_Init(void);

#endif


