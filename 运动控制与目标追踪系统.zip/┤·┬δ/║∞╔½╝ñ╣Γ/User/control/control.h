#ifndef _CONTROL_H
#define _CONTROL_H

#include "system.h"

#define QTX    3
#define QTY    4

#define QTLeft     1
#define QTRight    -1
#define QTUp       -1
#define QTDown     1


extern float CxPwmOut,CyPwmOut;
extern float TargetCxHope,TargetCyHope;

void Control_Init(void);
void TIM6_Init(u16 psc,u16 arr);
void TimeCrlSet(float PulseCntx, float PulseCnty, float TimeCnts);
void Task2(void);
void Task2_1(void);
void Task3(void);
void Task3_1(void);
void Task4(void);
void Task5(void);
void Control_Disable(void);
void Control_Enable(void);
void Gotoxy(uint8_t Cx, uint8_t Cy, uint16_t nms);
void QiTaWrite(uint8_t Mode, int Dir, double Timett);
void QiTaRes(void);
void Task5lv(void);
void Task0(void);
void Task00(void);


#endif


