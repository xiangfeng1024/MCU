#include "control.h"

float TargetCxHope=SERVOS_XInit,
			TargetCyHope=SERVOS_YInit;

float CxPwmOut=SERVOS_XInit,CyPwmOut=SERVOS_YInit;
float Time_t,TimeHope;
float CxHopePulse,CyHopePulse;

/**********************************************************************************************************
*�� �� ��: TIM6_Init
*����˵��: ��ʱ��ȡ�ٶȵ��ж϶�ʱ����ʼ��
*��    ��: psc��Ԥ��Ƶϵ��  arr������ֵ
*�� �� ֵ: ��
**********************************************************************************************************/
void TIM6_Init(u16 psc,u16 arr)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct; 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
	TIM_TimeBaseInitStruct.TIM_Period=arr;
	TIM_TimeBaseInitStruct.TIM_Prescaler=psc;	
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM6,&TIM_TimeBaseInitStruct);
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);

	TIM_Cmd(TIM6,ENABLE);
}

/**********************************************************************************************************
*�� �� ��: TimeCrlSet
*����˵��: д��������ջ�������
*��    ��: ������  ��ʱ��
*�� �� ֵ: ��
**********************************************************************************************************/
void TimeCrlSet(float PulseCntx, float PulseCnty, float TimeCnts)
{
	Time_t=0;
	CxHopePulse = PulseCntx;
	CxHopePulse = PulseCnty;
	TimeHope = TimeCnts*1000;
}

/**********************************************************************************************************
*�� �� ��: Control_Init
*����˵��: �����жϳ�ʼ��
*��    ��: ��
*�� �� ֵ: ��
**********************************************************************************************************/
void Control_Init(void)
{
	//��������10ms
	TIM6_Init(2000-1,360-1);
}

/**********************************************************************************************************
*�� �� ��: Control_Enable
*����˵��: ���ƿ���ʹ��
*��    ��: ��
*�� �� ֵ: ��
**********************************************************************************************************/
void Control_Enable(void)
{
	TIM_Cmd(TIM6,ENABLE);
}

/**********************************************************************************************************
*�� �� ��: Control_Disable
*����˵��: ���ƿ��ؽ�ֹ
*��    ��: ��
*�� �� ֵ: ��
**********************************************************************************************************/
void Control_Disable(void)
{
	TIM_Cmd(TIM6,DISABLE);
}

/**********************************************************************************************************
*�� �� ��: TIM6_IRQHandler
*����˵��: �����жϻص�����
*��    ��: ��
*�� �� ֵ: ��
**********************************************************************************************************/
void TIM6_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM6, TIM_IT_Update ); //��� TIM6 �����жϱ�־
		
		Erect_pid(&Serx,TargetCxHope,RedCx);
		Erect_pid(&Sery,TargetCyHope,RedCy);
		
		CxPwmOut+=Serx.out;
		CyPwmOut+=Sery.out;
		
		ServosLimit(&CxPwmOut, &CyPwmOut);
		
		Servos_Write(SERVOS_X,(int)CxPwmOut);
		Servos_Write(SERVOS_Y,(int)CyPwmOut);
	}
}

void Task0(void)
{
	int ll=0;
	OpenmvMode2Pick;
	delay_ms(200);
	while(KEY1)
	{
		delay_ms(30);
		if(KEY2==0)
		{
			delay_ms(100);
			while(!KEY2);
			OpenmvMode2Pick;
			OLED_Write(0,2,16,"cnt:%d",ll++);
			delay_ms(100);
		}
	}
}

void Task00(void)
{
	int ll=0;
	OpenmvMode5Pick;
	delay_ms(200);
	while(KEY1)
	{
		delay_ms(30);
		if(KEY2==0)
		{
			delay_ms(100);
			while(!KEY2);
			OpenmvMode2Pick;
			OLED_Write(0,2,16,"cnt:%d",ll++);
			delay_ms(100);
		}
	}
}


void Task2(void)
{
	uint16_t i=0,k=6;
	double Dx=0.0f,Dy=0.0f,
				 Cx=0.0f,Cy=0.0f,
		     Bx=0.0f,By=0.0f,
				 Ax=0.0f,Ay=0.0f;
	uint16_t t_ms=1;
	
	OpenmvMode1Pick;  //�л�ģʽѰ�Һ켤��
	RedCx=0;
	delay_ms(100);
	while(RedCx==0);
	RedCxInit=RedCx;
	RedCyInit=RedCy;
	
	Ax=BianKuang[0][0];
	Ay=BianKuang[0][1];
	Bx=BianKuang[3][0];
	By=BianKuang[3][1];
	Cx=BianKuang[2][0];
	Cy=BianKuang[2][1];
	Dx=BianKuang[1][0];
	Dy=BianKuang[1][1];
	
	TargetCxHope=Ax;
	TargetCyHope=Ay;
	
	Control_Init();
	
	
	Gotoxy(Ax, Ay, 100);
	
	
	for(i=0;i<k;i++)
	{
		Gotoxy(Ax+((Dx-Ax)/(double)k*i), Ay+((Dy-Ay)/(double)k*i), t_ms);
	}
//	delay_ms(500);
	for(i=0;i<k;i++)
	{
		Gotoxy(Dx+((Cx-Dx)/(double)k*i), Dy+((Cy-Dy)/(double)k*i), t_ms);
	}
//	delay_ms(500);
	for(i=0;i<k;i++)
	{
		Gotoxy(Cx+((Bx-Cx)/(double)k*i), Cy+((By-Cy)/(double)k*i), t_ms);
	}
//	delay_ms(500);
	for(i=0;i<k;i++)
	{
		
		Gotoxy(Bx+((Ax-Bx)/(double)k*i), By+((Ay-By)/(double)k*i), t_ms);
	}
//	delay_ms(500);
	Gotoxy(Ax, Ay, 10);
	
	
	while(1);
}

void Task3(void)
{
	uint16_t i=0,k=6;
	double Dx=0.0f,Dy=0.0f,
				 Cx=0.0f,Cy=0.0f,
		     Bx=0.0f,By=0.0f,
				 Ax=0.0f,Ay=0.0f;
	uint16_t t_ms=1;
	
	OpenmvMode1Pick;  //�л�ģʽѰ�Һ켤��
	RedCx=0;
	delay_ms(100);
	while(RedCx==0);
	RedCxInit=RedCx;
	RedCyInit=RedCy;
	
	Ax=Task3_BianKuang[0][0];
	Ay=Task3_BianKuang[0][1];
	Bx=Task3_BianKuang[3][0];
	By=Task3_BianKuang[3][1];
	Cx=Task3_BianKuang[2][0];
	Cy=Task3_BianKuang[2][1];
	Dx=Task3_BianKuang[1][0];
	Dy=Task3_BianKuang[1][1];
	
	TargetCxHope=Ax;
	TargetCyHope=Ay;
	
	Control_Init();
	
	
	Gotoxy(Ax, Ay, 100);
	
	
	for(i=0;i<k;i++)
	{
		Gotoxy(Ax+((Dx-Ax)/(double)k*i), Ay+((Dy-Ay)/(double)k*i), t_ms);
	}
	
	for(i=0;i<k;i++)
	{
		Gotoxy(Dx+((Cx-Dx)/(double)k*i), Dy+((Cy-Dy)/(double)k*i), t_ms);
	}
	
	for(i=0;i<k;i++)
	{
		Gotoxy(Cx+((Bx-Cx)/(double)k*i), Cy+((By-Cy)/(double)k*i), t_ms);
	}
	
	for(i=0;i<k;i++)
	{
		
		Gotoxy(Bx+((Ax-Bx)/(double)k*i), By+((Ay-By)/(double)k*i), t_ms);
	}

	Gotoxy(Ax, Ay, 10);
	
	
	while(1);
}


void Task4(void)
{
	// C B A D
	int x1=0;
	uint16_t i=0,k=6;
	double Dx=0.0f,Dy=0.0f,
				 Cx=0.0f,Cy=0.0f,
		     Bx=0.0f,By=0.0f,
				 Ax=0.0f,Ay=0.0f;
	uint16_t t_ms=1;
	
	OpenmvMode4Pick;  //Ѱ�Ҿ���
	JuXing[0][0]=0;
	OLED_Write(0,0,16,"Ju Xing ing...");
	delay_ms(200);
	while(KEY2);
	OLED_Write(0,0,16,"OK            ");
	RedCx=0;
	OpenmvMode1Pick;  //�л�ģʽѰ�Һ켤��
	
	while(RedCx==0);
	
	RedCxInit=RedCx;
	RedCyInit=RedCy;
	
	if(Kuang==1) 			x1=7;  //���
	else if(Kuang==2) x1=-5;
	
	if(JuXing[0][1]>JuXing[1][1] && JuXing[0][1]>JuXing[2][1] && JuXing[0][1]>JuXing[3][1])
	{
		Ax=JuXing[0][0];
		Ay=JuXing[0][1]-x1;
		Bx=JuXing[1][0]-x1;
		By=JuXing[1][1];
		Cx=JuXing[2][0];
		Cy=JuXing[2][1]+x1-3;
		Dx=JuXing[3][0]+x1;
		Dy=JuXing[3][1];
	}
	else
	{
		Ax=JuXing[0][0]+x1;
		Ay=JuXing[0][1];
		Bx=JuXing[1][0];
		By=JuXing[1][1]-x1;
		Cx=JuXing[2][0]-x1;
		Cy=JuXing[2][1];
		Dx=JuXing[3][0];
		Dy=JuXing[3][1]+x1-3;
	}
	TargetCxHope=Ax;
	TargetCyHope=Ay;
	
	Control_Init();
	
	
	Gotoxy(Ax, Ay, 100);
	
	
	for(i=0;i<k;i++)
	{
		Gotoxy(Ax+((Dx-Ax)/(double)k*i), Ay+((Dy-Ay)/(double)k*i), t_ms);
	}
	
	for(i=0;i<k;i++)
	{
		Gotoxy(Dx+((Cx-Dx)/(double)k*i), Dy+((Cy-Dy)/(double)k*i), t_ms);
	}
	
	for(i=0;i<k;i++)
	{
		Gotoxy(Cx+((Bx-Cx)/(double)k*i), Cy+((By-Cy)/(double)k*i), t_ms);
	}
	
	for(i=0;i<k;i++)
	{
		
		Gotoxy(Bx+((Ax-Bx)/(double)k*i), By+((Ay-By)/(double)k*i), t_ms);
	}

	Gotoxy(Ax, Ay, 10);
	
	
	while(1);
}

double pppxx=0.0f,pppyy=0.0f;
double PwmUpxx=0.0f,PwmUpyy=0.0f;
float Time=0.0,Time_t;
double ShuZiTiaoSizeZ=120.0f;


void Task5(void)
{
	uint16_t i=0,n;
	double Time=0.0f,Time_t=0.0f;
	
	QiTaRes();
	delay_ms(1000);
	
	Time=150.0f;
	n=6;
	Time_t=Time/n;
	QiTaWrite(QTX,QTRight,Time_t);   //3
	QiTaWrite(QTY,QTDown,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	QiTaWrite(QTX,QTRight,Time_t);
	QiTaWrite(QTY,QTDown,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	delay_ms(850);
	
	QiTaWrite(QTX,QTRight,Time_t);
	QiTaWrite(QTY,QTUp,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	QiTaWrite(QTX,QTRight,Time_t);
	QiTaWrite(QTY,QTUp,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	QiTaRes();
	delay_ms(850);
	
	n=5;
	Time_t=Time/n;
	for(i=0;i<5;i++)
	{
		QiTaWrite(QTX,QTRight,Time_t);   //2
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		delay_ms(850);
		
		QiTaWrite(QTX,QTLeft,Time_t);   //2
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaRes();
		delay_ms(850);
	}
	
	n=2;
	Time_t=Time/n;
	for(i=0;i<5;i++)
	{
		QiTaWrite(QTY,QTDown,Time_t);   //1
		QiTaWrite(QTY,QTDown,Time_t);
		delay_ms(850);
		
		QiTaWrite(QTY,QTUp,Time_t);     //1
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaRes();
		delay_ms(850);
	}
	
	n=6;
	Time_t=Time/n;
	for(i=0;i<10;i++)
	{
		QiTaWrite(QTY,QTDown,Time_t);   //0
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaRes();
		delay_ms(850);
	}
	while(1);
}

void Task5lv(void)
{
	uint16_t i=0,n;
	double Time=0.0f,Time_t=0.0f;
	
	QiTaRes();
	delay_ms(1000);
	
	Time=150.0f;
	n=2;
	Time_t=Time/n;
	QiTaWrite(QTY,QTDown,Time_t);   //1
	QiTaWrite(QTY,QTDown,Time_t);
	delay_ms(850);
	
	n=6;
	Time_t=Time/n;
	QiTaWrite(QTX,QTRight,Time_t);  //0
	QiTaWrite(QTY,QTUp,Time_t);
	QiTaWrite(QTY,QTUp,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	QiTaWrite(QTY,QTDown,Time_t);
	QiTaWrite(QTY,QTDown,Time_t);
	delay_ms(850);
	

	for(i=0;i<3;i++)
	{
		if(i==2) {LED_RED=0;LED_GREEN=0;}
		n=7;
		Time_t=Time/n;
		QiTaWrite(QTX,QTRight,Time_t);  //9
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		delay_ms(850);
		
		n=11;
		Time_t=Time/n;
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);   //8
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaRes();
		delay_ms(850);
		QiTaRes();
		
		n=3;
		Time_t=Time/n;
		QiTaWrite(QTX,QTRight,Time_t);  //7
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		delay_ms(650);
		QiTaRes();
		delay_ms(200);
		
		n=5;
		Time_t=Time/n;
		QiTaWrite(QTY,QTDown,Time_t); //6
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		delay_ms(750);
		QiTaWrite(QTY,QTDown,Time_t);
		delay_ms(100);
		
		if(i==2) LED_GREEN=1;
		n=5;
		Time_t=Time/n;
		QiTaWrite(QTX,QTRight,Time_t); //5
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		delay_ms(750);
		QiTaRes();
		delay_ms(100);
		
		
		n=5;
		Time_t=Time/n;
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t); //4
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		delay_ms(650);
		QiTaWrite(QTX,QTLeft,Time_t);
		delay_ms(200);
		
		n=6;
		Time_t=Time/n;
		QiTaWrite(QTX,QTRight,Time_t);  //3
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaRes();
		delay_ms(850);
		
		n=5;
		Time_t=Time/n;
		QiTaWrite(QTX,QTRight,Time_t);   //2
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		delay_ms(850);
		
		n=2;
		Time_t=Time/n;
		QiTaWrite(QTY,QTUp,Time_t);     //1
		QiTaWrite(QTY,QTUp,Time_t);
		delay_ms(850);
		
		n=9;
		Time_t=Time/n;
		QiTaWrite(QTX,QTLeft,Time_t);  //0
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
	//		QiTaRes();
		delay_ms(850);
	}
	while(1);
}

void QiTaRes(void)
{
	pppxx=-10.0f;
	pppyy=-180.0f;
	TIM_SetCompare1(TIM8,(int)(SERVOS_XInit+pppxx));
	TIM_SetCompare2(TIM8,(int)(SERVOS_YInit+pppyy));
}

void QiTaWrite(uint8_t Mode, int Dir, double Timett)
{
	uint16_t i;
	if(Mode==QTX) 
	{
		PwmUpxx=(double)(Dir*ShuZiTiaoSizeZ) / Timett;
		PwmUpyy=0;
	}
	else if(Mode==QTY)
	{
		PwmUpxx=0;
		PwmUpyy=(double)(Dir*ShuZiTiaoSizeZ) / Timett;
	}

	for(i=0;i<Timett;i++)
	{
		TIM_SetCompare1(TIM8,(int)(SERVOS_XInit+pppxx));
		TIM_SetCompare2(TIM8,(int)(SERVOS_YInit+pppyy));
		pppxx+=PwmUpxx;
		pppyy+=PwmUpyy;
		delay_ms(1);
	}
}

void Gotoxy(uint8_t Cx, uint8_t Cy, uint16_t nms)
{
	TargetCxHope=Cx;
	TargetCyHope=Cy;
	LED_BLUE=1;
	Control_Enable();
	while(1)
	{
		if(RedCx >= (TargetCxHope-2) && RedCx <= (TargetCxHope+2))
		{
			if(RedCy >= (TargetCyHope-2) && RedCy <= (TargetCyHope+2)) break;
		}
	}
	Control_Disable();   //�رտ�����
	LED_BLUE=0;
//	delay_ms(nms);
}


