/*********************************************************************************
*��		 ��: E:�˶�Ŀ��������Զ�׷��ϵͳ
*�� �� ��: zs
*����ʱ��: 2023.8.3
**********************************************************************************/
#include "system.h"

int main(void)
{
	SysTick_Init(72);          //�δ��ʱ����ʼ��
	NVIC_Config();
	KEY_GPIO_Init();
//	EXTIX_Init();
	LED_Init();
	OLED_Init();
	Servos_Init();
	AT24C02_Init();
 	Openmv_Init();
	PID_Init();
//	BeepOn();
//	while(KEY3);
	
	
	OLED_Write(0,0,16,"ok");
	
	ServosSaoMiao();
	Control_Init();
	
	while(1)
	{
		if(YuanData[1][0]>=Greenx-5 && YuanData[1][0]<=Greenx+5)
		{
			if(YuanData[1][1]>=Greeny-5 && YuanData[1][1]<=Greeny+5) 
			{
				if(beep==1)
				{
					BeepOn();
					LED_GREEN=0;
				}
			  else 
				{
					BeepOff();
					LED_GREEN=1;
				}
			}
			else 
			{
				BeepOff();
				LED_GREEN=1;
			}
		}
		else
		{
			BeepOff();
			LED_GREEN=1;
		}
	}
}

