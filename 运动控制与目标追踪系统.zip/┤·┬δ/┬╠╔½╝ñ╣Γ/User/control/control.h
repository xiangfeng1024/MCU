#ifndef _CONTROL_H
#define _CONTROL_H

#include "system.h"

extern float CxPwmOut,CyPwmOut;

#define QTX    3
#define QTY    4

#define QTLeft     1
#define QTRight    -1
#define QTUp       1
#define QTDown     -1


void Control_Init(void);
void TIM6_Init(u16 psc,u16 arr);
void TimeCrlSet(float PulseCntx, float PulseCnty, float TimeCnts);
void QiTaWrite(uint8_t Mode, int Dir, double Timett);
void Task5(void);


#endif


