#include "control.h"

float TargetCxHope=SERVOS_XInit,
			TargetCyHope=SERVOS_YInit;

float CxPwmOut=SERVOS_XInit,CyPwmOut=SERVOS_YInit;
float Time_t,TimeHope;
float CxHopePulse,CyHopePulse;

/**********************************************************************************************************
*�� �� ��: TIM6_Init
*����˵��: ��ʱ��ȡ�ٶȵ��ж϶�ʱ����ʼ��
*��    ��: psc��Ԥ��Ƶϵ��  arr������ֵ
*�� �� ֵ: ��
**********************************************************************************************************/
void TIM6_Init(u16 psc,u16 arr)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct; 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
	TIM_TimeBaseInitStruct.TIM_Period=arr;
	TIM_TimeBaseInitStruct.TIM_Prescaler=psc;	
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM6,&TIM_TimeBaseInitStruct);
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);

	TIM_Cmd(TIM6,ENABLE);
}

/**********************************************************************************************************
*�� �� ��: Control_Init
*����˵��: �����жϳ�ʼ��
*��    ��: ����ʱ��
*�� �� ֵ: ��
**********************************************************************************************************/
void Control_Init(void)
{
	//��������10ms
	TIM6_Init(2000-1,360-1);
//	YuanData[1][0]=0;
//	YuanData[1][1]=0;
//	k_flag=0;
}

float ABComp(float a)
{
	if(a>0) return 1; 
	if(a<0) return -1; 
	return 0;	
}


/**********************************************************************************************************
*�� �� ��: TIM6_IRQHandler
*����˵��: �����жϻص�����
*��    ��: ��
*�� �� ֵ: ��
**********************************************************************************************************/
void TIM6_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM6, TIM_IT_Update ); //��� TIM6 �����жϱ�־
		
//		if(k_flag!=0)
//		{
		if(beep==1)
		{
		Erect_pid(&Serx,YuanData[1][0],Greenx);
		Erect_pid(&Sery,YuanData[1][1],Greeny);
		
		CxPwmOut+=Serx.out;
		CyPwmOut+=Sery.out;
		
		ServosLimit(&CxPwmOut, &CyPwmOut);
		
		Servos_Write(SERVOS_X,(int)CxPwmOut);
		Servos_Write(SERVOS_Y,(int)CyPwmOut);
		}
//			if(kk++==30) {k_flag=0;kk=0;}
//			k_flag=0;
//		}
		
//		else
//		{
//			
//			CxPwmOut+=0.07f*ABComp(Serx.out);
//			CyPwmOut+=0.03f*ABComp(Sery.out);
//			
//			ServosLimit(&CxPwmOut, &CyPwmOut);
//			
//			Servos_Write(SERVOS_X,(int)CxPwmOut);
//			Servos_Write(SERVOS_Y,(int)CyPwmOut);
//		}
	}
}

double pppxx=0.0f,pppyy=0.0f;
double PwmUpxx=0.0f,PwmUpyy=0.0f;
float Time=0.0,Time_t;
double ShuZiTiaoSizeZ=120.0f;

void Task5(void)
{
	uint16_t i=0,n;
	double Time=0.0f,Time_t=0.0f;
	
	QiTaRes();
	delay_ms(1000);
	
	Time=150.0f;
	n=6;
	Time_t=Time/n;
	QiTaWrite(QTX,QTRight,Time_t);   //3
	QiTaWrite(QTY,QTDown,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	QiTaWrite(QTX,QTRight,Time_t);
	QiTaWrite(QTY,QTDown,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	delay_ms(850);
	
	QiTaWrite(QTX,QTRight,Time_t);
	QiTaWrite(QTY,QTUp,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	QiTaWrite(QTX,QTRight,Time_t);
	QiTaWrite(QTY,QTUp,Time_t);
	QiTaWrite(QTX,QTLeft,Time_t);
	QiTaRes();
	delay_ms(850);
	
	n=5;
	Time_t=Time/n;
	for(i=0;i<5;i++)
	{
		QiTaWrite(QTX,QTRight,Time_t);   //2
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		delay_ms(850);
		
		QiTaWrite(QTX,QTLeft,Time_t);   //2
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaRes();
		delay_ms(850);
	}
	
	n=2;
	Time_t=Time/n;
	for(i=0;i<5;i++)
	{
		QiTaWrite(QTY,QTDown,Time_t);   //1
		QiTaWrite(QTY,QTDown,Time_t);
		delay_ms(850);
		
		QiTaWrite(QTY,QTUp,Time_t);     //1
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaRes();
		delay_ms(850);
	}
	
	LED_RED=0;LED_GREEN=0;
	n=6;
	Time_t=Time/n;
	for(i=0;i<10;i++)
	{
		if(i==5) {LED_GREEN=1;BeepOn();}
		QiTaWrite(QTY,QTDown,Time_t);   //0
		QiTaWrite(QTY,QTDown,Time_t);
		QiTaWrite(QTX,QTRight,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTY,QTUp,Time_t);
		QiTaWrite(QTX,QTLeft,Time_t);
		QiTaRes();
		delay_ms(850);
	}
	while(1)
	{
		BeepOn();
		delay_ms(200);
		BeepOff();
		delay_ms(200);
	}
}

void QiTaRes(void)
{
	pppxx=0.0f;
	pppyy=180.0f;
	TIM_SetCompare1(TIM8,(int)(SERVOS_XInit+pppxx));
	TIM_SetCompare2(TIM8,(int)(SERVOS_YInit+pppyy));
}

void QiTaWrite(uint8_t Mode, int Dir, double Timett)
{
	uint16_t i;
	if(Mode==QTX) 
	{
		PwmUpxx=(double)(Dir*ShuZiTiaoSizeZ) / Timett;
		PwmUpyy=0;
	}
	else if(Mode==QTY)
	{
		PwmUpxx=0;
		PwmUpyy=(double)(Dir*ShuZiTiaoSizeZ) / Timett;
	}

	for(i=0;i<Timett;i++)
	{
		TIM_SetCompare1(TIM8,(int)(SERVOS_XInit+pppxx));
		TIM_SetCompare2(TIM8,(int)(SERVOS_YInit+pppyy));
		pppxx+=PwmUpxx;
		pppyy+=PwmUpyy;
		delay_ms(1);
	}
}

