#include "motor1.h"

double SaoMiaoPwmx=0;

void PWM_Init_TIM8(uint16_t Psc,uint16_t arr)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8,ENABLE);
	TIM_TimeBaseStructure.TIM_Period=arr;// ARR
	TIM_TimeBaseStructure.TIM_Prescaler= Psc;// PSC��Ƶ
	TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM8, &TIM_TimeBaseStructure);// ��ʼ����ʱ��
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;// ����ΪPWMģʽ1
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;// ���ʹ��	
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;// ���ͨ����ƽ�������ã��ߵ�ƽ��Ч
	TIM_OCInitStructure.TIM_Pulse = 0; 
	TIM_OC1Init(TIM8, &TIM_OCInitStructure);

	TIM_OC2Init(TIM8, &TIM_OCInitStructure);

//	TIM_OC3Init(TIM8, &TIM_OCInitStructure);


//	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;// ����ΪPWMģʽ1
//	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;// ���ʹ��	
//	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;// ���ͨ����ƽ�������ã��ߵ�ƽ��Ч
//	TIM_OC4Init(TIM8, &TIM_OCInitStructure);

	TIM_CtrlPWMOutputs(TIM8,ENABLE);

	TIM_OC1PreloadConfig(TIM8,TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM8,TIM_OCPreload_Enable);
//	TIM_OC3PreloadConfig(TIM8,TIM_OCPreload_Enable);
//	TIM_OC4PreloadConfig(TIM8,TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM8,ENABLE);
	
	TIM_Cmd(TIM8,ENABLE);
}

/**********************************************************************************************************
*�� �� ��: Servos_Init
*����˵��: ����ӿڳ�ʼ��
*��    ��: ��
*�� �� ֵ: ��
**********************************************************************************************************/
void Servos_Init(void)
{
	PWM_Init_TIM8(36-1,40000-1);
	TIM_SetCompare1(TIM8,SERVOS_XInit);   //С��  ����
	TIM_SetCompare2(TIM8,SERVOS_YInit);   //С��  ����
}

void ServosSaoMiao(void)
{
	uint16_t i=0,kk=0,a=0;
	double pppx=0.0f;//pppy=0.0f;
	double PwmUpx=0.0f;
	float time_t=1200.0f;
	
	while(KEY1 & KEY2 * KEY3);
	if(KEY1==0) kk=1;
	if(KEY2==0) kk=2;
	if(KEY3==0) Task5();
	
	//���
	if(kk==1)
	{
		PwmUpx=(-500.0f)/time_t;
		YuanData[1][0]=0;
		for(i=0;i<time_t;i++)
		{
			TIM_SetCompare1(TIM8,(int)(SERVOS_XInit+pppx));
			pppx+=PwmUpx;
			delay_ms(1); 
			if(YuanData[1][0]!=0)
			{
				if(a++>=300) break;
			}
		}
		CxPwmOut=SERVOS_XInit+pppx;
	}
	
	//�ұ�
	else
	{
		PwmUpx=(500.0f)/time_t;
		YuanData[1][0]=0;
		for(i=0;i<time_t;i++)
		{
			TIM_SetCompare1(TIM8,(int)(SERVOS_XInit+pppx));
			pppx+=PwmUpx;
			delay_ms(1);
			if(YuanData[1][0]!=0)
			{
				if(a++>=300) break;
			}
		}
		CxPwmOut=SERVOS_XInit+pppx;
	}
	
	EXTIX_Init();
}

/**********************************************************************************************************
*�� �� ��: Servos_Write
*����˵��: ���ص����
*��    ��: ID: �����  Out�����ֵ
*�� �� ֵ: ��
**********************************************************************************************************/
void Servos_Write(u8 ID, u16 Out)
{
	if(ID == SERVOS_X) 			TIM_SetCompare1(TIM8,Out);  //��  ��
	else if(ID == SERVOS_Y) TIM_SetCompare2(TIM8,Out);  //��  ��
}

/**********************************************************************************************************
*�� �� ��: Fabs
*����˵��: ����ֵ���
*��    ��: ��Ҫת������
*�� �� ֵ: ת�������
**********************************************************************************************************/
u16 Fabs(int p)
{
	u16 q;
	q = p>=0?p:(-p);
	return q;
}

void ServosLimit(float* PWMx, float* PWMy)
{
	if((*PWMx)>=4800) (*PWMx)=4800;
	if((*PWMx)<=1000) (*PWMx)=1000;
	if((*PWMy)>=2700) (*PWMy)=2700;
	if((*PWMy)<=1000) (*PWMy)=1000;
}


