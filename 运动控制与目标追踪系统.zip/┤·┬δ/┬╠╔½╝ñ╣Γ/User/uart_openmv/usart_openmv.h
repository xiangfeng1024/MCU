#ifndef __USART_OPENMV_h
#define __USART_OPENMV_h

#include "system.h"

#define 	Openmv_DATA_SIZE  6

extern uint8_t k_flag;
extern uint8_t YuanData[2][2];
extern uint8_t OpenmvData;
extern uint8_t CoEn;
extern uint8_t Greenx,Greeny;
extern uint8_t beep;

void Openmv_Init(void);

#endif
