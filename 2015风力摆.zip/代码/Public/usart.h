#ifndef _USART_H
#define _USART_H

#include "system.h" 
#include "stdio.h" 

//void USART1_Init(u32 bound);
//void USART2_Init(u32 bound);
//void USART3_Init(u32 bound);
//void USART4_Init(u32 bound);
//void USART5_Init(u32 bound);


#endif


