#ifndef _RGB_H
#define _RGB_H

#include "system.h"

#define R_LED_ON  {GPIOA->CRL &= 0xffffff0f;GPIOA->CRL |= (0x03U<<4);}
#define R_LED_OFF {GPIOA->CRL &= 0xffffff0f;GPIOA->CRL |= (0x04U<<4);}

#define G_LED_ON  {GPIOA->CRL &= 0xff0fffff;GPIOA->CRL |= (0x03U<<20);}
#define G_LED_OFF {GPIOA->CRL &= 0xff0fffff;GPIOA->CRL |= (0x04U<<20);}

#define B_LED_ON  {GPIOC->CRL &= 0xff0fffff;GPIOC->CRL |= (0x03U<<20);}
#define B_LED_OFF {GPIOC->CRL &= 0xff0fffff;GPIOC->CRL |= (0x04U<<20);}

void RGB_Init(void);


#endif


