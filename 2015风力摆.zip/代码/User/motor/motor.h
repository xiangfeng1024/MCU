#ifndef _MOTOR_H
#define _MOTOR_H

#include "system.h"
  

void PWM_Init_TIM8(uint16_t Psc,uint16_t arr);
void Motor_Init(void);
int Fabs(int p);
void Limit(int *PWMA,int *PWMB,int *PWMC,int *PWMD);
void Motor_Write(int PWMA, int PWMB, int PWMC, int PWMD);
void Motor_Open(int Mode,int distance_hope,int dir);
void Limit_d(int *PWMA);

#endif


