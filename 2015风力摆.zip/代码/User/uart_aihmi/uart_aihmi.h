#ifndef _UART_AIHMI_H
#define _UART_AIHMI_H

#include "system.h"  

#define AIHMI_DATA_SIZE  8


void AIHMI_Init(void);
//void USART2_Init(uint32_t a);

#endif

