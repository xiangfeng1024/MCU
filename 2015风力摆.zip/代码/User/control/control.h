#ifndef _CONTROL_H
#define _CONTROL_H

#include "system.h"

#define Poll_0   1.7
#define Pitch_0  0.1

extern int Roll_1_out,Roll_2_out,Pitch_1_out,Pitch_2_out;
extern int tt1,tt2,tt3,tt4;


void TIM5_Init(u16 psc,u16 arr);
void Control_Init(void);

#endif

