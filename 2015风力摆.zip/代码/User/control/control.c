#include "control.h"

int Roll_1_out=0,Roll_2_out=0,Pitch_1_out=0,Pitch_2_out=0;
int tt1,tt2,tt3,tt4;

//�����ж�
void TIM5_Init(u16 psc,u16 arr)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct; 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
	TIM_TimeBaseInitStruct.TIM_Period=arr;
	TIM_TimeBaseInitStruct.TIM_Prescaler=psc;	
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM5,&TIM_TimeBaseInitStruct);
	TIM_ClearITPendingBit(TIM5,TIM_IT_Update);
	TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE);

	TIM_Cmd(TIM5,ENABLE);
}

void Control_Init(void)
{
	//�����ж�5ms
	TIM5_Init(5000-1,72-1);
}

void TIM5_IRQHandler(void)
{
	int pwm1_out,pwm2_out,pwm3_out,pwm4_out;
	int out1=0,out2=0,out3=0,out4=0;
	if(TIM_GetITStatus(TIM5, TIM_IT_Update) != RESET) //��� TIM1�����жϷ������
	{
		
		//����һ
//		Roll_1_out = Erect_pid(&Roll_Ang, 8-IMU_Roll, IMU_Gyrox);
//		Roll_2_out = -Roll_1_out;
//		Limit_d(&Roll_1_out);
//		Limit_d(&Roll_2_out);
//		pwm1_out = Erect_pid(&Gyrox, IMU_Gyrox, 0);
//		out1 = Roll_1_out+pwm1_out;
//		out2 = Roll_2_out-pwm1_out;
//		Limit_d(&out1);
//		Limit_d(&out2); 
		
		
		
		pwm1_out = Erect_pid(&Pitch_Ang, 7-IMU_Pitch, IMU_Gyroy);
		Pitch_1_out = pwm1_out;
		Pitch_2_out = -pwm1_out;
//		Limit_d(&Pitch_1_out);
//		Limit_d(&Pitch_2_out);
		pwm2_out = Erect_pid(&Gyroy, IMU_Gyroy, 0);
		out3 = Pitch_1_out+pwm2_out;
		out4 = Pitch_2_out-pwm2_out;
		Limit_d(&out3);
		Limit_d(&out4); 
		
//		//������
//		Roll_1_out = V_pid(&Roll_Ang, 8-IMU_Roll, IMU_Gyrox);
//		Roll_2_out = -Roll_1_out;
//		Limit_d(&Roll_1_out);
//		Limit_d(&Roll_2_out);
		
//		Pitch_1_out = V_pid(&Pitch_Ang, Pitch_0-IMU_Pitch, IMU_Gyroy);
//		Pitch_2_out = -Pitch_1_out; 
//		Limit_d(&Pitch_1_out);
//		Limit_d(&Pitch_2_out);
		
//		//������
//		pwm1_out = Erect_pid(&Roll_Ang, Poll_0-IMU_Roll, 0);
//		pwm2_out = Erect_pid(&Gyrox, IMU_Gyrox, 0);
//		Roll_1_out += pwm1_out;
//		Roll_2_out -= pwm1_out;
//		Limit_d(&Roll_1_out);
//		Limit_d(&Roll_2_out);
//		out1 = Roll_1_out+pwm2_out;
//		out2 = Roll_2_out-pwm2_out;
//		Limit_d(&out1);
//		Limit_d(&out2);
//		
//		pwm3_out = Erect_pid(&Pitch_Ang, Pitch_0-IMU_Pitch, 0);
//		pwm4_out = Erect_pid(&Gyroy, IMU_Gyroy, 0);
//		Pitch_1_out += pwm3_out;
//		Pitch_2_out -= pwm3_out;
//		Limit_d(&Pitch_1_out);
//		Limit_d(&Pitch_2_out);
//		out3 = Pitch_1_out+pwm4_out;
//		out4 = Pitch_2_out-pwm4_out;
//		Limit_d(&out3);
//		Limit_d(&out4);
//		Motor_Write(out1,out3,out2,out4);

			Motor_Write(out1,out3,out2,out4);
	}
	TIM_ClearITPendingBit(TIM5, TIM_IT_Update ); //��� TIM1 �����жϱ�־
}

