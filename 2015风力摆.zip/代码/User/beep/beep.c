#include "beep.h"

void Beep_Init(void)
{
//	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void Beep_Write(uint8_t x)
{
	GPIOB->CRL &= 0xffffff0f;
	GPIOB->CRL |= 0x00000030;   //����Ϊ50M�������
	GPIOB->BRR = 0x02;				  //PB1��0
	delay_ms(x*100);
	GPIOB->BSRR  = 0x02;				//PB1��1
	GPIOB->CRL &=0xffffff0f;
	GPIOB->CRL |= 0x40;   			//����Ϊ��������
}

