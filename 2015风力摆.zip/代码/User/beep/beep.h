#ifndef _BEEP_H
#define _BEEP_H

#include "system.h"

void Beep_Init(void);
void Beep_Write(uint8_t x);


#endif


