##############################################################
# 2023年电赛训练  自循迹迷宫小车
# 创建者：周双
# 创建时间：2023.5.7
##############################################################
import sensor, image, time, lcd, math
from pyb import UART
from pyb import LED

usart1=UART(1,115200)
usart1.init(115200, bits=8, parity=None, stop=1) #初始化串口

#关闭补光灯防止地面反光
LED(1).off()
LED(2).off()
LED(3).off()

sensor.reset()
sensor.set_pixformat(sensor.RGB565)  #灰度图
sensor.set_framesize(sensor.QVGA)      #160*120
sensor.set_auto_gain(False)             #颜色跟踪必须关闭自动增益
sensor.set_auto_whitebal(False)         #颜色跟踪必须关闭白平衡
sensor.skip_frames(time = 3000)         #跳过3秒等待感光元件设置生效
#lcd.init()                              #初始化lcd


red = (67, 73, 4, 45, -8, 21)


#得到巡线模拟量函数：
def GetColor(img):
    color_blobs = img.find_blobs([red], area_threshold=70, merge=True)
    for Cor in color_blobs:
        UART_Out(Cor.cx(), Cor.cy())
    return color_blobs


#标记函数：
def Mark(cor):
    #【1】标记巡线：
    for blob in cor:
        img.draw_rectangle(blob.rect(), color=(255,255,255))        #圈出巡线区块
        img.draw_string(blob.x(), blob.y(),  "x:%dy: %d" %(blob.cx(), blob.cy()))    #圈出中心十字


#终端打印函数：
def UART_Out(Cx,Cy):

    if Cx>=255:
        Cx=255
    if Cy>=255:
        Cy=255
    #【2】串口发送：
    data = bytearray([0xb3, 0xb3, int(Cx), int(Cy), 0x5b]) #帧头 + 帧头 + 循迹值 + 赛道元素+ 帧尾
    usart1.write(data)


###########################################  主函数  ################################################
while(True):
    #【1】处理：
    img = sensor.snapshot()     #拍照,畸变矫正1.8
    Cor = GetColor(img)                        #从图像中得到赛道rho
    Mark(Cor)                                  #进行标记

    #【2】输出：
#    lcd.display(img)                    #lcd显示
#    UART_Out(line_rho)         #输出
