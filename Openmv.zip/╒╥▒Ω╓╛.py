##############################################################
# 2023年电赛训练  自循迹迷宫小车
# 创建者：周双
# 创建时间：2023.5.7
##############################################################
import sensor, image, time, lcd, math
from pyb import UART

usart1=UART(3,115200)
usart1.init(115200, bits=8, parity=None, stop=1) #初始化串口

sensor.reset()
sensor.set_pixformat(sensor.GRAYSCALE)  #灰度图
sensor.set_framesize(sensor.QQVGA)      #160*120
#sensor.set_auto_gain(False)             #颜色跟踪必须关闭自动增益
#sensor.set_auto_whitebal(False)         #颜色跟踪必须关闭白平衡
sensor.skip_frames(time = 3000)         #跳过3秒等待感光元件设置生效
#lcd.init()                              #初始化lcd

black = (0,64)
#元素识别区块：
Elements = [(0,25,160,25),    #区域1判断最前方
            (0,50,10,25),     #区域2判断左转方向
            (150,70,10,25),   #区域3判断右转方向
            (0,0,158,20)]     #区域4判断终点位置
#flag=0
global Element_data
Element_data = [0,0,0,0,0,0]   #元素类型数据列表


#获取赛道元素函数
def getElement(img):
    global Element_data
    Element_blobs=[]
    Element_blob0 = img.find_blobs([black], roi=Elements[0], area_threshold=60, merge=True)
    Element_blob1 = img.find_blobs([black], roi=Elements[1], area_threshold=60, merge=True)
    Element_blob2 = img.find_blobs([black], roi=Elements[2], area_threshold=60, merge=True)
    Element_blob3 = img.find_blobs([black], roi=Elements[3], area_threshold=900, merge=True)

    Element_data = [0,0,0,0,0,0]   #元素类型数据列表

    if Element_blob0:    #如果找到色块
        Element_data[1] = 1                     #标记
        Element_blobs.append(Element_blob0[0])  #加入 Element_blobs 列表
    if Element_blob1:    #如果找到色块
        Element_data[3] = 1                     #标记
        Element_blobs.append(Element_blob1[0])  #加入 Element_blobs 列表
    if Element_blob2:
        Element_data[5] = 1                     #标记
        Element_blobs.append(Element_blob2[0])  #加入 Element_blobs 列表
    if Element_blob3:    #如果找到色块
        Element_data[0] = 1                     #标记
        Element_data[2] = 1
        Element_blobs.append(Element_blob3[0])  #加入 Element_blobs 列表

    return Element_blobs




#标记函数：
def Mark(Element):

    #【1】标记赛道元素：
    for blob in Element:
        img.draw_rectangle(blob.rect(), color=(255,255,255))        #圈出巡线区块
        img.draw_cross(blob.cx(), blob.cy(),color=(255,255,255))    #圈出中心十字


#终端打印函数：
def UART_Out(Element):
    #【1】将标记的赛道元素转化10进制数
    Element_num = Element[0]*32+Element[1]*16+Element[2]*8+Element[3]*4+Element[4]*2+Element[5]*1

    print(Element)

    #【2】串口发送：
    data = bytearray([0xb3, 0xb3, Element_num, 0x5b]) #帧头 + 帧头 + 循迹值 + 赛道元素+ 帧尾
    usart1.write(data)



###########################################  主函数  ################################################
while(True):
    #【1】处理：
    img = sensor.snapshot().lens_corr(1.8)     #拍照,畸变矫正1.8
    Element = getElement(img)                  #从图像中得到赛道元素
    Mark(Element)                        #进行标记

    #【2】输出：
    #lcd.display(img)                    #lcd显示
    UART_Out(Element_data)         #输出
