##############################################################
# 2023年电赛训练  IO操作
# 创建者：周双
# 创建时间：2023.5.7
##############################################################
import sensor, image, time
from pyb import Pin

UserLed1 = Pin('P9', Pin.OUT_PP)           #设置p_out为输出引脚
UserLed1.high()                            #设置p_out引脚为高
UserLed1.low()                             #设置p_out引脚为低

UserLed1 = Pin('P9', Pin.IN, Pin.PULL_UP)   #设置p_in为输入引脚，并开启上拉电阻
UserLed1value = UserLed1.value()            # get value, 0 or 1#读入p_in引脚的值


###########################################  主函数  ################################################
while(True):
    #【1】处理：
    #img = sensor.snapshot().lens_corr(1.8)     #拍照,畸变矫正1.8
    UserLed1.low()

