#include "beep.h"

void beep_Init(void)
{
	//��ʼ��led�˿�
	GPIO_setAsOutputPin(GPIO_PORT_P6,GPIO_PIN0);
	GPIO_setOutputLowOnPin(GPIO_PORT_P6,GPIO_PIN0);
}

