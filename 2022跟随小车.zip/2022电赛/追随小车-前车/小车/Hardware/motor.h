#ifndef __MOTOR_h
#define __MOTOR_h

#include "driverlib.h"

#define  IN1_1  GPIO_setOutputHighOnPin(GPIO_PORT_P5,GPIO_PIN2)
#define  IN1_0  GPIO_setOutputLowOnPin(GPIO_PORT_P5,GPIO_PIN2)

#define  IN2_1  GPIO_setOutputHighOnPin(GPIO_PORT_P5,GPIO_PIN0)
#define  IN2_0  GPIO_setOutputLowOnPin(GPIO_PORT_P5,GPIO_PIN0)

#define  IN3_1  GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN6)
#define  IN3_0  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN6)

#define  IN4_1  GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN7)
#define  IN4_0  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN7)

void motor_Inti(void);
void Limit(int *PWMA,int *PWMB);
int Fabs(int p);
void Load(int PWMA,int PWMB);
void Load2(int PWMA,int PWMB);
void STOP(void);

#endif

