#include "motor.h"

int PWM_MAX=4200,PWM_MIN=-4200;

void motor_Inti(void)
{
		//��ʼ������˿�
		GPIO_setAsOutputPin(GPIO_PORT_P5,GPIO_PIN2);  //AIN1
		GPIO_setAsOutputPin(GPIO_PORT_P5,GPIO_PIN0);  //AIN2
		GPIO_setAsOutputPin(GPIO_PORT_P3,GPIO_PIN6);  //BIN1
		GPIO_setAsOutputPin(GPIO_PORT_P3,GPIO_PIN7);  //BIN2
	
//		GPIO_setOutputLowOnPin(GPIO_PORT_P1,GPIO_PIN0); //�͵�ƽ
//		GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN0);
//		GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN1);
//		GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN2);
}


/*�޷�����*/
void Limit(int *PWMA,int *PWMB)
{
	if(*PWMA>PWM_MAX) *PWMA = PWM_MAX;
	if(*PWMA<PWM_MIN) *PWMA = PWM_MIN;
	
	if(*PWMB>PWM_MAX) *PWMB = PWM_MAX;
	if(*PWMB<PWM_MIN) *PWMB = PWM_MIN;
}

/*����ֵ����*/
int Fabs(int p)
{
	int q;
	q = p>0?p:(-p);
	return q;
}

/*��ֵ����*/
/*�βΣ�PID������֮�����յ�PWMֵ*/
void Load(int PWMA,int PWMB)
{
//	int pwma_last,pwmb_last;
	
	if(PWMA>0) 	
	{
		IN1_1,IN2_0;//PWMֵ����0����ת
		Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_4,Fabs(PWMA)-106);
	}
	else       	
	{
		IN1_0,IN2_1;//PWMֵС��0����ת
		Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_4,Fabs(PWMA));
	}
	if(PWMB>0) 	
	{
		IN3_1,IN4_0;
		Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_3,Fabs(PWMB));
	}
	else 				
	{
		IN3_0,IN4_1;
		Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_3,Fabs(PWMB)-125);
	}
		
//	TIM_SetCompare4(TIM1,Fabs(PWMB));
}


void Load2(int PWMA,int PWMB)
{
	if(PWMA>0) 	IN1_1,IN2_0;//PWMֵ����0����ת
	else       	IN1_0,IN2_1;//PWMֵС��0����ת
	Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_4,Fabs(PWMA));
	
	if(PWMB>0) 	IN3_1,IN4_0;
	else 				IN3_0,IN4_1;
	Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_3,Fabs(PWMB)+16);
}

void STOP(void)
{
	IN1_0,IN2_0;
	Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_4,0);
	IN3_0,IN4_0;
	Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_3,0);
}

