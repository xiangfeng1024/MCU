#ifndef __PWM_h
#define __PWM_h

#include "driverlib.h"

void TimA0_PWM_Init(uint16_t ccr0, uint16_t psc);

void duo_ji_PWM_Init(void);
void duo_ji_enable(int duo_ji_x,float c);
	
#endif

