#ifndef __TIMER_h
#define __TIMER_h

#include "driverlib.h"

extern s16 m1,m2,c,lu,lu2;
extern int time_flag;
extern float m;

void TimA2_Init(uint16_t ccr0, uint16_t psc);

#endif
