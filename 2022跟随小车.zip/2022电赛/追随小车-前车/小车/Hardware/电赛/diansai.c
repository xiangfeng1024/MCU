#include "diansai.h"

int d=10;

void TI_1(void)
{
	while(d--)
	{
		zigbee_data(0x01);
	}
	d=10;
//	speed=-16;
//	PID_KP=-16.4;
//	PID_KD=-510;
//	PID_KI=0;
	pid_lu_aa(13);
//	pid_lu_zhi(500);//��������
	delay_ms(10);
	pid_lu(8600);
//	pid_lu_zhi(900);//��������
//		BEEP_ON;
//		STOP();
//		while(1);
	pid_lu(14520);
	useBios(-200);
	STOP();
	BEEP_ON;
}

void TI_2(void)
{
	TI_2_1();
	TI_2_2();
}


void TI_3(void)
{
	TI_3_1();
	TI_3_2();
	TI_3_3();
	STOP();
}


void TI_3_1(void)
{
	while(d--)
	{
		zigbee_data(0x03);
	}
	d=10;
	speed=-13;
	PID_KP=-8.2;
	PID_KD=-240;
	pid_lu(800);
	turn_XX(-40);
	pid_lu(1500);
//	pid_lu(600);
//	LED1_ON;
//	pid_lu_zhi(1700);//��������
//	LED3_ON;
	pid_lu(1600);
	speed=-12;
	PID_KP=-7.8;
	PID_KD=-220;
	delay_ms(10);
	pid_lu(20150);
	STOP();
}

void TI_3_2(void)
{
	pid_lu(1470);
	turn_XX(-40);  //�Ƕ�ƫ������Ȧ
	delay_ms(10);
	
	speed=-9;
	PID_KP=-6.2;
	PID_KD=-165;
	pid_lu(3800);
	
	speed=-12;
	PID_KP=-7.8;
	PID_KD=-220;
	
	pid_lu(20480);
}

void TI_3_3(void)
{
	LED3_ON;
	turn_XX3(75);
	delay_ms(10);
	pid_lu(6800);
	LED3_OFF;
	pid_lu(13750);
	useBios(-200);
	STOP();
	BEEP_ON;
}



void TI_2_1(void)
{
	while(d--)
	{
		zigbee_data(0x02);
	}
	d=10;
	speed=-13;
	PID_KP=-8.2;
	PID_KD=-240;
	pid_lu(600);
	pid_lu_zhi(1500);//��������
	pid_lu(1800);
//	pid_lu(4500);//Ȧ2
//	pid_lu(9000);//Ȧ3
//	BEEP_ON;
//	STOP();
//	while(1);
	speed=-12;
	PID_KP=-7.8;
	PID_KD=-220;
	delay_ms(10);
	pid_lu(3600);//Ȧ2
	zigbee_data(0x20);
	pid_lu(8600);//Ȧ3
	zigbee_data(0x20);
	pid_lu(4000);//Ȧ4
	zigbee_data(0x20);
	pid_lu(3750);
	STOP();
}

void TI_2_2(void)
{
	pid_lu(2220);
	turn_XX(-30);  //�Ƕ�ƫ������Ȧ
	delay_ms(10);  //Ȧ5
	while(d--)
	{
		zigbee_data(0x21);
	}
	pid_lu(5680);  //Ȧ6
	zigbee_data(0x20);
	pid_lu(7800);  //Ȧ7
	zigbee_data(0x20);
	pid_lu(5400);  //Ȧ8
	zigbee_data(0x20);
	pid_lu(2840);
	pid_lu(1790);
	zigbee_data(0x10);
	useBios(-200);
	BEEP_ON;
	STOP();
}

void TI_4(void)
{
	while(d--)
	{
		zigbee_data(0x04);
	}
	d=10;
	pid_lu_a();
	pid_lu(15300);
	pid_lu_a_j();
	useBios(0);
	useBios(0);
	STOP();
	delay_ms(4500);
	pid_lu_a4();
	pid_lu(2640);
	pid_lu_a_j();
	useBios(0);
	STOP();
	BEEP_ON;
	while(1) STOP();
}