#ifndef __TIMA_h
#define __TIMA_h

#include "driverlib.h"

void TimA0_Init(uint16_t ccr0, uint16_t psc);


#endif

