#ifndef __USART_OPENMV_h
#define __USART_OPENMV_h

#include "driverlib.h"

typedef struct _xian
{	
	 signed char rho;
	 signed char theta;
}xian;

extern xian black;

void usart_openmv_Init(uint32_t baudRate);


#endif
