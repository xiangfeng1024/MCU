#ifndef __led_h
#define __led_h

#include "driverlib.h"

#define LED1_OFF  GPIO_setOutputLowOnPin(GPIO_PORT_P1,GPIO_PIN0);  //��
#define LED2_OFF  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN0);  //��
#define LED3_OFF  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN1);  //��
#define LED4_OFF  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN2);  //��

#define LED1_ON  GPIO_setOutputHighOnPin(GPIO_PORT_P1,GPIO_PIN0);  //��
#define LED2_ON  GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0);  //��
#define LED3_ON  GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN1);  //��
#define LED4_ON  GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN2);  //��


//��������
void Led_inti(void);
void Led_toggle(void);

#endif

