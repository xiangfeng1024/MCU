#include "sensor.h"

void sensor_Init(void)
{
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P7, GPIO_PIN4); 
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P7, GPIO_PIN7);  
}

