#ifndef __PID_h
#define __PID_h

#include "driverlib.h"

//7 --  0.3
//12--  0.5
//17--  0.72

#define RHO_TARGET  16

extern float PID_KP,PID_KD,PID_KI;
extern int speed;

float V_pid(int V_stop,int V_now);
void turn_XX(int turn_pulse);
float Turn(float gyro_Z);
int distance_stop(int lu_stop,int lu_now);
void pid_lu(u32 lucheng);
void pid_lu_zhi(u32 lucheng);
int line_PID(int tho_target,int rho);
void useBios(int kd);
void pid_lu_a(void);
void pid_lu_a_j(void);
void turn_XX3(int turn_pulse);
void pid_lu_a4(void);
void pid_lu_aa(int v);



#endif

