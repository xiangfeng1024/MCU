#ifndef __KEY_h
#define __KEY_h

#define KEY1  GPIO_getInputPinValue(GPIO_PORT_P1, GPIO_PIN1)
#define KEY2  GPIO_getInputPinValue(GPIO_PORT_P1, GPIO_PIN4)

void key_Init(void);
int GO_pick(void);

#endif

