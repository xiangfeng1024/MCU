#ifndef __BEEP_h
#define __BEEP_h

#include "driverlib.h"

#define BEEP_ON  GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN0);
#define BEEP_OFF  GPIO_setOutputLowOnPin(GPIO_PORT_P6,GPIO_PIN0);

void beep_Init(void);


	
#endif

