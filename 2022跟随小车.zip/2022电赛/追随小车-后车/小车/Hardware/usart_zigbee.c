#include "usart_zigbee.h"
#include "baudrate_calculate.h"
#pragma import(__use_no_semihosting)

//int flag=0,i=0;
//int zigbee_data[3]={0};
//int zigbee_Mode=0;

void usart_zigbee_Init(uint32_t baudRate)
{
  const eUSCI_UART_Config uartConfig =
      {
				EUSCI_A_UART_CLOCKSOURCE_SMCLK,                  // ѡ��ʱ��ԴΪSMCLK
          26,                                            // 
          0,                                             // 
          111,                                           // 
          EUSCI_A_UART_NO_PARITY,                        // No Parity
          EUSCI_A_UART_LSB_FIRST,                        // MSB First
          EUSCI_A_UART_ONE_STOP_BIT,                     // One stop bit
          EUSCI_A_UART_MODE,                             // UART mode
          EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION, // Oversampling
      };
  eusci_calcBaudDividers((eUSCI_UART_Config *)&uartConfig, baudRate); //���ò�����
			
	//����GPIO����
  MAP_GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2, GPIO_PIN2 | GPIO_PIN3, GPIO_PRIMARY_MODULE_FUNCTION);
			
	//��ʼ����Ӧ����
  MAP_UART_initModule(EUSCI_A1_BASE, &uartConfig);
			
	//ʹ�ܶ�Ӧ����
  MAP_UART_enableModule(EUSCI_A1_BASE);
			
	//������������ж�
	UART_enableInterrupt(EUSCI_A1_BASE,EUSCI_A_UART_RECEIVE_INTERRUPT);
			
	//�������ڶ˿��ж�
	Interrupt_enableInterrupt(INT_EUSCIA1);
			
	//�������ж�
	Interrupt_enableMaster();
}

void VOFA_data(float a)
{
	float b;
	int i;
	u8 data[8];
	b=(float)a;
	
	data[0]=*((u8*)&b);
	data[1]=*((u8*)&b+1);
	data[2]=*((u8*)&b+2);
	data[3]=*((u8*)&b+3);
	
	data[4]=0x00;
	data[5]=0x00;
	data[6]=0x80;
	data[7]=0x7f;
	for(i=0;i<8;i++)
	{
		UART_transmitData(EUSCI_A1_BASE,data[i]);
	}
}

void VOFA_data_n(int n,float* a)
{
	float b[n];
	int i,k,m=0;
	i=n;
	u8 data[4*(i+1)];
	for(i=0;i<n;i++)
	{
		b[i] = a[i];
	}
	
	for(k=0;k<n;k++)
	{
		data[m++]=*((u8*)&b[k]);
		data[m++]=*((u8*)&b[k]+1);
		data[m++]=*((u8*)&b[k]+2);
		data[m++]=*((u8*)&b[k]+3);
	}
	
	data[4*n]=0x00;
	data[4*n+1]=0x00;
	data[4*n+2]=0x80;
	data[4*n+3]=0x7f;
	
	for(i=0;i<4*(n+1);i++)
	{
		UART_transmitData(EUSCI_A1_BASE,data[i]);
	}
}

void zigbee_data(int b)
{
	UART_transmitData(EUSCI_A1_BASE,0x33);
	UART_transmitData(EUSCI_A1_BASE,b);
	UART_transmitData(EUSCI_A1_BASE,0x55);
}

extern int zigbee_Mode;

void EUSCIA1_IRQHandler(void)
{
	static int flag=0,i=0;
	static int zigbee_data[3]={0};

	int a=0;
	uint32_t status = UART_getEnabledInterruptStatus(EUSCI_A1_BASE);
	
	if(status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG)  //�����ж�
	{
		a=UART_receiveData(EUSCI_A1_BASE);
		if(a==0x33)
		{
			flag=1;
//			LED1_ON;
		}
		if(flag==1)
		{
			zigbee_data[i]=a;
			i++;
			if(i>2) 
			{
				i=0;
				flag=0;
				if(zigbee_data[0]==0x33&&zigbee_data[2]==0x55)
				{
//					LED1_ON;
					zigbee_Mode=zigbee_data[1];
//					OLED_ShowNum(0,2,zigbee_Mode,2,16);
				}
			}
		}
	}
}

struct __FILE
{
  int handle;
};
FILE __stdout;

void _sys_exit(int x)
{
  x = x;
}

void _ttywrch(int ch)
{
    ch = ch;
}

int fputc(int ch, FILE *f)
{
  UART_transmitData(EUSCI_A1_BASE, ch & 0xFF);
  return ch;
}

