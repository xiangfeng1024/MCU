#include "pid.h"

extern int zigbee_Mode;

float PID_KP=0,PID_KD=0;
float d2[5]={0};
extern s16 t;
int speed=7;
int ff=0;

void turn_XX(int turn_pulse)
{
	lu2 = 0;
	while(1)
	{
		if(turn_pulse>0)
		{
			Load2(1850,-1250);
			delay_us(10);
		}
		else
		{
			Load2(2250,-2850);
			delay_us(10);
		}
//		d2[0]=m1;
//		d2[1]=m2;
//		d2[2]=m;
//		d2[3]=lu;
//		d2[4]=lu1;
//		VOFA_data_n(5,d2);
		if(Fabs(lu2)>Fabs(turn_pulse)) break;
	}
//	STOP();
}

void turn_XX2(int turn_pulse)
{
	lu2 = 0;
	while(1)
	{
		if(turn_pulse>0)
		{
			Load2(1850,-1250);
			delay_us(10);
		}
		else
		{
			Load2(1250,-1850);
			delay_us(10);
		}
//		d2[0]=m1;
//		d2[1]=m2;
//		d2[2]=m;
//		d2[3]=lu;
//		d2[4]=lu1;
//		VOFA_data_n(5,d2);
		if(Fabs(lu2)>Fabs(turn_pulse)) break;
	}
//	STOP();
}

void turn_XX4(int turn_pulse)
{
	lu2 = 0;
	while(1)
	{
		if(turn_pulse>0)
		{
			Load2(1850,-1250);
			delay_us(10);
		}
		else
		{
			Load2(3450,-3650);
			delay_us(10);
		}
//		d2[0]=m1;
//		d2[1]=m2;
//		d2[2]=m;
//		d2[3]=lu;
//		d2[4]=lu1;
//		VOFA_data_n(5,d2);
		if(Fabs(lu2)>Fabs(turn_pulse)) break;
	}
//	STOP();
	
}


void pid_lu_zhi(u32 lucheng)
{
	int out=0;
	lu=0;
	while(distance_stop(lucheng,lu))
	{
		out=V_pid(speed,m);
		Load2(out,-out-90);
		delay_ms(3);
//		d2[0]=m1;
//		d2[1]=m2;
//		d2[2]=m;
//		d2[3]=lu;
//		d2[4]=lu1;
//		VOFA_data_n(5,d2);
	}
}

void pid_lu3(u32 lucheng)
{
	int out=0,line_pid=0;
	int motor_left=0,motor_right=0;
	lu=0;
	while(distance_stop(lucheng,lu))
	{
		out=V_pid(speed,m);
		line_pid=line_PID(RHO_TARGET,black.rho);
		
		motor_left = out + line_pid;
		motor_right = out - line_pid;
		Limit(&motor_left,&motor_right);
		Load2(motor_left,-motor_right);
//		OLED_ShowNum(0,2,out,4,16);
		delay_ms(1);
		if(SENSOR1==0&&lucheng>7500) break;
		if((SENSOR2==1||SENSOR3==1)&&ff==0)
		{
			ff=1;
			pid_lu(200);
			turn_XX(-20);//��ת
			delay_ms(20);
		}
	}
}

void pid_lu(u32 lucheng)
{
	int out=0,line_pid=0;
	int motor_left=0,motor_right=0;
	lu=0;
	while(distance_stop(lucheng,lu))
	{
		out=V_pid(speed,m);
		line_pid=line_PID(RHO_TARGET,black.rho);
		OLED_ShowNum(0,2,black.rho,3,16);
		
		motor_left = out + line_pid;
		motor_right = out - line_pid;
		Limit(&motor_left,&motor_right);
		Load2(motor_left,-motor_right);
//		OLED_ShowNum(0,2,out,4,16);
		delay_ms(2);
	}
}


void pid_lu2(u32 lucheng)
{
	int out=0,line_pid=0;
	int motor_left=0,motor_right=0;
	lu=0;
	while(distance_stop(lucheng,lu))
	{
		out=V_pid(speed,m);
		line_pid=line_PID(RHO_TARGET,black.rho);
		
		motor_left = out + line_pid;
		motor_right = out - line_pid;
		Limit(&motor_left,&motor_right);
		Load2(motor_left,-motor_right);
		delay_ms(1);
		if(SENSOR1==0) 
		{
			speed=9;
			PID_KP=-10.8;
			PID_KD=-190;
		}
		if(SENSOR1==1)
		{
			speed=12;
			PID_KP=-12.4;
			PID_KD=-320;
		}
		if(zigbee_Mode==0x10) 
		{
			useBios(-330);
			STOP();
			BEEP_ON
			while(1);
		}
		if(zigbee_Mode==0x20)
		{
			zigbee_Mode=0;
			speed=12;
			PID_KP=-14.8;
			PID_KD=-320;
			pid_lu(2000);
			LED1_OFF;
			LED3_OFF;
			LED2_OFF;
		}
		if(zigbee_Mode==0x21)
		{
			zigbee_Mode=0;
			speed=12;
			PID_KP=-14.8;
			PID_KD=-320;
			pid_lu(300);
			turn_XX2(-10);//��ת
			delay_ms(20);
			
		}
	}
}

float V_pid(int V_stop,int V_now)  //�ٶȱջ�
{
	float Kp=7.5,Ki=380;
	static float last_error=0;
	float error;
	static int out;
	
	error = V_stop-V_now;
	out += Kp*error+Ki*(error-last_error);
	
	last_error = error;
	
	return out;
}

int distance_stop(int lu_stop,int lu_now)  //����ͻ������
{
	if(lu_now>=lu_stop)
	{
		return 0;
	}
	return 1;
}

int line_PID(int tho_target,int rho)
{
	int ret;
//	static float PID_KP=-2.2,PID_KP=-110;  //�ٶ�8��kp-7.8     7:  p=-4.2  d=-110       -9,8
	float rho_error;                        //�ٶ�12  -4.2  -200  �ٶ�17  -8.2  -465
	static float rho_error_last=0;
	
	rho_error = rho - tho_target;
	
	ret = PID_KP*rho_error+PID_KD*(rho_error-rho_error_last);
	rho_error_last=rho_error;
	
	return ret;	
}

//����
void useBios(int kd)
{
	int bios_pid=0;
	PID_KD=0;
	unsigned int count = 20000;
	
	while(count)
	{
		bios_pid = 2.5 *line_PID(RHO_TARGET,black.rho);
//		delay_ms(20);
//		OLED_ShowNum(0,2,bios_pid ,4,16);
		Load2(bios_pid,bios_pid);
		
		count --;
	}
	PID_KD=kd;
}

void pid_lu_a(void)
{
	int j=5;
	while(j<19)
	{
		switch(j)
		{
//			case 1:speed=5;PID_KP=-2.8;PID_KD=-30;break;
//			case 2:speed=6;PID_KP=-3.1;PID_KD=-60;break;
//			case 3:speed=7;PID_KP=-5.3;PID_KD=-85;break;
//			case 4:speed=8;PID_KP=-6.8;PID_KD=-120;break;
//			case 5:speed=9;PID_KP=-7.9;PID_KD=-150;break;
			case 6:speed=10;PID_KP=-9.1;PID_KD=-170;break;
			case 7:speed=11;PID_KP=-10.2;PID_KD=-220;break;
			case 8:speed=12;PID_KP=-11.5;PID_KD=-240;break;
			case 9:speed=13;PID_KP=-12.7;PID_KD=-270;break;
			case 10:speed=14;PID_KP=-14.2;PID_KD=-360;break;
			case 11:speed=15;PID_KP=-15.8;PID_KD=-420;break;
			case 12:speed=16;PID_KP=-16.4;PID_KD=-510;break;
			case 13:speed=17;PID_KP=-17.6;PID_KD=-660;break;
			case 14:speed=18;PID_KP=-18.6;PID_KD=-690;break;
			case 15:speed=19;PID_KP=-19.8;PID_KD=-740;break;
			case 16:speed=20;PID_KP=-22.6;PID_KD=-780;break;
			case 17:speed=21;PID_KP=-24.8;PID_KD=-860;break;
			case 18:speed=22;PID_KP=-28.1;PID_KD=-980;break;
		}
		pid_lu(120);
		j++;
	}
}


void pid_lu_a2(void)
{
	int j=5;
	while(j<16)
	{
		switch(j)
		{
//			case 1:speed=5;PID_KP=-2.8;PID_KD=-30;break;
//			case 2:speed=6;PID_KP=-3.1;PID_KD=-60;break;
//			case 3:speed=7;PID_KP=-5.3;PID_KD=-85;break;
//			case 4:speed=8;PID_KP=-6.8;PID_KD=-120;break;
//			case 5:speed=9;PID_KP=-7.9;PID_KD=-150;break;
			case 6:speed=10;PID_KP=-9.1;PID_KD=-170;break;
			case 7:speed=11;PID_KP=-10.2;PID_KD=-220;break;
			case 8:speed=12;PID_KP=-11.5;PID_KD=-240;break;
			case 9:speed=13;PID_KP=-12.7;PID_KD=-270;break;
			case 10:speed=14;PID_KP=-14.2;PID_KD=-360;break;
			case 11:speed=15;PID_KP=-15.8;PID_KD=-420;break;
			case 12:speed=16;PID_KP=-16.4;PID_KD=-510;break;
			case 13:speed=17;PID_KP=-17.6;PID_KD=-660;break;
			case 14:speed=18;PID_KP=-18.6;PID_KD=-690;break;
			case 15:speed=19;PID_KP=-19.8;PID_KD=-740;break;
//			case 16:speed=20;PID_KP=-22.6;PID_KD=-780;break;
//			case 17:speed=21;PID_KP=-24.8;PID_KD=-860;break;
//			case 18:speed=22;PID_KP=-28.1;PID_KD=-980;break;
		}
		pid_lu(130);
		j++;
	}
}

void pid_lu_a_j(void)
{
	int j=1;
	while(j<13)
	{
		switch(j)
		{
			case 1:speed=22;PID_KP=-24.1;PID_KD=-30;break; 
			case 2:speed=21;PID_KP=-20.8;PID_KD=-60;break;
			case 3:speed=20;PID_KP=-18.6;PID_KD=-85;break;
			case 4:speed=19;PID_KP=-17.8;PID_KD=-120;break;
			case 5:speed=18;PID_KP=-16.6;PID_KD=-150;break;
			case 6:speed=17;PID_KP=-15.6;PID_KD=-170;break;
			case 7:speed=16;PID_KP=-14.4;PID_KD=-220;break;
			case 8:speed=15;PID_KP=-13.8;PID_KD=-240;break;
			case 9:speed=14;PID_KP=-12.2;PID_KD=-270;break;
			case 10:speed=13;PID_KP=-10.7;PID_KD=-360;break;
			case 11:speed=12;PID_KP=-9.5;PID_KD=-420;break;
			case 12:speed=11;PID_KP=-8.2;PID_KD=-510;break;
//			case 13:speed=-10;PID_KP=-9.1;PID_KD=-660;break;
//			case 14:speed=-9;PID_KP=-7.9;PID_KD=-690;break;
//			case 15:speed=-8;PID_KP=-6.8;PID_KD=-740;break;
//			case 16:speed=-7;PID_KP=-5.3;PID_KD=-780;break;
//			case 17:speed=-6;PID_KP=-3.1;PID_KD=-860;break;
//			case 15:speed=6;PID_KP=-3.1;PID_KD=-860;break;
		}
//		if(j<7)
//		{
			pid_lu(120);
//		}
//		else
//		{
//			pid_lu_zhi(120);
//		}
		j++;
	}
}

void pid_lu_a4(void)
{
	int j=5;
	while(j<19)
	{
		switch(j)
		{
//			case 1:speed=5;PID_KP=-2.8;PID_KD=-30;break;
//			case 2:speed=6;PID_KP=-3.1;PID_KD=-60;break;
//			case 3:speed=7;PID_KP=-5.3;PID_KD=-85;break;
//			case 4:speed=8;PID_KP=-6.8;PID_KD=-120;break;
//			case 5:speed=9;PID_KP=-7.9;PID_KD=-150;break;
			case 6:speed=10;PID_KP=-9.1;PID_KD=-170;break;
			case 7:speed=11;PID_KP=-10.2;PID_KD=-220;break;
			case 8:speed=12;PID_KP=-11.5;PID_KD=-240;break;
			case 9:speed=13;PID_KP=-12.7;PID_KD=-270;break;
			case 10:speed=14;PID_KP=-14.2;PID_KD=-360;break;
			case 11:speed=15;PID_KP=-15.8;PID_KD=-420;break;
			case 12:speed=16;PID_KP=-16.4;PID_KD=-510;break;
			case 13:speed=17;PID_KP=-17.6;PID_KD=-660;break;
			case 14:speed=18;PID_KP=-18.6;PID_KD=-690;break;
			case 15:speed=19;PID_KP=-19.8;PID_KD=-740;break;
			case 16:speed=20;PID_KP=-22.6;PID_KD=-780;break;
			case 17:speed=21;PID_KP=-24.8;PID_KD=-860;break;
			case 18:speed=22;PID_KP=-28.1;PID_KD=-980;break;
		}
		pid_lu(100);
		j++;
	}
}

void pid_lu_aa(int v)
{
	int j=5;
	while(j<v)
	{
		switch(j)
		{
//			case 1:speed=5;PID_KP=-2.8;PID_KD=-30;break;
//			case 2:speed=6;PID_KP=-3.1;PID_KD=-60;break;
//			case 3:speed=7;PID_KP=-5.3;PID_KD=-85;break;
//			case 4:speed=8;PID_KP=-6.8;PID_KD=-120;break;
//			case 5:speed=9;PID_KP=-7.9;PID_KD=-150;break;
			case 6:speed=10;PID_KP=-9.1;PID_KD=-170;break;
			case 7:speed=11;PID_KP=-10.2;PID_KD=-220;break;
			case 8:speed=12;PID_KP=-11.5;PID_KD=-240;break;
			case 9:speed=13;PID_KP=-12.7;PID_KD=-270;break;
			case 10:speed=14;PID_KP=-14.2;PID_KD=-360;break;
			case 11:speed=15;PID_KP=-15.8;PID_KD=-420;break;
			case 12:speed=16;PID_KP=-12.1;PID_KD=-310;break;
			case 13:speed=17;PID_KP=-17.6;PID_KD=-660;break;
			case 14:speed=18;PID_KP=-18.6;PID_KD=-690;break;
			case 15:speed=19;PID_KP=-19.8;PID_KD=-740;break;
			case 16:speed=20;PID_KP=-22.6;PID_KD=-780;break;
			case 17:speed=21;PID_KP=-24.8;PID_KD=-860;break;
			case 18:speed=22;PID_KP=-28.1;PID_KD=-980;break;
		}
		if(j<18)
		{
			//pid_lu_zhi(130);
			pid_lu(130);
		}
		else
		{
			pid_lu_zhi(200);
			//pid_lu(130);
		}
		j++;
	}
}
