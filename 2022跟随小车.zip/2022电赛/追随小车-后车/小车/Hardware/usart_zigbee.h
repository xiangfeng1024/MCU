#ifndef __USART_ZIGBEE_h
#define __USART_ZIGBEE_h

#include "driverlib.h"
#include "stdio.h"

void usart_zigbee_Init(uint32_t baudRate);
void VOFA_data_n(int n,float* a);
void VOFA_data(float a);
//void VOFA_data_n(int n,float* a);
void zigbee_data(int data);


#endif


