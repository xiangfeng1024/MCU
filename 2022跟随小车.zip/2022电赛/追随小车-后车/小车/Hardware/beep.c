#include "beep.h"

void beep_Init(void)
{
	//��ʼ��led�˿�
	GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN4);
	GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN4);
}

