#ifndef __BEEP_h
#define __BEEP_h

#include "driverlib.h"

#define BEEP_OFF  GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN4);
#define BEEP_ON  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN4);

void beep_Init(void);


	
#endif

