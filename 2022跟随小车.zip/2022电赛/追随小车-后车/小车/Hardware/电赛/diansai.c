#include "diansai.h"

extern int zigbee_Mode;

void TI_1(void)
{
	zigbee_Mode=0;
//	speed=7;
//	PID_KP=-7.8;
//	PID_KD=-100;
	pid_lu_aa(12);
	pid_lu(1550);
	pid_lu_zhi(800);//��������
	delay_ms(10);
	pid_lu(20950);
	useBios(-330);
	BEEP_ON;
	STOP();
	while(1);
}

void TI_2(void)
{
	zigbee_Mode=0;
	pid_lu_a2();
	pid_lu3(7500);
	speed=14;
	PID_KP=-14.8;
	PID_KD=-350;
	pid_lu3(230000);
	pid_lu2(230000);
	while(1) STOP();
}

void TI_3_1(void)
{
	speed=12;
	PID_KP=-10.8;
	PID_KD=-260;
//	pid_lu(3000);
//	turn_XX2(-40);
//	pid_lu(1200);
	pid_lu(2800);
	pid_lu_zhi(1400);//��������
	pid_lu(20550);
}

void TI_3_2(void)
{
	pid_lu(3100);
	LED3_ON;
	turn_XX2(100);
	PID_KP=-11.4;
	PID_KD=-230;
	pid_lu(6000);
	PID_KP=-10.8;
	PID_KD=-260;
	pid_lu(900);
	LED3_OFF;
	pid_lu(12850);
}

void TI_3_3(void)
{
	pid_lu(1900);
	turn_XX2(-40);
	speed=10;
	PID_KP=-9.0;
	PID_KD=-230;
	pid_lu(10200);
	speed=12;
	PID_KP=-10.8;
	PID_KD=-260;
	pid_lu(11000);
}

	
void TI_3(void)
{
	zigbee_Mode=0;
	TI_3_1();
	TI_3_2();
	TI_3_3();
	useBios(-330);
	STOP();
	BEEP_ON;
	while(1) STOP();
}

void TI_4(void)
{
	zigbee_Mode=0;
	pid_lu_a();
//	turn_XX4(-30);
//	LED3_ON;
	pid_lu_zhi(550);
	pid_lu(15000);
	pid_lu_a_j();
	useBios(0);
	useBios(0);
	STOP();
	delay_ms(4500);
	pid_lu_a4();
	pid_lu(2640);
	pid_lu_a_j();
	useBios(0);
	STOP();
	BEEP_ON;
	while(1) STOP();
}
