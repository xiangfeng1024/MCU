#ifndef __DIANSAI_h
#define __DIANSAI_h

#include "driverlib.h"

void TI_1(void);
void TI_2(void);
void TI_3(void);
void TI_4(void);

#endif

