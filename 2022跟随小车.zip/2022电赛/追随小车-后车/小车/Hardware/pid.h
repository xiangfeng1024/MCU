#ifndef __PID_h
#define __PID_h

#include "driverlib.h"

extern float PID_KP,PID_KD;
extern int speed;
//						 PID_T2_KP,PID_T2_KP,
//						 PID_T3_KP,PID_T3_KP,
//						 PID_T4_KP,PID_T4_KP;

#define RHO_TARGET  -5

extern int speed;

float V_pid(int V_stop,int V_now);
void turn_XX(int turn_pulse);
float Turn(float gyro_Z);
int distance_stop(int lu_stop,int lu_now);
int line_PID(int tho_target,int rho);
void pid_lu(u32 lucheng);
void pid_lu_zhi(u32 lucheng);
int line_PID(int tho_target,int rho);
void useBios(int kd);
void pid_lu_a(void);
void pid_lu2(u32 lucheng);
void pid_lu_a_j(void);
void pid_lu_a2(void);
void pid_lu3(u32 lucheng);
void turn_XX2(int turn_pulse);
void pid_lu_a4(void);
void turn_XX4(int turn_pulse);
void pid_lu_aa(int v);



#endif

