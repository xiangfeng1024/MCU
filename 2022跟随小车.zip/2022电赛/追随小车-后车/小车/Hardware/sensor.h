#ifndef __SENSOR_h
#define __SENSOR_h

#include "driverlib.h"

#define SENSOR1  GPIO_getInputPinValue(GPIO_PORT_P7, GPIO_PIN4)
#define SENSOR2  GPIO_getInputPinValue(GPIO_PORT_P7, GPIO_PIN7)
#define SENSOR3  GPIO_getInputPinValue(GPIO_PORT_P7, GPIO_PIN6)

void sensor_Init(void);

#endif

