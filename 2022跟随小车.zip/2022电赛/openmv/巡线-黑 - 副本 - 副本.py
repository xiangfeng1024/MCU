import sensor, image, time, math  #导入用到的库
from pyb import UART
from pyb import LED
#(28, 47, -6, 59, -16, 29)
#LED(1).on()
#LED(2).on()
LED(3).on()

THRESHOLD = (28, 47, -6, 59, -16, 29)  #黑线阈值

uart = UART(3, 115200)
uart.init(115200, bits=8, parity=None, stop=1)  #8位数据位，无校验位，1位停止位

def outuart(rho,thera):
    data = bytearray([0xb3,0xb3,int(rho),int(thera),0x5b])
    uart.write(data)
    time.sleep_ms(1)

sensor.reset()  #重置感光元件，重置摄像机
sensor.set_pixformat(sensor.RGB565)  #设置颜色格式为RGB565
sensor.set_framesize(sensor.QQQVGA)  #图像大小为QVGA
sensor.skip_frames(time = 2000)  #
sensor.set_auto_gain(False)  #关闭白平衡
clock = time.clock()

while(True):
    #clock.tick()
    img = sensor.snapshot().binary([THRESHOLD]).lens_corr(1.8)
    line = img.get_regression([(100,100)], robust = True)
    if (line):
        rho =abs(line.rho())-img.width()/2
        if(rho>=127):
            rho=127
        if(rho<=-128):
            rho=-128
        rho = rho+80
        outuart(rho,55)
        #uart.write(bytearray([int(rho)]))
        print(int(rho))
        #print(clock.fps)
