#ifndef __PWM_h
#define __PWM_h

#include "driverlib.h"

void TimA0_PWM_Init(uint16_t ccr0, uint16_t psc);
	
#endif

