#include "led.h"

void Led_Init(void)
{
		//��ʼ��led�˿�
		GPIO_setAsOutputPin(GPIO_PORT_P1,GPIO_PIN0);  //P1.0,���
		GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN0);
		GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN1);
		GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN2);
	
		GPIO_setOutputLowOnPin(GPIO_PORT_P1,GPIO_PIN0); //�͵�ƽ
		GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN0);
		GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN1);
		GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN2);
}

//led�ƶ˿�ȡ�����
void Led_toggle(void)
{
	 	GPIO_toggleOutputOnPin(GPIO_PORT_P1,GPIO_PIN0);  //��ת
		GPIO_toggleOutputOnPin(GPIO_PORT_P2,GPIO_PIN0);
		GPIO_toggleOutputOnPin(GPIO_PORT_P2,GPIO_PIN1);
		GPIO_toggleOutputOnPin(GPIO_PORT_P2,GPIO_PIN2);
}


