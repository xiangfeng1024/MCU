#ifndef __MOTOR_h
#define __MOTOR_h

#include "driverlib.h"

#define  IN1_1  GPIO_setOutputHighOnPin(GPIO_PORT_P5,GPIO_PIN2)
#define  IN1_0  GPIO_setOutputLowOnPin(GPIO_PORT_P5,GPIO_PIN2)

#define  IN2_1  GPIO_setOutputHighOnPin(GPIO_PORT_P5,GPIO_PIN0)
#define  IN2_0  GPIO_setOutputLowOnPin(GPIO_PORT_P5,GPIO_PIN0)

#define  IN3_1  GPIO_setOutputHighOnPin(GPIO_PORT_P3,GPIO_PIN0)
#define  IN3_0  GPIO_setOutputLowOnPin(GPIO_PORT_P3,GPIO_PIN0)

#define  IN4_1  GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN5)
#define  IN4_0  GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN5)

#define MOTOR_Line		1
#define MOTOR_TURN		2

void V_Set(int v);
void motor_Init(void);
void Limit(int *PWMA,int *PWMB);
int Fabs(int p);
void Load(int PWMA,int PWMB);
void MOTOR_STOP(void);
void Motor_Write(int Mode,int pulse);
int Distance_limit(int hope,int real);

#endif

