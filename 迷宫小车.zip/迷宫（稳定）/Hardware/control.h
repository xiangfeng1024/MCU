#ifndef __CONTROL_h
#define __CONTROL_h

#include "driverlib.h"

#define LINE_HOPE  80

//#define V_HOPE  12
#define TURN_RIGHT_90  335
#define TURN_RIGHT_180  790
#define TURN_LEFT_90  -440

#define L   1
#define S   2
#define R   3
#define B   4
#define STOP   5
#define ERR    8

#define CONTROL_L   TURN_UP=1
#define CONTROL_S   TURN_UP=0
#define CONTROL_R   TURN_UP=2
#define CONTROL_B   TURN_UP=3
/***********************��������****************************/
extern u8 MG_ELEMENT[512];			//=======�����ӦԪ������
extern u8 *Element;         		//=======Ԫ��λ��ָ��
extern u8 BACK_ELEMENT[512];		//=======���·��
extern u8 *Back_Element;        //=======���·��ָ��

extern int Pick_kp,
					 Pick_kd,
					 Pick_V,
					 Pick_turn_out,
					 Pick_turn_out1,
					 Pick_turn_pulse,
					 Pick_turn_pulse1,
					 Pick_line_stop,
					 Pick_turn_stop,
					 Pick_line_pulse_left,
					 Pick_line_pulse_right,
					 Pick_turn_pulse_right_comp;
				 
extern int GO_FLAG,
					 HUI_FLAG,
					 TURN_FLAG,
					 PULSE_SKIP_FLAG,
					 LINE_FLAG,
					 TURN_UP,
					 V_UP;

extern float line_out,
						 turn_out,
						 turn_out1;
						 

extern s16 	m1,
						m2,
						m,
						m_turn;

void TA2_0_IRQHandler(void);
void BUGing(void);
void Control_Pick(int Mode);
void Interrupt_NVIC_Config(void);
u8 Openmv_Element_Process(void);
u8 Element_Set(u8 a,u8 b,u8 c);
void Back_LSRB_Set(u8 *p1, u8 *p2);
void Element_Control(void);
void Mode_Pick(u8 Mode);
void cai_dan(void);

#endif

