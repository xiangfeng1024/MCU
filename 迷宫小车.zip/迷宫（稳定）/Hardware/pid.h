#ifndef __PID_h
#define __PID_h

#include "driverlib.h"

struct PID
{
	float kp;
	float ki;
	float kd;
	
	float err;
	float err_last;
	float err_last_dev;
	float out;
};

extern struct PID V_LEFT,V_RIGHT,line;

void PID_Init(void);
float V_pid(struct PID* para,int V_stop,int V_now);
int line_pid(struct PID* para,int line_stop,int line_now);

#endif

