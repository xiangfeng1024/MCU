#include "encoder.h"

void Encoder_Init(void)
{
	//1.A��GPIO��ʼ
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4, GPIO_PIN5);
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4, GPIO_PIN0);
	
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4, GPIO_PIN2);
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4, GPIO_PIN4);
	
	//2.��� P4.4 ���жϱ�־λ
	GPIO_clearInterruptFlag(GPIO_PORT_P4, GPIO_PIN5);
	GPIO_clearInterruptFlag(GPIO_PORT_P4, GPIO_PIN2);
	
	//3.���������ش����ж�
	GPIO_interruptEdgeSelect(GPIO_PORT_P4,GPIO_PIN5,GPIO_LOW_TO_HIGH_TRANSITION);
	GPIO_interruptEdgeSelect(GPIO_PORT_P4,GPIO_PIN2,GPIO_LOW_TO_HIGH_TRANSITION);
	
	//4.����P4.4��GPIO�˿��ж�
	GPIO_enableInterrupt(GPIO_PORT_P4, GPIO_PIN5);
	GPIO_enableInterrupt(GPIO_PORT_P4, GPIO_PIN2);
	
	//5.ʹ���ж�2
	Interrupt_enableInterrupt(INT_PORT4);
	
	//6.�������ж�
//	Interrupt_enableMaster();
}

void Pulse_Set(int pulse)
{
	m=0;
	LINE_FLAG=0;
	line_out=0;
	while(Distance_limit(Fabs(pulse),Fabs(m)));
}

void Pulse_turn_Set(int pulse)
{
	m_turn=0;
	LINE_FLAG=0;
	line_out=0;
	while(Distance_limit(Fabs(pulse),Fabs(m_turn)));
}

s16 encoder_num2=0,encoder_num1=0;

s16 Encoder_Read(int x)
{
	s16 value=0;
	switch(x)
	{
		case 1:value=encoder_num1;encoder_num1=0;break;
		case 2:value=encoder_num2;encoder_num2=0;break;
		default:value = 0;
	}
	return value;
}

void PORT4_IRQHandler(void)
{
	uint32_t status;
	
	status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P4);
	GPIO_clearInterruptFlag(GPIO_PORT_P4, status);
	
	if(status == GPIO_PIN5) //B���½��������ж�
	{
		if(GPIO_getInputPinValue(GPIO_PORT_P4,GPIO_PIN0)==GPIO_INPUT_PIN_LOW)  //�͵�ƽ
		{
				encoder_num2--; //������
		}
		else
		{
				encoder_num2++; //������
		}
	}
	
	if(status == GPIO_PIN2) //B���½��������ж�
	{
		if(GPIO_getInputPinValue(GPIO_PORT_P4,GPIO_PIN4)==GPIO_INPUT_PIN_LOW)  //�͵�ƽ
		{
				encoder_num1--; //������
		}
		else
		{
				encoder_num1++; //������
		}
	}
}

