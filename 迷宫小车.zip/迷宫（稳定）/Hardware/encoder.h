#ifndef __ENCODER_h
#define __ENCODER_h

#include "driverlib.h"

void Encoder_Init(void);
s16 Encoder_Read(int x);
void Pulse_Set(int pulse);
void Pulse_turn_Set(int pulse);

extern s16 lu;

#endif

