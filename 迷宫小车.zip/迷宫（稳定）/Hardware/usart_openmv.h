#ifndef __USART_OPENMV_h
#define __USART_OPENMV_h

#include "driverlib.h"

#define 	Openmv_DATA_SIZE  6

void usart_openmv_Init(uint32_t baudRate);
void Openmv_Init(void);

extern u8 line_rho,Element_data,turn_stop,tick;
extern u8 Element_buff[6];

#endif
