##############################################################
# 2023年电赛训练  自循迹迷宫小车
# 创建者：周双
# 创建时间：2023.5.7
##############################################################
import sensor, image, time, lcd, math
from pyb import UART
from pyb import LED

usart1=UART(3,115200)
usart1.init(115200, bits=8, parity=None, stop=1) #初始化串口

#关闭补光灯防止地面反光
LED(1).off()
LED(2).off()
LED(3).off()

sensor.reset()
sensor.set_pixformat(sensor.GRAYSCALE)  #灰度图
sensor.set_framesize(sensor.QQVGA)      #160*120
#sensor.set_auto_gain(False)             #颜色跟踪必须关闭自动增益
#sensor.set_auto_whitebal(False)         #颜色跟踪必须关闭白平衡
sensor.skip_frames(time = 3000)         #跳过3秒等待感光元件设置生效
#lcd.init()                              #初始化lcd

#循迹黑色色块阈值：
black = (0,64)                           #循迹黑色赛道阈值
black_roi= [(0, 100, 160, 10, 0.9),      #3个roi用于巡线，获取模拟量
            (0, 85, 160, 10, 0.2),       #元组第四位代码权重，离小车越近的roi权重越高
            (0, 70, 160, 10, 0.1)]       #利用3个roi获取赛道rho、thera

weight_sum = 0                           #权值和初始化
for r in black_roi: weight_sum += r[4]
global line_rho
line_rho=0                               #rho变量
turn_stop=0

#元素识别区块：
Elements = [(0,25,160,25),    #区域1判断最前方
            (0,50,10,25),     #区域2判断左转方向
            (150,70,10,25),   #区域3判断右转方向
            (0,0,158,20)]     #区域4判断终点位置
#flag=0
global Element_data
Element_data = [0,0,0,0,0,0]   #元素类型数据列表


#得到巡线模拟量函数：
def getLine(img):
    global line_rho
    global Element_data
    global turn_stop
    line_blobs=[]
    centroid_sum = 0                                       #权重
    for r in black_roi:                                    #利用颜色识别分别寻找三个矩形区域内的线段
        black_blobs = img.find_blobs([black], roi=r[0:4],y_stride=10,area_threshold=100, merge=True)
        if black_blobs:
           largest_blob = max(black_blobs, key=lambda b: b.pixels())    #查找像素最多的blob的索引
           line_blobs.append(largest_blob)                              #加入 line_blobs 列表
           centroid_sum += largest_blob.cx() * r[4]                     #计算centroid_sum，centroid_sum等于
                                                                        #每个区域的最大颜色块的中心点的x坐标值乘
                                                                        #本区域的权值
    line_rho = int(centroid_sum / weight_sum)                           #中间值公式
    turn_stop=0
    if len(line_blobs)>2:
        turn_stop = abs(line_blobs[0].cx() - line_blobs[2].cx())
    else:
        turn_stop = 100
    return line_blobs


#获取赛道元素函数
def getElement(img):
    global Element_data
    Element_blobs=[]
    Element_blob0 = img.find_blobs([black], roi=Elements[0], area_threshold=60, merge=True)
    Element_blob1 = img.find_blobs([black], roi=Elements[1], area_threshold=60, merge=True)
    Element_blob2 = img.find_blobs([black], roi=Elements[2], area_threshold=60, merge=True)
    Element_blob3 = img.find_blobs([black], roi=Elements[3], area_threshold=900, merge=True)

    Element_data = [0,0,0,0,0,0]   #元素类型数据列表

    if Element_blob0:    #如果找到色块
        Element_data[1] = 1                     #标记
        Element_blobs.append(Element_blob0[0])  #加入 Element_blobs 列表
    if Element_blob1:    #如果找到色块
        Element_data[3] = 1                     #标记
        Element_blobs.append(Element_blob1[0])  #加入 Element_blobs 列表
    if Element_blob2:
        Element_data[5] = 1                     #标记
        Element_blobs.append(Element_blob2[0])  #加入 Element_blobs 列表
    if Element_blob3:    #如果找到色块
        Element_data[0] = 1                     #标记
        Element_data[2] = 1
        Element_blobs.append(Element_blob3[0])  #加入 Element_blobs 列表

    return Element_blobs




#标记函数：
def Mark(Line, Element):
    #【1】标记巡线：
    for blob in Line:
        img.draw_rectangle(blob.rect(), color=(255,255,255))        #圈出巡线区块
        img.draw_cross(blob.cx(), blob.cy(),color=(255,255,255))    #圈出中心十字

    #【2】标记赛道元素：
    for blob in Element:
        img.draw_rectangle(blob.rect(), color=(255,255,255))        #圈出巡线区块
        img.draw_cross(blob.cx(), blob.cy(),color=(255,255,255))    #圈出中心十字
'''
#串口接收函数
def UART_Read():
#    global flag
    global Elements
    flag=65
    if(uart.any()>0):         #如果接收到数据
        flag = uart.readchar()
        if flag==65:
            Elements[1]=(0,50,10,25)
            Elements[2]=(0,50,10,25)
        elif flag==66:
            Elements[1]=(0,50,10,25)
            Elements[2]=(0,50,10,25)
        elif flag==67:
            Elements[1]=(0,50,10,25)
            Elements[2]=(0,50,10,25)
'''


#终端打印函数：
def UART_Out(Line, Element, rho, turn_stops):
    #【1】将标记的赛道元素转化10进制数
    if len(Line)<2: Element[4] = 0
    else          : Element[4] = 1
    Element_num = Element[0]*32+Element[1]*16+Element[2]*8+Element[3]*4+Element[4]*2+Element[5]*1
    #print("rho=", rho, "Element_num=", Element_num)     #终端打印
    print(Element)

    #【2】串口发送：
    data = bytearray([0xb3, 0xb3, rho, Element_num, turn_stops, 0x5b]) #帧头 + 帧头 + 循迹值 + 赛道元素+ 帧尾
    usart1.write(data)



###########################################  主函数  ################################################
while(True):
    #【1】处理：
    img = sensor.snapshot().lens_corr(1.8)     #拍照,畸变矫正1.8
    Line = getLine(img)                        #从图像中得到赛道rho
    Element = getElement(img)                  #从图像中得到赛道元素
    #Mark(Line, Element)                        #进行标记
    #print(Element_data)

    #【2】输出：
    #lcd.display(img)                    #lcd显示
    UART_Out(Line, Element_data, line_rho, turn_stop)         #输出
