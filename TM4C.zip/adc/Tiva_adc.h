#ifndef _TIVA_ADC_H
#define _TIVA_ADC_H

#include "system.h"

extern uint32_t adc_FIFO_buf[8];
extern float power,sum;
extern uint8_t adc_interrupt;
extern uint32_t adc_data_buf[1];

void Power_Handler(void);
void ADC0_Init(void);
void Power_Init(void);
unsigned long ADC_ValueGet(uint32_t ui32Base, uint32_t ui32SequenceNum);
unsigned long ADC_ValueGet_S(uint32_t ui32Base, uint32_t ui32SequenceNum);

#endif

