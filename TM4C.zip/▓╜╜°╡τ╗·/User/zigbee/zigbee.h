#ifndef _ZIGBEE_H
#define _ZIGBEE_H

#include "system.h"

//#define  YKQ

#if defined(YKQ)
#define   ZIGBEE_DATA_SIZE 11
#else
#define   ZIGBEE_DATA_SIZE 3
#endif

extern uint8_t zigbee_data;

void UART5_Handler(void);
void Zigbee_Init(void);
void PulseToRocker(int32_t buff);
void DataWriteCHE(uint8_t k);

#endif


