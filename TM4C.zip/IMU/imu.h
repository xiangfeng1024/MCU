#ifndef _IMU_H
#define _IMU_H

#include "system.h"

#define IMU_DATA_SIZE  28

extern float IMU_Roll,
						 IMU_Pitch,
						 IMU_Yaw;

extern float IMU_Gyrox,
						 IMU_Gyroy,
						 IMU_Gyroz;

void UART7_Init(uint32_t baud);
void UART7_Handler(void);
void IMU_Init(void);
	
#endif

