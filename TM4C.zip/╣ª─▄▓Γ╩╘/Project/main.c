/*******************************************
//EK-TM4C123GH6PM
//���ܲ���
//2023���������
//�����ߣ���˫
//��������:2023/7/25
*******************************************/
#include "system.h"

int32_t PulseCnt=0;

int main(void)
{
	System_Clock_Init();  		//========����ϵͳʱ��Ϊ80MHz
	led_Init();								//========��ʼ��LED
	Key_Init();								//========��ʼ������
	Beep_Init();
	NVIC_IntPriority();				//========�ж����ȼ�����
//	EXTI_Init();							//========�ⲿ�жϳ�ʼ��
	OLED_Init();							//========OLED��ʼ��
	Motor_Init();
	Encoder_Init();
	K210_Init();
	Openmv_Init();
	IMU_Init();
	Zigbee_Init();
	Power_Init();

	while(KEY1);
//	OLED_Write(0,0,16,"ADC:%d",(int)((((double)(ADC_ValueGet(ADC0_BASE,ADC_CTL_CH1))/4096*3.3)*100)*5.28636));
//	PulseToRocker(-40000);
//	Motor_Write(7500,7500);
//	while(KEY2);
//	Motor_Write(3000,3000);
//	while(KEY3);
//	Motor_Write(1000,1000);
	
	
	while(1)
	{
		if(zigbee_data==0x01) 
		{
			Motor_Write(-7900,-7900);
		}
		
		if(zigbee_data==0x02) 
		{
			Motor_Write(-7900,7900);
		}
		
		if(zigbee_data==0x03) 
		{
			Motor_Write(7900,-7900);
		}
		
		if(zigbee_data==0x04) 
		{
			Motor_Write(7900,7900);
		}
		if(zigbee_data==0x00)
		{
			Motor_Write(0,0);
		}
		PulseCnt+=Encoder_Read(1);
		PulseToRocker(PulseCnt);
//		OLED_Write(0,4,16,"zigbee:%d",zigbee_data);
//		OLED_Write(0,0,16,"L:%d",Encoder_Read(0));
//		OLED_Write(0,2,16,"R:%d",Encoder_Read(1));
		delay_ms(50);
//		OLED_Write(0,0,8,"Roll:%d",(int)IMU_Roll);
//		OLED_Write(0,1,8,"Pitch:%d",(int)IMU_Pitch);
//		OLED_Write(0,2,8,"Yaw:%d",(int)IMU_Yaw);
//		
//		OLED_Write(0,4,8,"Gyrox:%d",IMU_Gyrox);
//		OLED_Write(0,5,8,"Gyroy:%d",IMU_Gyroy);
//		OLED_Write(0,6,8,"Gyroz:%d",IMU_Gyroz);
		
	}
}

