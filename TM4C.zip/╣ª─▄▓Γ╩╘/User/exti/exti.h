#ifndef _EXTI_H
#define _EXTI_H

#include "system.h"

void EXTI_Init(void);
void GPIO_KEY_Handler(void);

#endif

