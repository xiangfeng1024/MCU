#ifndef _USART_K210_H
#define _USART_K210_H

#include "system.h"  

/****************************�궨��*****************************/ 
#define K210_DATA_SIZE  6


extern uint8_t k210_data;

/****************************��������***************************/ 
void K210_Init(void);
void UART0_Handler(void);

#endif



