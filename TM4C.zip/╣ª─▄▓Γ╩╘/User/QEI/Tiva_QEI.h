#ifndef _TIVA_QEI_H
#define _TIVA_QEI_H

#include "system.h"

void QEI0_Init(void);
void QEI1_Init(void);
void Encoder_Init(void);
int32_t Encoder_Read(uint8_t x);
#endif

