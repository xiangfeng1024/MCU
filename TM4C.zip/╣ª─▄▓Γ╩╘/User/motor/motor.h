#ifndef _MOTOR_H
#define _MOTOR_H

#include "system.h"

#define  IN1_1  GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_0,0)
#define  IN1_0  GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_0,GPIO_PIN_0)

#define  IN2_1  GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_2,0)
#define  IN2_0  GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_2,GPIO_PIN_2)

#define  IN3_1  GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_5,0)
#define  IN3_0  GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_5,GPIO_PIN_5)

#define  IN4_1  GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_7,0)
#define  IN4_0  GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_7,GPIO_PIN_7)

void PWM0_G0_Init(uint32_t period);
void PWM0_G3_Init(uint32_t period);
void PWM0_G1_Init(uint32_t period);
void Motor_Init(void);
int Fabs(int p);
void Motor_Write(int PWMA,int PWMB);
void MOTOR_STOP(void);

#endif

