#include "led.h"

void led_Init(void)
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);  														//ʹ��GPIOFʱ��
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3); //����GPIOΪ�������ģʽ
	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_1,0);																//GPIOF,PIN1д��͵�ƽ
	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_2,0);
	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_3,0);
	
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD); 
	GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_2|GPIO_PIN_3);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC); 
	GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_4|GPIO_PIN_7);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB); 
	GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_3);
	
	GPIOPinWrite(GPIO_PORTB_BASE,GPIO_PIN_3,GPIO_PIN_3);
	GPIOPinWrite(GPIO_PORTD_BASE,GPIO_PIN_2,GPIO_PIN_2);
	GPIOPinWrite(GPIO_PORTD_BASE,GPIO_PIN_3,GPIO_PIN_3);
	GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_4,GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTC_BASE,GPIO_PIN_7,GPIO_PIN_7);
	
}

void Beep_Init(void)
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA); 
}

void Beep_Write(uint8_t x)
{
	GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_6,0);	
	delay_ms(x*100);
	GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_6);
}

