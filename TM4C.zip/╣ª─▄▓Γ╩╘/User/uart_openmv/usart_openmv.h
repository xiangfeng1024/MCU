#ifndef _USART_OPENMV_H
#define _USART_OPENMV_H

#include "system.h"

#define 	Openmv_DATA_SIZE  4

extern uint8_t OpenmvData;

void Openmv_Init(void);
void UART1_Handler(void);

#endif

