#include "led.h"

void led_Init(void)
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);  														//ʹ��GPIOFʱ��
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3); //����GPIOΪ�������ģʽ
	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_1,0);																//GPIOF,PIN1д��͵�ƽ
	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_2,0);
	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_3,0);
	
//	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_1,GPIO_PIN_1);											//GPIOF,PIN1д��ߵ�ƽ
//	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_2,GPIO_PIN_2);
//	GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_3,GPIO_PIN_3);
	
//	GPIOPinRead(GPIO_PORTF_BASE,GPIO_PIN_1);																	//����GPIO��ƽ
}

void Beep_Init(void)
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA); 
	GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_6,GPIO_PIN_6);	
}

void Beep_Write(uint8_t x)
{
	GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_6,0);	
	delay_ms(x*100);
	GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_6);
}

