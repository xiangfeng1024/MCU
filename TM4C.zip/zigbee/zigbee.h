#ifndef _ZIGBEE_H
#define _ZIGBEE_H

#include "system.h"

#define   ZIGBEE_DATA_SIZE 11

extern int zigbee_data;

void UART5_Handler(void);
void Zigbee_Init(void);

#endif


