#ifndef __ENCODER_h
#define __ENCODER_h

#include "driverlib.h"

void Encoder_Init(void);
s16 Encoder_Read(int x);

#endif

