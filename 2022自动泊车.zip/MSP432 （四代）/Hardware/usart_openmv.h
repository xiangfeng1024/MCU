#ifndef __USART_OPENMV_h
#define __USART_OPENMV_h

#include "driverlib.h"

#define 	Openmv_DATA_SIZE  5

extern u8 line_rho,line_rho2;
extern u8 Stop_openmv_1,Stop_openmv_2,Stop_openmv_3,Stop_openmv_4;
extern u8 clock_fps;

void usart_openmv_Init(uint32_t baudRate);
void Openmv_Init(void);


#endif
