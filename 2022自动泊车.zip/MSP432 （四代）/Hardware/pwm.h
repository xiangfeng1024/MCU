#ifndef __PWM_H
#define __PWM_H

#include "driverlib.h"

void TimA0_PWM_Init(void);
void TimA1_PWM_Init(uint16_t ccr0, uint16_t psc);
//void TimA0_PWM_Init(uint16_t ccr0, uint16_t psc);
	
#endif

