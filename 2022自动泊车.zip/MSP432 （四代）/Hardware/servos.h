#ifndef __SERVOS_H
#define __SERVOS_H

#include "driverlib.h"

#define Right_max   1100   //1180
#define Left_max  	1670  //
#define Median  		1410  //1450

void Servos_Init(void);
void Servos_Set(uint8_t xh, uint16_t out);
void Servos_Limit(uint16_t *PWMA);

#endif

