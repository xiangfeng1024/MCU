#include "sensor.h"

int SENSOR_DATA[8]={0};
int line_data=0;

void sensor_Init(void)
{
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P3, GPIO_PIN7); 
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P3, GPIO_PIN6);  
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P3, GPIO_PIN5); 
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P2, GPIO_PIN7); 
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN6); 
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P2, GPIO_PIN3); 
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4, GPIO_PIN7); 
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN5);  
}

void Sensor_Get(void)
{
	SENSOR_DATA[0] = HW1;
	SENSOR_DATA[1] = HW2;
	SENSOR_DATA[2] = HW3;
	SENSOR_DATA[3] = HW4;
	SENSOR_DATA[4] = HW5;
	SENSOR_DATA[5] = HW11;
	SENSOR_DATA[6] = HW12;
	SENSOR_DATA[7] = HW13;
}

void Sensor_line(void)
{
//	static int line_data_last=0;
	if(SENSOR_DATA[3]==0) 		 line_data=-2;
	else if(SENSOR_DATA[1]==0) line_data=2;
	else line_data=0;
//	line_data_last=line_data;
//	if(SENSOR_DATA[3]==1 & SENSOR_DATA[1]==1 & line_data_last==-2) line_data=1;
//	else if(SENSOR_DATA[3]==1 & SENSOR_DATA[1]==1 & line_data_last==2) line_data=-1;
}

u8 Sensor_Element_Process(void)
{
	u8 da=0;
	da=(SENSOR_DATA[0] << 4) | (SENSOR_DATA[4] << 3) | (SENSOR_DATA[5] << 2) | (SENSOR_DATA[6] << 1) | SENSOR_DATA[7];
//	OLED_Write(0,4,16,"TYPE:%d",da);
	switch(da)
	{
		case 0x1f:da=0;break;  		//====== 11111  " �� " ����ͬ
		case 0x0f:da=1;break;     //====== 01111  " �� " ����
		case 0x17:da=2;break;     //====== 10111  " �� " ����
		case 0x07:da=3;break;     //====== 00111  " �� " T��·
		case 0x05:da=4;break;     //====== 00101  " �� " ʮ��·
		case 0x0d:da=5;break;     //====== 01101  " �� " ��T��·
		case 0x15:da=6;break;     //====== 10101  " �� " ��T��·
		case 0x00:da=7;break;     //====== 00000  " �� " �յ�
		default: da=8;
	}
	return da;  //����
}

u8 Sensor_Count_Process(void)
{
	u8 da=0;
	da=(SENSOR_DATA[0] << 4) | (SENSOR_DATA[4] << 3) | (SENSOR_DATA[5] << 2) | (SENSOR_DATA[6] << 1) | SENSOR_DATA[7];
	switch(da)
	{
		case 0x1f:da=0;break;  		//====== 11111  " �� " ����ͬ
		case 0x0f:da=0;break;     //====== 01111  " �� " ����
		case 0x17:da=0;break;     //====== 10111  " �� " ����
		case 0x07:da=1;break;     //====== 00111  " �� " T��·  ����Ϊ����ͬ
		case 0x05:da=2;break;     //====== 00101  " �� " ʮ��·
		case 0x0d:da=1;break;     //====== 01101  " �� " ��T��·
		case 0x15:da=1;break;     //====== 10101  " �� " ��T��·
		case 0x00:da=0;break;     //====== 00000  " �� " �յ�
		default: da=8;
	}
	return da;  //����
}

void Sensor_EXTI_Init(void)
{
	GPIO_clearInterruptFlag(GPIO_PORT_P3, GPIO_PIN7);
	GPIO_clearInterruptFlag(GPIO_PORT_P3, GPIO_PIN5);
	GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN6);
	
	GPIO_interruptEdgeSelect(GPIO_PORT_P3,GPIO_PIN7,GPIO_HIGH_TO_LOW_TRANSITION);
	GPIO_interruptEdgeSelect(GPIO_PORT_P3,GPIO_PIN5,GPIO_LOW_TO_HIGH_TRANSITION);
	GPIO_interruptEdgeSelect(GPIO_PORT_P1,GPIO_PIN6,GPIO_HIGH_TO_LOW_TRANSITION);
	
	GPIO_enableInterrupt(GPIO_PORT_P3, GPIO_PIN7);
	GPIO_enableInterrupt(GPIO_PORT_P3, GPIO_PIN5);
	GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN6);
	
	Interrupt_enableInterrupt(INT_PORT3);
	Interrupt_enableInterrupt(INT_PORT1);
}

void Interrupt_NVIC_Config(void)
{
	//���������ȼ�
	//�ж����ȼ�ֻ��ȡ��3λ������5λ
	Interrupt_setPriority(INT_TA1_0,1<<5);	//��ʱ��������Ѳ��
	Interrupt_setPriority(INT_PORT1,2<<5);  //�����������ȼ�
	Interrupt_setPriority(INT_PORT3,3<<5);  //�Һ���
	Interrupt_setPriority(INT_PORT4,4<<5);	//������
	Interrupt_setPriority(INT_TA2_0,5<<5);	//��ʱ��������Ѳ��
}


