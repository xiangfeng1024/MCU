#ifndef __TIMER_h
#define __TIMER_h

#include "driverlib.h"

void TimA2_Init(uint16_t ccr0, uint16_t psc);
#endif
