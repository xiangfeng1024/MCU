#ifndef __SENSOR_h
#define __SENSOR_h

#include "driverlib.h"

#define HW1   GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN7)
#define HW2   GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN6)
#define HW3   GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN5)
#define HW4   GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN7)
#define HW5   GPIO_getInputPinValue(GPIO_PORT_P1, GPIO_PIN6)

#define HW11  GPIO_getInputPinValue(GPIO_PORT_P2, GPIO_PIN3)
#define HW12  GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN7)
#define HW13  GPIO_getInputPinValue(GPIO_PORT_P1, GPIO_PIN5)

void sensor_Init(void);
void Sensor_Get(void);
void Sensor_EXTI_Init(void);
void Interrupt_NVIC_Config(void);
u8 Sensor_Element_Process(void);
u8 Sensor_Count_Process(void);
void Sensor_line(void);

extern int SENSOR_DATA[8],
					line_data;

#endif

