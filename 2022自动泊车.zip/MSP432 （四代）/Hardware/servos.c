#include "servos.h"

int SERVOS_MAX=2300,SERVOS_MIN=700;

void Servos_Init(void)
{
	TimA0_PWM_Init();  //50Hz  PWM���
}

void Servos_Set(uint8_t xh, uint16_t out)
{
	Servos_Limit(&out);
	switch(xh)
	{
		case 0:Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,out);break;
		case 1:Timer_A_setCompareValue(TIMER_A0_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_3,out);break;
	}
}

/*�޷�����*/
void Servos_Limit(uint16_t *PWMA)
{
	if(*PWMA>SERVOS_MAX) *PWMA = SERVOS_MAX;
	if(*PWMA<SERVOS_MIN) *PWMA = SERVOS_MIN;
}

