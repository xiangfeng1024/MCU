##############################################################
# 2023年电赛训练  自动泊车系统
# 创建者：周双
# 创建时间：2023.5.15
######################################.########################
import sensor, image, time, lcd, math, time
from pyb import UART
from pyb import LED

usart3=UART(3,115200)
usart3.init(115200, bits=8, parity=None, stop=1) #初始化串口

#关闭补光灯防止地面反光
LED(1).off()
LED(2).off()
LED(3).off()

sensor.reset()
sensor.set_pixformat(sensor.GRAYSCALE)  #灰度图
sensor.set_framesize(sensor.QQVGA)      #160*120
#sensor.set_auto_gain(False)             #颜色跟踪必须关闭自动增益
#sensor.set_auto_whitebal(False)         #颜色跟踪必须关闭白平衡
sensor.skip_frames(time = 3000)         #跳过3秒等待感光元件设置生效
#lcd.init()                              #初始化lcd
clock = time.clock()

Mode_dir = 1


#循迹黑色色块阈值：
black = (0,64)                     #循迹黑色赛道阈值
black1 = (0,84)
black_roi = [(0, 35, 90, 50),
             (0, 65, 90, 30)]

#停止标志
Stop_data = [0,0,0,0]
Stop_roi = [(60 , 0, 45, 20),
            (25, 5, 20, 30),
            (130, 0, 15, 20),
            (0, 50, 12, 12)]

'''
Stop_roi = [(20 , 0, 15, 30),
            (30, 5, 20, 30),
            (130, 0, 15, 20),
            (0, 50, 12, 12)]
'''

Stop_roi1 = [(21, 0, 15, 30),
            (30, 5, 20, 30),
            (110, 55, 15, 15),
            (0, 28, 12, 12)]

#得到巡线数字量函数：
def getLine(img):
    line_blob0 = img.find_blobs([black], roi=black_roi[0], x_stride=12, area_threshold=200, merge=True)

    return line_blob0

#得到巡线数字量函数：
def getLine1(img):
    line_blob1 = img.find_blobs([black], roi=black_roi[1], x_stride=12, area_threshold=200, merge=True)

    return line_blob1


#得到停车标志函数：
def getStop(img):
    global Stop_data
    global Mode_dir
    Stop_blobs=[]
    Stop_data = [0,0,0,0]
    Stop_blob0 = img.find_blobs([black], roi=Stop_roi[0], area_threshold=70, merge=True)
    if Stop_blob0:
        Stop_data[0]=1
        Stop_blobs.append(Stop_blob0[0])

    Stop_blob1 = img.find_blobs([black1], roi=Stop_roi[1], area_threshold=20, merge=True)
    if Stop_blob1:
        Stop_data[1]=1
        Stop_blobs.append(Stop_blob1[0])

    Stop_blob2 = img.find_blobs([black], roi=Stop_roi[2], area_threshold=20, merge=True)
    if Stop_blob2:
        Stop_data[2]=1
        Stop_blobs.append(Stop_blob2[0])

    Stop_blob3 = img.find_blobs([black], roi=Stop_roi[3], area_threshold=70, merge=True)
    if Stop_blob3:
        Stop_data[3]=1
        Stop_blobs.append(Stop_blob3[0])
    return Stop_blobs

#得到停车标志函数：
def getStop1(img):
    global Stop_data
    Stop_blobs=[]
    Stop_data = [0,0,0,0]
    Stop_blob0 = img.find_blobs([black], roi=Stop_roi1[0], area_threshold=70, merge=True)
    if Stop_blob0:
        Stop_data[0]=1
        Stop_blobs.append(Stop_blob0[0])

    Stop_blob1 = img.find_blobs([black1], roi=Stop_roi1[1], area_threshold=20, merge=True)
    if Stop_blob1:
        Stop_data[1]=1
        Stop_blobs.append(Stop_blob1[0])

    Stop_blob2 = img.find_blobs([black], roi=Stop_roi1[2], area_threshold=20, merge=True)
    if Stop_blob2:
        Stop_data[2]=1
        Stop_blobs.append(Stop_blob2[0])

    Stop_blob3 = img.find_blobs([black], roi=Stop_roi1[3], area_threshold=70, merge=True)
    if Stop_blob3:
        Stop_data[3]=1
        Stop_blobs.append(Stop_blob3[0])
    return Stop_blobs


#标记函数：
def Mark(Line, Stop):
    #【1】标记巡线：
    for blob in Line:
        img.draw_rectangle(blob.rect(), color=(255,255,255))        #圈出巡线区块
        img.draw_cross(blob.cx(), blob.cy(),color=(255,255,255))    #圈出中心十字

    #【2】标记停车：
    for blob in Stop:
        img.draw_rectangle(blob.rect(), color=(255,255,255))        #圈出巡线区块
        img.draw_cross(blob.cx(), blob.cy(),color=(255,255,255))    #圈出中心十字




#串口接收函数
def UART_Read(uart):
    global Mode_dir
    if(uart.any()>0):         #如果接收到数据
        Mode_dir = uart.readchar()


#终端打印函数：
def UART_Out(Line, Stop):
    line_data1 = 0
    #【1】将循迹值返回
    if Line:
        line_data1 = Line[0].cy()

    #【2】将停车标志转化为10进制：
    Stop_num = Stop[0]*8+Stop[1]*4+Stop[2]*2+Stop[3]*1

    #【3】串口发送：
    data = bytearray([0xb3, 0xb3, line_data1, Stop_num, 0x5b]) #帧头 + 帧头 + 循迹值 + 赛道元素+ 帧尾
    usart3.write(data)


###########################################  主函数  ################################################
while(True):
#    clock.tick()
    #【1】处理：
    img = sensor.snapshot().lens_corr(1.8).mean(1)    #拍照,畸变矫正1.8
    Line = getLine(img)                        #从图像中得到赛道rho
#    Line1 = getLine1(img)                        #从图像中得到赛道rho
    if Mode_dir==1:
        Stop = getStop(img)
    else :
        Stop = getStop1(img)
    UART_Read(usart3)
 #   Mark(Line, Stop)                        #进行标记
    #print(Stop_data)

    #【2】输出：
#    lcd.display(img)                    #lcd显示
#    print(clock.fps())
    UART_Out(Line, Stop_data)         #输出
