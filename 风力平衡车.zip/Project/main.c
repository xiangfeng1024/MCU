/*******************************************
*EK-TM4C123GH6PM
*11.С��ģ�����
*2023���������
*�����ߣ���˫
*��������:2023/5/29
*******************************************/
#include "system.h"

extern int   UpMotorPowerPwmOut;

extern float AngHope,YawHope;

int main(void)
{
	System_Clock_Init();  		//========����ϵͳʱ��Ϊ80MHz
	led_Init();								//========��ʼ��LED
	Key_Init();								//========��ʼ������
	NVIC_IntPriority();				//========�ж����ȼ�����
	OLED_Init();							//========OLED��ʼ��
//	UART1_Init(115200);				//========����1��ʼ��
	Motor_Init();							//========�����ʼ��
	PID_Init();
	Zigbee_Init();
//	Beep_Write(5);
	IMU_Init();
	
	
//	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);
	OLED_Write(0,0,16,"ok");
	OLED_Write(0,2,16,"Yaw:");
	while(KEY2)
	{
		OLED_float(40,2,IMU_Yaw);
	}
	Control_Init();
	OLED_Write(0,2,16,"Yaw:");
	while(!zigbee_data)
	{
		YawHope = IMU_Yaw;
		OLED_float(40,2,IMU_Yaw);
	}
	
	while(1)
	{
		delay_ms(50);
		OLED_Write(0,0,16,"Up:%d",(int)UpMotorPowerPwmOut);
//		OLED_Write(0,2,16,"Yaw:");
		OLED_float(40,2,IMU_Yaw);
		if(zigbee_data==0x01) 
		{
			while(1)
			{
				delay_ms(50);
				if(zigbee_data==0x01)
				{
					UpMotorPowerPwmOut+=50;
//					AngHope = SetRollHopeOut(UpMotorPowerPwmOut);
				}
				if(zigbee_data==0x00) break;
			}
		}
		if(zigbee_data==0x04)
		{
			while(1)
			{

				delay_ms(50);
				if(zigbee_data==0x04)
				{
					UpMotorPowerPwmOut-=50;
				}
				if(zigbee_data==0x00) break;
			}
		}
		
		if(zigbee_data==0x06)
		{
			TimerDisable(TIMER0_BASE, TIMER_A);
			Motor_Write(MotorModeUp, 0, 0);
			Motor_Write(MotorModeTurn, 0, 0);
			while(1);
		}
		
		
//		OLED_Write(0,0,16,"%d",Encoder_Read(0));
		
//		OLED_Write(0,0,16,"%d",(int)(IMU_Roll*100));
//		OLED_Write(0,2,16,"%d",(int)(IMU_Pitch*100));
//		OLED_Write(0,4,16,"%d",(int)(IMU_Yaw*100));
	}
}

