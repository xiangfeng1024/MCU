#ifndef _SYSTEM_H
#define _SYSTEM_H

#include "inc/tm4c123gh6pm.h"				//Register Definitions
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "inc/hw_nvic.h"
//#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "driverlib/rom.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom_map.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "driverlib/cpu.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/pwm.h"
#include "driverlib/qei.h"
#include "timer.h"
#include "uartstdio.h"

#include "delay.h"

#include "led.h"
#include "key.h"
#include "oled.h"
#include "usart.h"
#include "Tiva_pwm.h"
#include "motor.h"
#include "imu.h"
#include "pid.h"
#include "control.h"
#include "zigbee.h"



typedef int32_t  s32;
typedef int16_t s16;
typedef int8_t  s8;

typedef uint32_t  u32;
typedef uint16_t u16;
typedef uint8_t  u8;


void System_Clock_Init(void);
void NVIC_IntPriority(void);

#endif

