#ifndef _DELAY_H
#define _DELAY_H

#include "system.h"

void delay_us(uint16_t i);
void delay_ms(uint16_t i);
void delay_s(uint8_t i);

#endif

