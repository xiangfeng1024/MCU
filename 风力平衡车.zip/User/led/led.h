#ifndef _LED_H
#define _LED_H

#include "system.h"

void led_Init(void);

#define LED1_ON  GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_1,GPIO_PIN_1)
#define LED1_OFF GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_1,0)
#define LED2_ON  GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_2,GPIO_PIN_2)
#define LED2_OFF GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_2,0)
#define LED3_ON  GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_3,GPIO_PIN_3)
#define LED3_OFF GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_3,0)

void Beep_Write(uint8_t x);
void Beep_Init(void);

#endif

