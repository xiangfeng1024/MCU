#ifndef _TIM_H
#define _TIM_H

#include "system.h"

extern uint32_t v;


void Timer0_Init(uint16_t arr);
void Timer0_WID_Init(uint16_t arr);
void TIMER0_IRQHandler(void);
void TIMER0_WID_IRQHandler(void);
	
#endif

