#ifndef _KEY_H
#define _KEY_H

#include "system.h"

#define  KEY1  GPIOPinRead(GPIO_PORTF_BASE,GPIO_PIN_4)
#define  KEY2  GPIOPinRead(GPIO_PORTF_BASE,GPIO_PIN_0)

#define  KEY3  GPIOPinRead(GPIO_PORTA_BASE,GPIO_PIN_2)
#define  KEY4  GPIOPinRead(GPIO_PORTE_BASE,GPIO_PIN_3)

void Key_Init(void);

#endif

