#ifndef _CONTROL_H
#define _CONTROL_H

#include "system.h"

void Control_Init(void);
void Timer0_Init(uint16_t arr);
void TIMER0_IRQHandler(void);
float YawCrlOut(float hope, float now);
float SetRollHopeOut(uint16_t Up);
	
#endif

