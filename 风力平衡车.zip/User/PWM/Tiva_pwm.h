#ifndef _TIVA_PWM_H
#define _TIVA_PWM_H

#include "system.h"

//void PWM0_G3_Init(uint32_t period);
//void PWM1_G2_Init(uint32_t period);
//void PWM_Set(uint32_t PWMx, uint32_t Gx, uint32_t pulse);

#endif

