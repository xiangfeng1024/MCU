#ifndef _ZIGBEE_H
#define _ZIGBEE_H

#include "system.h"

extern int zigbee_data;

#define   ZIGBEE_DATA_SIZE 11

void UART5_Handler(void);
void Zigbee_Init(void);

#endif


