#ifndef _PID_H
#define _PID_H

#include "system.h"

struct PID
{
	float kp;
	float ki;
	float kd;
	
	float err;
	float err_last;
	float err_last_dev;
	float err_last_dev_last;
	float err_last_dev_lastdev;
	float err_add;
	float err_add_limit;
	
	float ki_p;
	
	float out;
	float out_limit;
};

void PID_Init(void);
float Erect_pid(struct PID* para,float hope, float now);
float Erect_pid2(struct PID* para,float err, float err_v);
float Increment_pid(struct PID* para,float hope,float now);

#endif


