#ifndef _usart_H
#define _usart_H

#include "system.h" 
#include "stdio.h" 


void Usart1_Init(u32 bound);


#endif


