#ifndef _pid_h
#define _pid_h

#include <system.h>

int PID_Vertical(float Med,float roll,int Vroll);
float PID_Velocity(int encoder);

#endif
