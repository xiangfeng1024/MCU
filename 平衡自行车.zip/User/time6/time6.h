#ifndef _time6_H
#define _time6_H

#include <system.h>

void Stop(float *Med_Jiaodu,float *Jiaodu);
	
#endif
