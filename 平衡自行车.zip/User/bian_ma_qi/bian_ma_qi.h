#ifndef _BIAN_MA_QI_H_
#define _BIAN_MA_QI_H_

#include "stm32f10x.h"

int du_qu_Speed(int TIMx);
void bian_ma_qi_TIM4_Init(void);
int Read_Encoder_TIM4(void);

#endif


