#ifndef __ADC_H
#define __ADC_H	
#include "system.h"

void adc_Init(void);
u16 Get_adc(u8 chn);
u16 Get_adc_Average(u8 chn, u8 times);

#endif
