#ifndef __IIC_H_
#define __IIC_H_

#include "stm32f10x.h"
#include "system.h"

#define SCL              PBout(12)
#define SDA              PBout(13)

void xie(uint8_t add,uint8_t dat);
uint8_t ACK(void);
void fasong(uint8_t dat);
void zhongzhi(void);
void kaishi(void);
static void Delay10us(void);
void iic_GPIO_OLED(void);
void IIC_Delay(void);
	
#endif

