#include "caidan.h"
#include "oled.h"

uint8_t time[10] = {77,78,79,80,81,82,83,84,85,86};


void bian_ma_qi_OLED(int a)
{
	int a1,a2,a3,a4,a5,a6,a7;
//	int b1,b2,b3,b4,b5,b6,b7;
	
	if(a<0) a = -a;
//	if(b<0) b = -b;
	a1 = (int)(a/1000000);
	a2 = (int)(a/100000%10);
	a3 = (int)(a/10000%10);
	a4 = (int)(a/1000%10);
	a5 = (int)(a/100%10);
	a6 = (int)(a/10%10);
	a7 = (int)(a%10);
	
//	b1 = (int)(b/1000000);
//	b2 = (int)(b/100000%10);
//	b3 = (int)(b/10000%10);
//	b4 = (int)(b/1000%10);
//	b5 = (int)(b/100%10);
//	b6 = (int)(b/10%10);
//	b7 = (int)(b%10);
	
	LED_Chinese(20,3,time[a1]);
	LED_Chinese(28,3,time[a2]);
	LED_Chinese(36,3,time[a3]);
	LED_Chinese(44,3,time[a4]);
	LED_Chinese(52,3,time[a5]);
	LED_Chinese(60,3,time[a6]);
	LED_Chinese(68,3,time[a7]);
	
//	LED_Chinese(20,5,time[b1]);
//	LED_Chinese(28,5,time[b2]);
//	LED_Chinese(36,5,time[b3]);
//	LED_Chinese(44,5,time[b4]);
//	LED_Chinese(52,5,time[b5]);
//	LED_Chinese(60,5,time[b6]);
//	LED_Chinese(68,5,time[b7]);
}

void Pitch_OLED(int a)
{
	int a1,a2,a3,a4;
//	int a4,a5,a6,a7;
//	a=a/10;
	if(a>=0) LED_Chinese(12,3,118);
	else    {LED_Chinese(12,3,76);a=-a;}
	a1 = (a/1000);
	a2 = (a/100%10);
	a3 = (a/10%10);
	
	a4 = (a%10);
//	a5 = (a%10);
//	a6 = (int)(Pitch/10%10);
//	a7 = (int)(Pitch%10);
	
	LED_Chinese(20,3,time[a1]);
	LED_Chinese(28,3,time[a2]);
	LED_Chinese(36,3,time[a3]);
	LED_Chinese(44,3,24);
	LED_Chinese(52,3,time[a4]);
//	LED_Chinese(44,3,24);
//	LED_Chinese(52,3,time[a5]);
//	LED_Chinese(52,3,time[a5]);
//	LED_Chinese(60,3,time[a5]);
//	LED_Chinese(68,3,time[a7]);
}

void ADC_OLED(float a)
{
	int a1,a2,a3;
	int a4,a5;
	int b=0;
	b=(int)(a*1000000);
	if(a>=0) LED_Chinese(12,5,118);
	else     {LED_Chinese(12,5,76);a=-a;}
	a1 = (b/10000000);
	a2 = (b/1000000%10);
	a3 = (b/100000%10);
	
	a4 = (b/10000%10);
	a5 = (b/1000%10);
	
	LED_Chinese(20,5,time[a1]);
	LED_Chinese(28,5,24);
	LED_Chinese(36,5,time[a2]);
	LED_Chinese(44,5,time[a3]);
//	LED_Chinese(44,5,time[a4]);
//	LED_Chinese(44,5,24);
	LED_Chinese(52,5,time[a4]);
	LED_Chinese(60,5,time[a5]);
}

