#ifndef __CAIDAN_H_
#define __CAIDAN_H_

#include "stm32f10x.h"

	
void bian_ma_qi_OLED(int a);
void Pitch_OLED(int a);
void ADC_OLED(float a);
//void Pitch_OLED(float a);

#endif

