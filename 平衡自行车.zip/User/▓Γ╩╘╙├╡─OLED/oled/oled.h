#ifndef __OLED_H_
#define __OLED_H_

#include "stm32f10x.h"

void delay(uint32_t i);
void LED_BMP(uint8_t BMP[]);
void LED_Chinese(uint8_t x,uint8_t y,uint8_t z);
void LEDxy(uint8_t x,uint8_t y);
void OLED(void);
void qing_pin(void);
void OLED_xiesj(uint8_t dat);
void OLED_xieml(uint8_t dat);
void LED_shu_zi(uint8_t x,uint8_t y,uint8_t num,uint8_t len,uint8_t size2);
void LED_char(uint8_t x,uint8_t y,uint8_t chr,uint8_t chr_size);

#endif

