#ifndef __LED_H_
#define __LED_H_

#include "stm32f10x.h"

//�̵�
#define LED1_GPIO_PIN                GPIO_Pin_0
#define LED1_GPIO_PORT               GPIOB
#define LED1_GPIO_CLK                RCC_APB2Periph_GPIOB

//����
#define LED2_GPIO_PIN                GPIO_Pin_1
#define LED2_GPIO_PORT               GPIOB
#define LED2_GPIO_CLK                RCC_APB2Periph_GPIOB

//���
#define LED3_GPIO_PIN                GPIO_Pin_5
#define LED3_GPIO_PORT               GPIOB
#define LED3_GPIO_CLK                RCC_APB2Periph_GPIOB


#define LED_zhuang1         {LED1_GPIO_PORT->ODR ^= LED1_GPIO_PIN;}
#define LED_zhuang2         {LED2_GPIO_PORT->ODR ^= LED2_GPIO_PIN;}
#define LED_zhuang3         {LED3_GPIO_PORT->ODR ^= LED3_GPIO_PIN;}

#define GPIOB_ODR_Addr             (GPIOB_BASE+12) 
#define GPIOA_IDR_Addr             (GPIOA_BASE+8) 
#define GPIOA_ODR_Addr             (GPIOA_BASE+12) 
#define GPIOC_IDR_Addr             (GPIOC_BASE+8)  
#define GPIOC_ODR_Addr             (GPIOC_BASE+12)  

#define GB1(n)                      PP(GPIOB_ODR_Addr,n)    //ODR�����
#define GC1(n)                      PP(GPIOC_ODR_Addr,n)    //IDR�����
#define GA1(n)                      PP(GPIOA_ODR_Addr,n)    //ODR�����

#define GA2(n)                      PP(GPIOA_IDR_Addr,n)    //IDR������
#define GC2(n)                      PP(GPIOC_IDR_Addr,n)    //IDR������

#define LED1                       GB1(0)                 //��ɫ
#define LED2                       GB1(1)                 //��ɫ
#define LED3                       GB1(5)                 //��ɫ
#define LED4            {LED1 = 0,LED2 = 1,LED3 = 0;}    //��ɫ
#define LED5            {LED1 = 1,LED2 = 0,LED3 = 0;}    //��ɫ
#define LED6            {LED1 = 0,LED2 = 0,LED3 = 1;}    //��ɫ
#define LED7            {LED1 = 0,LED2 = 0,LED3 = 0;}    //��ɫ
#define LED0            {LED1 = 1,LED2 = 1,LED3 = 1;}    //����

#define PP(addr,n)                *(unsigned long *)((addr & 0xF0000000)+0x02000000+((addr & 0x00FFFFFF)<<5)+(n<<2)) 

void LED_GPIO(void);                      //LED��ʼ������

#endif

