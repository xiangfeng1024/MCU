#ifndef _TB6612_H_
#define _TB6612_H_

#include "stm32f10x.h"

#define GPIOC_ODR_Addr             (GPIOC_BASE+12) 
#define GPIOB_ODR_Addr             (GPIOB_BASE+12) 
#define PP(addr,n)                *(unsigned long *)((addr & 0xF0000000)+0x02000000+((addr & 0x00FFFFFF)<<5)+(n<<2)) 

#define GB1(n)                      PP(GPIOB_ODR_Addr,n)    //ODR�����
#define GC1(n)                      PP(GPIOC_ODR_Addr,n)    //ODR�����

#define zuo_lun1                    GC1(5)
#define zuo_lun2                    GC1(4)
#define you_lun1                    GB1(0)
#define you_lun2                    GB1(1)

extern int PWM_MAX;
extern int PWM_MIN;

void TB6612_Init(void);
void Load(int PWMA);
void Limit(int *PWMA);
int Fabs(int p);
void Angle(int *pwm,float y);


#endif


