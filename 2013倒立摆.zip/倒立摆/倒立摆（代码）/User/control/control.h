#ifndef _CONTROL_H
#define _CONTROL_H

#include "system.h"

#define GAN_High  2100			//��ߵ㣨��̬��
#define GAN_Low  70					//��͵㣨��̬�ɱ䣩

void TIM5_Init(u16 psc,u16 arr);
void Control_Init(void);
void Task1(void);
void Task2(void);
void Task3(void);
void Task6(void);

#endif

