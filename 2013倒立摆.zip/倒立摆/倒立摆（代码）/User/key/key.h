#ifndef _KEY_H
#define _KEY_H

#include "system.h"

#define KEY1      PAin(4) 
#define KEY2      PAin(5) 

void KEY_GPIO_Init(void);
void EXTIX_Init(void);

#endif


