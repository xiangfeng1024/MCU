#ifndef _MOTOR_H
#define _MOTOR_H

#include "system.h"
  
#define zuo_lun1        PBout(12)      //����1IO
#define zuo_lun2        PBout(14)      //����2IO

void Motor_GPIO_Init(void);
void PWM_Init_TIM4(uint16_t Psc,uint16_t arr);
void Motor_Init(void);
int Fabs(int p);
void Limit(int *PWMA);
void Motor_Write(int PWMA);
void Motor_Open(int Mode,int distance_hope,int dir);

#endif


