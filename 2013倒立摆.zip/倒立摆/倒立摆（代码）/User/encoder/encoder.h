#ifndef _ENCODER_H
#define _ENCODER_H

#include "system.h"

extern int distance_count,speed;

void Encoder_Init(void);
void Encoder_TIM8_Init(void);
int Encoder_Read(void);
void TIM6_Init(u16 psc,u16 arr);

#endif


