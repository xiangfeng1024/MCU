#ifndef _ADC_H
#define _ADC_H

#include "system.h"

extern uint32_t power_raw;
extern float power;

void ADC_GPIO_Init(void);
void ADC_Mode_Init(void);
void Power_Init(void);
void Power_Read(float* adc);
#endif


