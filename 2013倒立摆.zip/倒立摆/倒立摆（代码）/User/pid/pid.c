#include "pid.h"

struct PID Gan,Vel,pus;

/*
P  -23.5
D  -35
*/

/*
P  -14.5
D  -52

P	 -100
*/
void PID_Init(void)
{
	Gan.kp=-14.5;
	Gan.ki=0;//-0.007;
	Gan.kd=-52;
	
	Vel.kp=-100;
	Vel.ki=0;
	
//	pus.kp=-0.014;
	pus.kd=-0.54;
	pus.ki=0;
}

//λ��ʽֱ��PID
float Erect_pid(struct PID* para,int err, int err_v)
{
	if(err > 500)  err=500;
	if(err < -500) err=-500;
//	if(err>-5 && err<5) err=0;
	(*para).err = err;
	
	(*para).err_last_dev = (*para).err - (*para).err_last;
	
	(*para).out = (*para).kp*(*para).err + (*para).kd*(*para).err_last_dev + (*para).ki*(*para).err_add;
	
	(*para).err_last=(*para).err;
	
	if((*para).err < 35) (*para).err_add+=0.7*(*para).err;  			//�����ۼ�
	else								(*para).err_add+=0.3*(*para).err;		//���ַ���
	
	if((*para).err_add>500)  (*para).err_add=500;
	if((*para).err_add<-500)  (*para).err_add=-500;
	
	return (*para).out;
}

/****************
�ٶȻ�PI  
Kp*Ek+Ki*Ek_S 
****************/  
float PID_Velocity(struct PID* para, int encoder_left)  //����Ϊ�����������Ķ���
{
	(*para).err = encoder_left;
	
	(*para).out = (*para).kp*(*para).err + (*para).ki*(*para).err_add;
	
	(*para).err_last=(*para).err;
	
	if((*para).err < 5) (*para).err_add+=(*para).err;  			//�����ۼ�
	else								(*para).err_add+=0.1*(*para).err;		//���ַ���
	
	return (*para).out;
}


//��������
//���ʵ��ֵ��������ֵ�򷵻�0
int Distance_limit(int hope,int real)
{
	if(real>=hope)
	{
		return 0;
	}
	return 1;
}


