##############################################################
# 2023年电赛训练  滚球控制系统
# 创建者：周双
# 创建时间：2023.5.29
######################################.########################
import sensor, image, time, lcd, math, time
from pyb import UART
from pyb import LED

usart3=UART(3,115200)
usart3.init(115200, bits=8, parity=None, stop=1) #初始化串口

#关闭补光灯防止地面反光
LED(1).off()
LED(2).off()
LED(3).off()

sensor.reset()
sensor.set_pixformat(sensor.RGB565)  #灰度图
sensor.set_framesize(sensor.QQVGA)      #160*120
#sensor.set_auto_gain(False)             #颜色跟踪必须关闭自动增益
#sensor.set_auto_whitebal(False)         #颜色跟踪必须关闭白平衡
sensor.skip_frames(time = 2000)         #跳过3秒等待感光元件设置生效
#lcd.init()                              #初始化lcd
clock = time.clock()
#sensor.set_auto_exposure(True, exposure_us=8000)


#小球阈值
reg = (48, 66, 30, 127, -128, 127)


def getxy(img):
    qiu_blob = img.find_blobs([reg], area_threshold=3, merge=True)
    return  qiu_blob


#标记函数：
def Mark(qiuxy):
    #【1】标记球：
    for blob in qiuxy:
        img.draw_circle(blob.cx(), blob.cy(), int(blob.w()/2), color=(255,255,0))    #圈出小球
        #img.draw_cross(blob.cx(), blob.cy(),color=(255,255,255))    #圈出中心十字

    img.draw_circle(25, 20, 5, color=(255,0,0))    #圈出小球   1
    img.draw_circle(70, 20, 5, color=(255,0,0))    #圈出小球   2
    img.draw_circle(115, 20, 5, color=(255,0,0))   #圈出小球   3

    img.draw_circle(29, 64, 5, color=(255,0,0))    #圈出小球   4
    img.draw_circle(70, 64, 5, color=(255,0,0))    #圈出小球   5
    img.draw_circle(115, 64, 5, color=(255,0,0))    #圈出小球  6

    img.draw_circle(32, 112, 5, color=(255,0,0))    #圈出小球   7
    img.draw_circle(74, 108, 5, color=(255,0,0))    #圈出小球   8
    img.draw_circle(118, 108, 5, color=(255,0,0))   #圈出小球   9




#终端打印函数：
def UART_Out(qiuxy):
    if qiuxy:
        #【1】串口发送：
        #print("cx:%d, cy:%d" %(qiuxy[0].cx(),qiuxy[0].cy()))
        data = bytearray([0xb3, 0xb3, qiuxy[0].cx(), qiuxy[0].cy(), 0x5b]) #帧头 + 帧头 + 循迹值 + 赛道元素+ 帧尾
        usart3.write(data)


###########################################  主函数  ################################################
while(True):
    clock.tick()
    #【1】处理：
    img = sensor.snapshot().lens_corr(1.8)#.mean(1)    #拍照,畸变矫正1.8
    qiuxy = getxy(img)
#    Mark(qiuxy)                        #进行标记

    #【2】输出：
#    img.draw_string(0,0, "FPS:%d"%int(clock.fps()), color=(255,0,0))
#    lcd.display(img)                    #lcd显示
#    print(clock.fps())
    UART_Out(qiuxy)         #输出
