#include "control.h"
#include "math.h"

struct qu_yu qu_yu_1,qu_yu_2,qu_yu_3,qu_yu_4,qu_yu_5,qu_yu_6,qu_yu_7,qu_yu_8,qu_yu_9;
int PulseA_out,PulseB_out;
int Hope_Cx,Hope_Cy;
int x_err_cx,
		x_err_cy,
		v_err_cx,
		v_err_cy,
		qiu_cx2,
		qiu_cy2;
struct qu_yu qu_yu_last;
int err_cx,err_cy,now_cx,now_cy,quyu_pick=1,dirx=0,diry=0;

int sin_cx[64] = {400,439,478,516,553,588,622,653,682,709,732,752,769,782,792,798,800,798,792,782,
769,752,732,709,682,653,622,588,553,516,478,439,400,360,321,283,246,211,177,146,
117,90,67,47,30,17,7,1,0,1,7,17,30,47,67,90,117,146,177,211,246,283,321,360};

int cos_cy[64] = {800,798,792,782,769,752,732,709,682,653,622,588,553,516,478,439,400,360,321,283,
246,211,177,146,117,90,67,47,30,17,7,1,0,1,7,17,30,47,67,90,117,146,177,211,246,
283,321,360,400,439,478,516,553,588,622,653,682,709,732,752,769,782,792,798};

void TIM3_Init(void)  //10ms
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	TIM_TimeBaseInitStruct.TIM_Period=1000;
	TIM_TimeBaseInitStruct.TIM_Prescaler=720-1;
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);

	TIM_Cmd(TIM3,ENABLE);
}

void Contorl_Init(void)
{
//	TIM3_Init();
	qu_yu_1.cx = 34; 	qu_yu_1.cy = 30;		//����1
	qu_yu_2.cx = 65; 	qu_yu_2.cy = 28;		//����2
	qu_yu_3.cx = 96; qu_yu_3.cy = 27;		//����3
	qu_yu_4.cx = 35; 	qu_yu_4.cy = 60;		//����4
	qu_yu_5.cx = 66; 	qu_yu_5.cy = 59;		//����5
	qu_yu_6.cx = 98; qu_yu_6.cy = 56;		//����6
	qu_yu_7.cx = 39; 	qu_yu_7.cy = 90;		//����7
	qu_yu_8.cx = 68; 	qu_yu_8.cy = 89;		//����8
	qu_yu_9.cx = 98; qu_yu_9.cy = 87;		//����9
}

void Control_quan(void)
{
	int i=0,fu_hao=0;
	float r=0,sinc_x,r2;
	int fai=+13;
	OLED_Clear();
	Openmv_Init();
	delay_ms(1000);
//	USART_Cmd(USART3, DISABLE);
	
	while(1)
	{
//		for(i=0;i<64;i++)
//		{
			r= sqrt(((qiu_cx-qu_yu_5.cx)*(qiu_cx-qu_yu_5.cx)) + ((qiu_cy-qu_yu_5.cy)*(qiu_cy-qu_yu_5.cy)));
			r2=r*(0.72);
			sinc_x = (qiu_cx-qu_yu_5.cx)/r;
			
//			OLED_Write(0,0,16,"sinc_x: %.2f",sinc_x);
			
			if((qiu_cy-qu_yu_5.cy)>0) fu_hao=1;
			else 											fu_hao=-1;
			

			
//			i=Fabs((int)(sinc_x/(1/16.0f)));
			
			if(fu_hao==1)  if(sinc_x>0) {i=(int)(sinc_x/(1/16.0f));i=(-i)+26+fai;}
			if(fu_hao==1)  if(sinc_x<0) {i=(int)(sinc_x/(1/16.0f));i=(-i)+26+fai;}
			if(fu_hao==-1) if(sinc_x<0) {i=(int)(sinc_x/(1/16.0f));i=i+58+fai;}
			if(fu_hao==-1) if(sinc_x>0) {i=(int)(sinc_x/(1/16.0f));i=i+58+fai;}
			
			if(i>=64) i=i-64;
			if(i<0) i=64-i;
			
//			OLED_Write(0,2,16,"i: %d",i);
			
			if(r2>=1.2) 	r2=1.2f;
			if(r2<=-1.2) 	r2=-1.2f;
			Motor_Write((-(sin_cx[i]-400)*r2), ((cos_cy[i]-400))*r2);
			delay_ms(5);
//			k= sqrt(((qiu_cx-qu_yu_5.cx)*(qiu_cx-qu_yu_5.cx)) + ((qiu_cy-qu_yu_5.cy)*(qiu_cy-qu_yu_5.cy)));
			
//		}
//		while(1);
	}
}

void Control_Pick(int cx, int cy)
{
	if(cx!= NUL) Hope_Cx = cx;
	if(cy!= NUL) Hope_Cy = cy;
}

void Control_Pick_Num(int Mode)
{
	switch(Mode)
	{
		case 1:now_cx = qu_yu_1.cx;now_cy = qu_yu_1.cy;break;
		case 2:now_cx = qu_yu_2.cx;now_cy = qu_yu_2.cy;break;
		case 3:now_cx = qu_yu_3.cx;now_cy = qu_yu_3.cy;break;
		case 4:now_cx = qu_yu_4.cx;now_cy = qu_yu_4.cy;break;
		case 5:now_cx = qu_yu_5.cx;now_cy = qu_yu_5.cy;break;
		case 6:now_cx = qu_yu_6.cx;now_cy = qu_yu_6.cy;break;
		case 7:now_cx = qu_yu_7.cx;now_cy = qu_yu_7.cy;break;
		case 8:now_cx = qu_yu_8.cx;now_cy = qu_yu_8.cy;break;
		case 9:now_cx = qu_yu_9.cx;now_cy = qu_yu_9.cy;break;
	}
}

void Control_Pick_Mode(int cx, int cy)
{
	u8 out_x,out_y;
	u8 Fcx=Fabs(cx),Fcy=Fabs(cy);
	u8 a=0,b=0,c=0;
	
	if(cx<-10) dirx=1;
	if(cy<-10) diry=1;
	if(Fcx<10) 									a=0;
	else if(Fcx>=20 & Fcx<=50)  a=1;
	else if(Fcx>50) 						a=2;
	
	if(Fcy<10) 									b=0;
	else if(Fcy>=20 & Fcy<=50)  b=1;
	else if(Fcy>50) 						b=2;
	
	c = b | (a<<4);
	switch(c)
	{
		case 0x00:break;
		case 0x10:					//y��0ƫ��  x��1����λƫ��
		{
			Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
			delay_ms(200);
			
			if(dirx==0) Control_Pick(qu_yu_last.cx+16, qu_yu_last.cy);
			else 				Control_Pick(qu_yu_last.cx-16, qu_yu_last.cy);
			delay_ms(1000);
			delay_ms(400);
			
			Control_Pick(now_cx, now_cy);
			break;
		}
		case 0x20:					//y��0ƫ��  x��2����λƫ��
		{
			if(qu_yu_last.cy<80)
			{
				Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
				delay_ms(200);
				
				if(diry==0) Control_Pick(qu_yu_last.cx, qu_yu_last.cy+8);
				else 				Control_Pick(qu_yu_last.cx, qu_yu_last.cy-8);
				delay_ms(200);
				delay_ms(1000);
				
				if(diry==0) Control_Pick(qu_yu_last.cx, qu_yu_last.cy+12);
				else 				Control_Pick(qu_yu_last.cx, qu_yu_last.cy-12);
				delay_ms(1000);
				delay_ms(1000);
				delay_ms(500);
				
				if(dirx==0) Control_Pick(now_cx-25, qu_yu_last.cy+12);
				else 				Control_Pick(now_cx+25, qu_yu_last.cy-12);
				delay_ms(1000);
				delay_ms(1000);
				
				if(dirx==0) Control_Pick(now_cx, qu_yu_last.cy+12);
				else 				Control_Pick(now_cx, qu_yu_last.cy-12);
				delay_ms(1000);
				delay_ms(1000);
				delay_ms(500);
				
				if(dirx==0) Control_Pick(now_cx, qu_yu_last.cy+4);
				else 				Control_Pick(now_cx, qu_yu_last.cy-4);
				delay_ms(1000);
				delay_ms(300);
				
				Control_Pick(now_cx, now_cy);
				break;
			}
			else
			{
				Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
				delay_ms(200);
				
				if(diry==0) Control_Pick(qu_yu_last.cx, qu_yu_last.cy-8);
				else 				Control_Pick(qu_yu_last.cx, qu_yu_last.cy+8);
				delay_ms(200);
				delay_ms(1000);
				
				if(diry==0) Control_Pick(qu_yu_last.cx, qu_yu_last.cy-12);
				else 				Control_Pick(qu_yu_last.cx, qu_yu_last.cy+12);
				delay_ms(1000);
				delay_ms(1000);
				delay_ms(500);
				
				if(dirx==0) Control_Pick(now_cx-25, qu_yu_last.cy-12);
				else 				Control_Pick(now_cx+25, qu_yu_last.cy+12);
				delay_ms(1000);
				delay_ms(1000);
				
				if(dirx==0) Control_Pick(now_cx, qu_yu_last.cy-12);
				else 				Control_Pick(now_cx, qu_yu_last.cy+12);
				delay_ms(1000);
				delay_ms(1000);
				delay_ms(500);
				
				if(dirx==0) Control_Pick(now_cx, qu_yu_last.cy-4);
				else 				Control_Pick(now_cx, qu_yu_last.cy+4);
				delay_ms(1000);
				delay_ms(300);
				
				Control_Pick(now_cx, now_cy);
				break;
			}
		}
		case 0x01:					//y��1ƫ��  x��0����λƫ��
		{
			Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
			delay_ms(200);
			
			if(diry==0) Control_Pick(qu_yu_last.cx, qu_yu_last.cy+16);
			else 				Control_Pick(qu_yu_last.cx, qu_yu_last.cy-16);
			delay_ms(1000);
			delay_ms(650);
			
			Control_Pick(now_cx, now_cy);
			break;
		}
		case 0x11:					//y��1ƫ��  x��1����λƫ��
		{
			Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
			delay_ms(200);
			
			if(dirx==0) out_x = qu_yu_last.cx + 18;
			else 				out_x = qu_yu_last.cx - 18;
			if(diry==0) out_y = qu_yu_last.cy + 18;
			else 				out_y = qu_yu_last.cy - 18;
			Control_Pick(out_x, out_y);
			delay_ms(1000);
			delay_ms(400);
			Control_Pick(now_cx, now_cy);
			break;
		}
		case 0x21:					//y��1ƫ��  x��2����λƫ��
		{
			Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
			delay_ms(200);
			
			if(dirx==0) out_x = qu_yu_last.cx + 42;
			else 				out_x = qu_yu_last.cx - 28;
			if(diry==0) 
			{
				out_y = qu_yu_last.cy + 15;
				if(qu_yu_last.cy == qu_yu_4.cy) out_y = qu_yu_last.cy + 11;
				if(qu_yu_last.cy == qu_yu_1.cy) out_y = qu_yu_last.cy + 10;
			}
			else 				out_y = qu_yu_last.cy - 11;

			
			Control_Pick(out_x, out_y);
			delay_ms(1000);
			delay_ms(500);
			Control_Pick(out_x, now_cy);
			delay_ms(600);
			Control_Pick(now_cx, now_cy);
			break;
		}
		case 0x02:					//y��2ƫ��  x��0����λƫ��
		{
			if(qu_yu_last.cx<=80)
			{
				Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
				delay_ms(200);
				
				if(dirx==0) Control_Pick(qu_yu_last.cx+8, qu_yu_last.cy);
				else 				Control_Pick(qu_yu_last.cx-8, qu_yu_last.cy);
				delay_ms(200);
				delay_ms(1000);
				
				if(dirx==0) Control_Pick(qu_yu_last.cx+14, qu_yu_last.cy);
				else 				Control_Pick(qu_yu_last.cx-14, qu_yu_last.cy);
				delay_ms(1000);
				delay_ms(500);
				
				if(diry==0) Control_Pick(NUL, qu_yu_last.cy+38);
				else 				Control_Pick(NUL, qu_yu_last.cy-28);
				delay_ms(1000);
				delay_ms(1000);
				delay_ms(400);
				
				if(diry==0) Control_Pick(NUL, now_cy);
				else 				Control_Pick(NUL, now_cy);
				delay_ms(1000);
				delay_ms(500);
				
				if(dirx==0) Control_Pick(now_cx+6, now_cy);
				else 				Control_Pick(now_cx-6, now_cy);
				delay_ms(1000);
				delay_ms(300);
				
				Control_Pick(now_cx, now_cy);
			}
			else
			{
				Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
				delay_ms(200);
				
				if(dirx==0) Control_Pick(qu_yu_last.cx-8, qu_yu_last.cy);
				else 				Control_Pick(qu_yu_last.cx+8, qu_yu_last.cy);
				delay_ms(200);
				delay_ms(1000);
				
				if(dirx==0) Control_Pick(qu_yu_last.cx-14, qu_yu_last.cy);
				else 				Control_Pick(qu_yu_last.cx+14, qu_yu_last.cy);
				delay_ms(1000);
				delay_ms(500);
				
				if(diry==0) Control_Pick(NUL, qu_yu_last.cy+38);
				else 				Control_Pick(NUL, qu_yu_last.cy-28);
				delay_ms(1000);
				delay_ms(1000);
				delay_ms(400);
				
				if(diry==0) Control_Pick(NUL, now_cy);
				else 				Control_Pick(NUL, now_cy);
				delay_ms(1000);
				delay_ms(500);
				
				if(dirx==0) Control_Pick(now_cx-6, now_cy);
				else 				Control_Pick(now_cx+6, now_cy);
				delay_ms(1000);
				delay_ms(300);
				
				Control_Pick(now_cx, now_cy);
			}
			break;
		}
		case 0x12:					//y��2ƫ��  x��1����λƫ��
		{
			Control_Pick(qu_yu_last.cx, qu_yu_last.cy);
			delay_ms(200);
			
			if(diry==0) out_y = qu_yu_last.cy + 34;
			else 				out_y = qu_yu_last.cy - 33;
			if(dirx==0) out_x = qu_yu_last.cx + 8;
			else 				out_x = qu_yu_last.cx - 8;

			
			Control_Pick(out_x, out_y);
			delay_ms(1000);
			delay_ms(200);
			if(dirx==0) Control_Pick(now_cx-8, out_y);
			else 				Control_Pick(now_cx+8, out_y);
			delay_ms(1300);
			Control_Pick(now_cx, now_cy);
			break;
		}
	}
}

void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) //��� TIM1�����жϷ������
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update ); //��� TIM1 �����жϱ�־
	}
}

int Mode=0;
void cai_dan(void)
{
	int a=0;
	OLED_Write(0,0,16,"Mode1");
	OLED_Write(0,2,16,"Mode2");
	OLED_Write(0,4,16,"Mode3");
	OLED_Write(0,6,16,"Mode4");
	OLED_Write(100,0,16,"<--");
	while(1)
	{
		if(KEY1==0&&a==0)
		{
			delay_ms(10);
			while(KEY1==0);
			OLED_Write(100,0,16,"   ");
			OLED_Write(100,2,16,"<--");
			a=1;
		}
		if(KEY1==0&&a==1)
		{
			delay_ms(10);
			while(KEY1==0);
			OLED_Write(100,2,16,"   ");
			OLED_Write(100,4,16,"<--");
			a=2;
		}
		if(KEY1==0&&a==2)
		{
			delay_ms(10);
			while(KEY1==0);
			OLED_Write(100,4,16,"   ");
			OLED_Write(100,6,16,"<--");
			a=3;
		}
		if(KEY1==0&&a==3)
		{
			delay_ms(10);
			while(KEY1==0);
			OLED_Write(100,6,16,"   ");
			OLED_Write(100,0,16,"<--");
			a=0;
		}
		if(KEY2==0)
		{
			delay_ms(10);
			while(KEY2==0);
			OLED_Clear();
			switch(a)
			{
				case 0:Mode=1;OLED_Write(20,3,16,"Mode1--OK!");break;
				case 1:Mode=2;OLED_Write(20,3,16,"Mode2--OK!");break;
				case 2:Mode=3;OLED_Write(20,3,16,"Mode3--OK!");break;
				case 3:Mode=4;OLED_Write(20,3,16,"Mode4--OK!");break;
			}
			break;
		}
	}
	
	switch(Mode)
	{
		case 1:Task_6();break;
		case 2:Task_2();break;
		case 3:Task_3();break;
		case 4:Task_4();break;
	}
}

void Pick_startup(int a)
{
	quyu_pick = a;
	Control_Pick_Num(quyu_pick);
	Control_Pick(now_cx, now_cy);  //���
	qu_yu_last.cx = now_cx;        //��¼ǰһ��λ��
	qu_yu_last.cy = now_cy;
	Openmv_Init();
	delay_ms(200);
}

void Pick_end(int a)
{
	quyu_pick = a;
	Control_Pick_Num(quyu_pick);
	err_cx = now_cx - qu_yu_last.cx;
	err_cy = now_cy - qu_yu_last.cy;
	
	Control_Pick_Mode(err_cx, err_cy);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	
	qu_yu_last.cx = now_cx;        //��¼ǰһ��λ��
	qu_yu_last.cy = now_cy;
}

void Pick_end_xy(int cx1, int cy1)
{
	
}

int pick_xy_oled(void)
{
	int now2;
	OLED_Write(0,0,16,"Pick:");
	while(zigbee_data==0);
	now2 = zigbee_data;
	OLED_Write(0,2,16,"now: %d",now2);
	Control_Pick_Num(now2);
	qu_yu_last.cx = now_cx;            //��¼ǰһ��λ��
	qu_yu_last.cy = now_cy;
	while(zigbee_data==now2);
	while(zigbee_data==0);
	now2 = zigbee_data;
	OLED_Write(0,4,16,"hope: %d",now2);
	return	now2;
}


void Task_1(void)
{
	Control_Pick(qu_yu_2.cx, qu_yu_2.cy);
	Openmv_Init();
	while(1);
}

void Task_2(void)
{
	Control_Pick(qu_yu_1.cx, qu_yu_1.cy);
	Openmv_Init();
	delay_ms(500);
	
	Control_Pick(qu_yu_1.cx+16, qu_yu_1.cy+16);
	delay_ms(1000);
	delay_ms(400);
	Control_Pick(qu_yu_5.cx, qu_yu_5.cy);
	while(1);
}

void Task_3(void)
{
	Control_Pick(qu_yu_1.cx, qu_yu_1.cy);
	Openmv_Init();
	delay_ms(500);
	
	Control_Pick(qu_yu_4.cx, qu_yu_4.cy-16);
	delay_ms(1000);
	delay_ms(700);
	
	Control_Pick(qu_yu_4.cx, qu_yu_4.cy);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	Control_Pick(qu_yu_5.cx-12, qu_yu_5.cy);
	delay_ms(1000);
	delay_ms(400);
	Control_Pick(qu_yu_5.cx, qu_yu_5.cy);
	while(1);
}

void Task_4(void)
{
	Control_Pick(qu_yu_1.cx, qu_yu_1.cy);      //�ȶ�������1
	Openmv_Init();
	delay_ms(500);
	Control_Pick(qu_yu_4.cx, qu_yu_1.cy+8);		 
	delay_ms(200);
	delay_ms(1000);
	Control_Pick(qu_yu_4.cx, qu_yu_1.cy+12);	 //�ȶ�������1�·�
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(500);
	
	
	Control_Pick(qu_yu_2.cx-4, qu_yu_1.cy+12); 
	delay_ms(1000);
	delay_ms(800);
	Control_Pick(qu_yu_3.cx-15, qu_yu_1.cy+12);	//�ȶ�������3���·�
	
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(500);
	
	
	Control_Pick(qu_yu_3.cx-15, qu_yu_6.cy+12);
	delay_ms(1000);
	delay_ms(800);
	delay_ms(400);
	Control_Pick(qu_yu_3.cx-15, qu_yu_9.cy);			//�ȶ�������9��
	
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(500);
	
	Control_Pick(qu_yu_9.cx-6, qu_yu_9.cy);
	delay_ms(700);
	delay_ms(500);
	Control_Pick(qu_yu_9.cx, qu_yu_9.cy);				//�ȶ�������9
	while(1);
}

void Task_5(void)
{
	OLED_Clear();
	delay_ms(100);
	
	Pick_startup(1);
	Pick_end(6);
//	Pick_startup(6);
	Pick_end(7);
//	Pick_startup(7);
	Pick_end(8);
	while(1);
}

void Task_6(void)
{
	int now2=0;
	int a,b,c,d;
	OLED_Clear();
	delay_ms(100);
	
	OLED_Write(0,0,16,"A:");
	OLED_Write(0,2,16,"B:");
	OLED_Write(0,4,16,"C:");
	OLED_Write(0,5,16,"D:");
	
	while(zigbee_data==0);
	now2 = zigbee_data;
	a=now2;
	OLED_Write(40,0,16,"%d",now2);
	Control_Pick_Num(now2);
	qu_yu_last.cx = now_cx;            //��¼ǰһ��λ��
	qu_yu_last.cy = now_cy;
	while(zigbee_data==now2);
	while(zigbee_data==0);
	now2 = zigbee_data;
	b=now2;
	OLED_Write(40,2,16,"%d",now2);
	while(zigbee_data==now2);
	while(zigbee_data==0);
	now2 = zigbee_data;
	c=now2;
	OLED_Write(40,4,16,"%d",now2);
	while(zigbee_data==now2);
	while(zigbee_data==0);
	now2 = zigbee_data;
	d=now2;
	OLED_Write(40,5,16,"%d",now2);
	
	
	Pick_startup(a);
	Pick_end(b);
	Pick_end(c);
	Pick_end(d);
	while(1);
}

void Task_7(void)
{
	Pick_startup(4);
	
	Control_Pick(qu_yu_4.cx+12, qu_yu_4.cy);
	delay_ms(800);
	delay_ms(500);
	Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy);
	delay_ms(600);
	delay_ms(600);
	
	
	while(1)
	{
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy+6);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		
		
		Control_Pick(qu_yu_4.cx+33, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy+1);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+32, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy-2);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		
		delay_ms(1000);
		
		//2Ȧ
		
		Control_Pick(qu_yu_4.cx+33, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy+2);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+32, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy-2);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy+12);
		
		delay_ms(1000);
		
		//3Ȧ
		Control_Pick(qu_yu_4.cx+33, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy+2);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+42, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+32, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy-10);
		delay_ms(800);
		delay_ms(400);
		
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy-2);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_4.cx+21, qu_yu_4.cy+12);
		
		delay_ms(1000);
		delay_ms(1000);
		
		//��9
		Control_Pick(qu_yu_4.cx+21+14, qu_yu_4.cy+12);
		delay_ms(800);
		delay_ms(400);
		Control_Pick(qu_yu_9.cx, qu_yu_4.cy+12);
		delay_ms(1000);
		Control_Pick(qu_yu_9.cx, qu_yu_4.cy+12+6);
		delay_ms(800);
		Control_Pick(qu_yu_9.cx, qu_yu_9.cy);
		
		
		while(1);
	}
}
