#ifndef _CONTROL_h
#define _CONTROL_h

#include "system.h"

#define NUL 2000

struct qu_yu
{
	int cx;
	int cy;
};

extern struct qu_yu qu_yu_1,qu_yu_2,qu_yu_3,qu_yu_4,qu_yu_5,qu_yu_6,qu_yu_7,qu_yu_8,qu_yu_9;
extern int Hope_Cx,Hope_Cy;
extern int PulseA_out,PulseB_out;
extern int x_err_cx,
		x_err_cy,
		v_err_cx,
		v_err_cy,
		qiu_cx2,
		qiu_cy2;


void TIM3_Init(void);  //10ms
void Contorl_Init(void);
void Control_Pick(int cx, int cy);
void Control_Pick_Num(int Mode);
int pick_xy_oled(void);
void Control_quan(void);

void cai_dan(void);
void Task_1(void);  //��Ŀ1
void Task_2(void);	//��Ŀ2
void Task_3(void);	//��Ŀ3
void Task_4(void);	//��Ŀ4
void Task_5(void);
void Task_6(void);
void Task_7(void);


#endif

