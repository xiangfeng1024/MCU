#include "zigbee.h"

int zigbee_data=0;

float Debug_zigbee_data[10]={0};

void USART2_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
 
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = bound;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2, &USART_InitStructure);
	
	USART_ClearFlag(USART2, USART_FLAG_TC);
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	USART_Cmd(USART2, ENABLE);
}

void zigbee_debug_Init(void)
{
	USART2_Init(115200);
}

//void VOFA_data(float a)
//{
//	float b;
//	int i;
//	u8 data[8];
//	b=(float)a;
//	
//	data[0]=*((u8*)&b);
//	data[1]=*((u8*)&b+1);
//	data[2]=*((u8*)&b+2);
//	data[3]=*((u8*)&b+3);
//	
//	data[4]=0x00;
//	data[5]=0x00;
//	data[6]=0x80;
//	data[7]=0x7f;
//	for(i=0;i<8;i++)
//	{
//		USART_SendData(UART5,data[i]);
//		while( USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET );
//	}
//}

void VOFA_Write(int n,float* a)
{
	float b[n];
	int i,k,m=0;
	i=n;
	u8 data[4*(i+1)];
	for(i=0;i<n;i++)
	{
		b[i] = a[i];
	}
	
	for(k=0;k<n;k++)
	{
		data[m++]=*((u8*)&b[k]);
		data[m++]=*((u8*)&b[k]+1);
		data[m++]=*((u8*)&b[k]+2);
		data[m++]=*((u8*)&b[k]+3);
	}
	
	data[4*n]=0x00;
	data[4*n+1]=0x00;
	data[4*n+2]=0x80;
	data[4*n+3]=0x7f;
	
	for(i=0;i<4*(n+1);i++)
	{
		USART_SendData(USART2,data[i]);
		while( USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET );
	}
}

void Zigbee_Write(int n)
{
	int Zigbee_data[3]={0xa1,n,0xa2},i=0;
	for(i=0;i<3;i++)
	{
		USART_SendData(USART2,Zigbee_data[i]);
		while( USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET );
	}
}

void USART2_IRQHandler(void)
{
	int a;
	static int zigbee_buf[5]={0};
	static u8 data_Flag=0;
	static u8 i=0;
	if(USART_GetITStatus(USART2,USART_IT_RXNE)!=RESET)
	{
		a=USART_ReceiveData(USART2);	//��ȡ���յ�����Ϣ
		
		if(data_Flag==0 && a==0xa1) //�ж�֡ͷ
		{
			data_Flag=1;
			i=0;
		}
	
		if(data_Flag==1)  //���յ�֡ͷ����ʼ��������        
		{
			zigbee_buf[i]=a;
			if(i<2) i++;
			else  //���ݽ����꣬��ʼУ��
			{
				data_Flag=0;
				i=0;
				if(zigbee_buf[0]==0xa1&&zigbee_buf[2]==0xa2)  //У��ɹ�����Ҫ���յ�����
				{
					zigbee_data = zigbee_buf[1];
				}
			}
		}
	}
	USART_ClearFlag(USART2,USART_FLAG_TC);	//������������ ������
}


