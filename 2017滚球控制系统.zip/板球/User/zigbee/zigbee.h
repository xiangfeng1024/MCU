#ifndef _ZIGBEE_H
#define _ZIGBEE_H

#include "system.h"

extern float Debug_zigbee_data[10];
extern int zigbee_data;

void USART2_Init(u32 bound);
void zigbee_debug_Init(void);
void VOFA_Write(int n,float* a);
void Zigbee_Write(int n);

#endif


