#include "motor.h"

u16 Pulse_Tick;		//�������
		
int Pulse_Count=0,
		Pa,
		Pb,
		A_1,
		B_1,
		Ta_last=0,
		Tb_last=0,
		Pulse_Tick_A,
		Pulse_Tick_B,
		Pulse_Stop_Flag=0,
		Pulese_out=0;

/*�����ʼ������*/
void Motor_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;                   //�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void TIM4_Init(void)  //100us
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
	TIM_TimeBaseInitStruct.TIM_Period=200;
	TIM_TimeBaseInitStruct.TIM_Prescaler=72-1;
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStruct);
	TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);

//	TIM_Cmd(TIM2,ENABLE);
}

void TIM2_Init(void)  //15ms
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	TIM_TimeBaseInitStruct.TIM_Period=500;
	TIM_TimeBaseInitStruct.TIM_Prescaler=7200-1;
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStruct);
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);

//	TIM_Cmd(TIM2,ENABLE);
}

void Motor_Init(void)
{
	Motor_GPIO_Init();
	TIM4_Init();
}

void Motor_Load(int PulseA, int PulseB)
{
//	Motor_Limit(&PulseA,&PulseB);
	Pa=Fabs(PulseA);
	Pb=Fabs(PulseB);
	
	if(Pa > Pb) Pulese_out=Pa;
	else 				Pulese_out=Pb;
	
	if(PulseA > 0) {DIR1=1;A_1=1;}
	else					 {DIR1=0;A_1=0;}
	if(PulseB > 0) {DIR2=1;B_1=1;}
	else					 {DIR2=0;B_1=0;}
	
	TIM_Cmd(TIM4,ENABLE);
}


void Motor_Write(int STPA, int STPB)
{
	int outA = 0, outB = 0;   					//��ȡ��Ҫ����������
	
	TIM_Cmd(TIM4,DISABLE);
	
	outA = STPA-Ta_last;
	outB = STPB-Tb_last;
	
	Pulse_Tick_A=0;
	Pulse_Tick_B=0;
	Pulse_Tick=0;
	
	Motor_Load(outA, outB);
}

void Motor_Limit(int *STPA, int *STPB)
{
	if((*STPA)>=300)  (*STPA)=300;
	if((*STPA)<=-300) (*STPA)=-300;
	
	if((*STPB)>=300)  (*STPB)=300;
	if((*STPB)<=-300) (*STPB)=-300;
}


/*����ֵ����*/
int Fabs(int p)
{
	int q;
	q = p>0?p:(-p);
	return q;
}


void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET) //��� TIM1�����жϷ������
	{
		Pulse_Tick++;
		Pulse_Stop_Flag=0;
		if(A_1==1) 
		{
			if(Pulse_Tick_A < Pa) {GPIOB->ODR ^= GPIO_Pin_6;Ta_last++;Pulse_Tick_A++;}
		}
		else
		{
			if(Pulse_Tick_A > (-Pa)) {GPIOB->ODR ^= GPIO_Pin_6;Ta_last--;Pulse_Tick_A--;}
		}
		
		if(B_1==1)
		{
			if(Pulse_Tick_B < Pb) {GPIOB->ODR ^= GPIO_Pin_8;Tb_last++;Pulse_Tick_B++;}
		}
		else
		{
			if(Pulse_Tick_B > (-Pb)) {GPIOB->ODR ^= GPIO_Pin_8;Tb_last--;Pulse_Tick_B--;}
		}
		
		if((Pulse_Tick)>=Pulese_out) TIM_Cmd(TIM4,DISABLE);
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update ); //��� TIM1 �����жϱ�־
	}
}



void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) //��� TIM1�����жϷ������
	{
		
		x_err_cx = Hope_Cx - qiu_cx;
		x_err_cy = Hope_Cy - qiu_cy;
		
		v_err_cx = qiu_cx2 - qiu_cx;
		v_err_cy = qiu_cy2 - qiu_cy;
		
		qiu_cx2 = qiu_cx;
		qiu_cy2 = qiu_cy;
		//10ms��һ�ο���
		PulseA_out = -Loca_pid(&STE_A, x_err_cy, v_err_cy);
		PulseB_out = Loca_pid(&STE_B, x_err_cx, v_err_cx);
		
		Motor_Write(PulseA_out, PulseB_out);
		
		OLED_Write(0,0,16,"v: %d",v_err_cy);
		
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update ); //��� TIM1 �����жϱ�־
	}
}

