#ifndef _MOTOR_H
#define _MOTOR_H

#include "system.h"
 
#define EN  PBout(5)

#define STP1  PBout(6)
#define DIR1  PBout(7)
#define STP2  PBout(8)
#define DIR2  PBout(9)
 
extern u16 Pulse_Tick;
 
void Motor_GPIO_Init(void);
void Motor_Init(void);
void TIM4_Init(void);
int Fabs(int p);
void Motor_Load(int PulseA, int PulseB);
void Motor_Write(int STPA, int STPB);
void Motor_Limit(int *STPA, int *STPB);
void TIM2_Init(void);


#endif


