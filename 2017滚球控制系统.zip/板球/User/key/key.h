#ifndef _KEY_H
#define _KEY_H

#include "system.h"

#define KEY1      PAin(8) 
#define KEY2      PAin(9) 
#define KEY3      PAin(10) 

void KEY_GPIO_Init(void);
void EXTIX_Init(void);

#endif


