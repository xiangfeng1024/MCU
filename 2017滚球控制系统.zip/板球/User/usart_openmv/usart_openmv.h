#ifndef _USART_OPENMV_H
#define _USART_OPENMV_H

#include "system.h"

#define Openmv_DATA_SIZE  5


void USART3_Init(uint32_t a);
void Openmv_Init(void);

extern u8 qiu_cx,qiu_cy;
extern int Tick;


#endif


