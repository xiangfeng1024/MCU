#ifndef _PID_H
#define _PID_H

#include "system.h"

struct PID
{
	float kp;
	float ki;
	float kd;
	
	float err;
	float err_last;
	float err_last_dev;
	float err_add;
	
	float ki_p;
	
	float out;
};

void PID_Init(void);
int Loca_pid(struct PID* para,int hope,int now);

extern struct PID STE_A,STE_B;

#endif


