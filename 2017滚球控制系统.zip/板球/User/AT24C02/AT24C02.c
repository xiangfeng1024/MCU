#include "AT24C02.h"

void AT24_IIC_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(AT24_IIC_SCL_PORT_RCC|AT24_IIC_SDA_PORT_RCC, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = AT24_IIC_SCL_PIN;	 
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(AT24_IIC_SCL_PORT, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = AT24_IIC_SDA_PIN;	 
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(AT24_IIC_SDA_PORT, &GPIO_InitStructure);
}

void AT24_Init(void)
{
	AT24_IIC_Init();
}

void SDA_OUT(void)	//���ģʽ
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = AT24_IIC_SDA_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(AT24_IIC_SDA_PORT, &GPIO_InitStructure);
}

void SDA_IN(void)	//����ģʽ
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = AT24_IIC_SDA_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(AT24_IIC_SDA_PORT, &GPIO_InitStructure);
}


void IIC_AT24_Start(void)
{
	AT24_SDA_Set();
	delay_us(5);
	AT24_SCL_Set();
	delay_us(5);
	AT24_SDA_Clr();
	delay_us(5);
	AT24_SCL_Clr();
	delay_us(5);
}

void IIC_AT24_Stop(void)
{
	AT24_SDA_Clr();
	delay_us(5);
	AT24_SCL_Set();
	delay_us(5);
	AT24_SDA_Set();
	delay_us(5);
}

void IIC_AT24_Ack(void)
{
	AT24_SCL_Set();
	delay_us(5);
	AT24_SCL_Clr();
}

void IIC_AT24_XIE(unsigned char IIC_Byte)
{
	unsigned char i;
	unsigned char m,da;
	da=IIC_Byte;
	AT24_SCL_Clr();
	for(i=0;i<8;i++)		
	{
		m=da;
		m=m&0x80;
		if(m==0x80)
		{
		  AT24_SDA_Set();
		}
		else 
		{
			AT24_SDA_Clr();
		}
		delay_us(5);
		da=da<<1;
		AT24_SCL_Set();
		delay_us(5);
		AT24_SCL_Clr();
		delay_us(5);
		}
}

unsigned char IIC_AT24_Read(void)
{
	unsigned char i;
	unsigned char da=0;
	SDA_IN();
	AT24_SCL_Clr();
	delay_us(5);
	for(i=0;i<8;i++)		
	{
		AT24_SCL_Set();
		delay_us(5);
		da <<= 1;
		if(SDAin) da |= 0x01;
		AT24_SCL_Clr();
		delay_us(5);
	}
	SDA_OUT();
	AT24_SDA_Set();
	AT24_SCL_Clr();
	return da;
}

void IIC_AT24_XIE_DATA(unsigned char AT24_ADDR, unsigned char AT24_DATA)
{
   IIC_AT24_Start();
   IIC_AT24_XIE(0xA0);
	 IIC_AT24_Ack();
   IIC_AT24_XIE(AT24_ADDR);
	 IIC_AT24_Ack();
   IIC_AT24_XIE(AT24_DATA); 
	 IIC_AT24_Ack();
   IIC_AT24_Stop();
}

unsigned char IIC_AT24_Read_DATA(unsigned char AT24_ADDR)
{
	 unsigned char data=0;
	 IIC_AT24_Start();
	 IIC_AT24_XIE(0xA0);
	 IIC_AT24_Ack();
	 IIC_AT24_XIE(AT24_ADDR);
	 IIC_AT24_Ack();	
	 IIC_AT24_Start();
	 IIC_AT24_XIE(0xA1);
	 IIC_AT24_Ack();
	 data = IIC_AT24_Read();	
	 IIC_AT24_Stop();
	 return data;
}

