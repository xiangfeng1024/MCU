#ifndef _AT24C02_H
#define _AT24C02_H

#include "system.h"

/*  IIC_SCLʱ�Ӷ˿ڡ����Ŷ��� */
#define AT24_IIC_SCL_PORT 				GPIOA   
#define AT24_IIC_SCL_PIN 					GPIO_Pin_6
#define AT24_IIC_SCL_PORT_RCC			RCC_APB2Periph_GPIOA

/*  IIC_SDAʱ�Ӷ˿ڡ����Ŷ��� */
#define AT24_IIC_SDA_PORT 				GPIOA  
#define AT24_IIC_SDA_PIN 					GPIO_Pin_7
#define AT24_IIC_SDA_PORT_RCC			RCC_APB2Periph_GPIOA

#define AT24_SCL_Clr() GPIO_ResetBits(AT24_IIC_SCL_PORT,AT24_IIC_SCL_PIN)//SCL
#define AT24_SCL_Set() GPIO_SetBits(AT24_IIC_SCL_PORT,AT24_IIC_SCL_PIN)

#define AT24_SDA_Clr() GPIO_ResetBits(AT24_IIC_SDA_PORT,AT24_IIC_SDA_PIN)//SDA
#define AT24_SDA_Set() GPIO_SetBits(AT24_IIC_SDA_PORT,AT24_IIC_SDA_PIN)

#define  SDAin  PAin(6)

void AT24C02_Init(void);
void IIC_AT24_Start(void);
void IIC_AT24_Stop(void);
void IIC_AT24_Ack(void);
void IIC_XIE(unsigned char IIC_Byte);
unsigned char IIC_AT24_Read(void);
void IIC_AT24_XIE_DATA(unsigned char AT24_ADDR, unsigned char AT24_DATA);
unsigned char IIC_AT24_Read_DATA(unsigned char AT24_ADDR);
void AT24_Init(void);

#endif

