#ifndef _LED_H
#define _LED_H

#include "system.h"

#define LED_RED        PAout(8)  
//#define LED_2        PDout(2) 
#define LED_YELLOW     PAout(10)
#define LED_GREEN      PAout(9)

void LED_Init(void);

#endif


