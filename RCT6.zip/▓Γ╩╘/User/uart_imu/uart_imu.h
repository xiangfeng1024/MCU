#ifndef _UART_IMU_H
#define _UART_IMU_H

#include "system.h"  

#define IMU_DATA_SIZE  28

extern float IMU_Roll,
						 IMU_Pitch,
						 IMU_Yaw;

extern uint16_t IMU_Gyrox,
								IMU_Gyroy,
								IMU_Gyroz;

extern int imu_ok;

void IMU_Init(void);
void USART3_Init(uint32_t a);

#endif

