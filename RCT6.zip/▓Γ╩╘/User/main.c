#include "system.h"

int main(void)
{
	SysTick_Init(72);          //�δ��ʱ����ʼ��
	NVIC_Config();
	LED_Init();
	OLED_Init();
	Motor_Init();
//	Servos_Init();
	Encoder_Init();
	AT24C02_Init();
//	Power_Init();
	IMU_Init();
	Openmv_Init();
	K210_Init();
	AIHMI_Init();
	zigbee_debug_Init();
	OLED_Write(0,0,16,"hello");
//	Wirte_Pid(1000,-200,60);
//	Read_Pid();
	
	while(KEY1);
	Motor_Write(0,4000);
	OLED_Write(0,2,16,"world");
//	Power_Read();
//	Motor_Write(3000,3000);
	
	
	while(1)
	{
		delay_ms(50);
//		OLED_Write(0,0,16,"L:%d",OpenmvData);
//		OLED_Write(0,2,16,"R:%d",K210Data);
//		OLED_Write(0,4,16,"R1:%d",aihmi_data);
//		OLED_Write(0,6,16,"R2:%d",zigbee_data);
//		Power_Read();
		
//		OLED_Write(0,0,8,"Roll:%.2f",IMU_Roll);
//		OLED_Write(0,1,8,"Pitch:%.2f",IMU_Pitch);
//		OLED_Write(0,2,8,"Yaw:%.2f",IMU_Yaw);
//		
//		OLED_Write(0,4,8,"Gyrox:%d",IMU_Gyrox);
//		OLED_Write(0,5,8,"Gyroy:%d",IMU_Gyroy);
//		OLED_Write(0,6,8,"Gyroz:%d",IMU_Gyroz);
		
	}
}

