#ifndef _USART_K210_H
#define _USART_K210_H

#include "system.h"  

/****************************�궨��*****************************/ 
#define K210_DATA_SIZE  6

extern u8 K210Data;


/****************************��������***************************/ 
void K210_Init(void);

#endif

