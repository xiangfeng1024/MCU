#ifndef _ENCODER_H
#define _ENCODER_H

#include "system.h"

extern int distance_count,speed_left,speed_right;

void Encoder_Init(void);
void Encoder_TIM4_Init(void);
void Encoder_TIM3_Init(void);
int Encoder_Read(int TIMx);
void TIM6_Init(u16 psc,u16 arr);



#endif


