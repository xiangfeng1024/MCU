#ifndef _MOTOR_H
#define _MOTOR_H

#include "system.h"

#define MOTOR_Line        1           //Ѳ��ģʽ
#define MOTOR_TURN        2           //��תģʽ

#define SERVOS_X        1           	//X����
#define SERVOS_Y        2           	//Y����

#define zuo_lun1        PBout(9)      //����1IO
#define zuo_lun2        PBout(8)      //����2IO
#define you_lun1        PBout(5)      //����1IO
#define you_lun2        PBout(4)      //����2IO

void Motor_GPIO_Init(void);
void PWM_Init_TIM1(uint16_t Psc,uint16_t arr);
void PWM_Init_TIM8(uint16_t Psc,uint16_t arr);
void Motor_Init(void);
u16 Fabs(int p);
void Limit(int *PWMA,int *PWMB);
void Motor_Write(int PWMA,int PWMB);
void Motor_Open(int Mode,int distance_hope,int dir);
void Servos_Write(u8 ID, u16 Out);
void Servos_Init(void);

#endif


