#ifndef _USART_K210_H
#define _USART_K210_H

#include "system.h"  

/****************************�궨��*****************************/ 
#define K210_DATA_SIZE  6


/****************************��������***************************/ 
void K210_Init(void);

#endif

