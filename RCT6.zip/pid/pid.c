#include "pid.h"

struct PID Pitch_Ang,Roll_Ang,Gyrox,Gyroy;

//λ��ʽPID����
void PID_Init(void)
{
	Pitch_Ang.kp = -10;
	Pitch_Ang.kd = -1000;
	Pitch_Ang.ki = 0;
	
	Gyroy.kp=-250;
	
	Roll_Ang.kp = 10;
	Roll_Ang.kd = 1000;
	Roll_Ang.ki = 0;
	
	Gyrox.kp=250;
	

}

//λ��ʽPID
float Erect_pid(struct PID* para,float hope, float now)
{
	(*para).err = now - hope;
	
	(*para).err_last_dev = (*para).err - (*para).err_last;
	
	(*para).out = (*para).kp*(*para).err + (*para).kd*(*para).err_last_dev + (*para).ki*(*para).err_add;
	
	(*para).err_last =  (*para).err;
	
	(*para).err_add+=(*para).err;
	
	return (*para).out;
}


