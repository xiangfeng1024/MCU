#ifndef _PID_H
#define _PID_H

#include "system.h"

extern struct PID Pitch_Ang,Roll_Ang,Gyrox,Gyroy;

struct PID
{
	float kp;
	float ki;
	float kd;
	
	float err;
	float err_last;
	float err_last_dev;
	float err_last_dev_last;
	float err_last_dev_lastdev;
	float err_add;
	
	float ki_p;
	
	float out;
};

float Erect_pid(struct PID* para,float hope, float now);
float V_pid(struct PID* para,int err, int err_v);
void PID_Init(void);

#endif


