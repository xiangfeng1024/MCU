#ifndef __USART_OPENMV_h
#define __USART_OPENMV_h

#include "system.h"

#define 	Openmv_DATA_SIZE  5

void Openmv_Init(void);

#endif
