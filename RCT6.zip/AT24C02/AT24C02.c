#include "AT24C02.h"

void AT24C02_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(AT24_IIC_SCL_PORT_RCC|AT24_IIC_SDA_PORT_RCC, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = AT24_IIC_SCL_PIN;	 
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(AT24_IIC_SCL_PORT, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = AT24_IIC_SDA_PIN;	 
 	GPIO_Init(AT24_IIC_SDA_PORT, &GPIO_InitStructure);
	AT24_SDA=1;
	AT24_SCL=1;
}

void IIC_AT24_Start(void)
{
	AT24_SDAoutMode;
	AT24_SDA=1;
	AT24_SCL=1;
	delay_us(4);
	AT24_SDA=0;
	delay_us(4);
	AT24_SCL=0;
}

void IIC_AT24_Stop(void)
{
	AT24_SDAoutMode;
	AT24_SCL=0;
	AT24_SDA=0;
	delay_us(4);
	AT24_SCL=1;
	AT24_SDA=1;
	delay_us(4);
}

unsigned char AT24_IIC_Wait_Ack(void)
{
	unsigned char ucErrTime=0;
	AT24_SDAinMode;      //SDA����Ϊ����  
	AT24_SDA=1;delay_us(1);	   
	AT24_SCL=1;delay_us(1);	 
	while(AT24_SDAin)
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			IIC_AT24_Stop();
			return 1;
		}
	}
	AT24_SCL=0;//ʱ�����0 	   
	return 0;  
}

void IIC_AT24_Ack(void)
{
	AT24_SCL=0;
	AT24_SDAoutMode;
	AT24_SDA=0;
	delay_us(2);
	AT24_SCL=1;
	delay_us(2);
	AT24_SCL=0;
}

void IIC_AT24_NAck(void)
{
	AT24_SCL=0;
	AT24_SDAoutMode;
	AT24_SDA=1;
	delay_us(2);
	AT24_SCL=1;
	delay_us(2);
	AT24_SCL=0;
}

void IIC_AT24_XIE(unsigned char IIC_Byte)
{
	unsigned char i;
	AT24_SDAoutMode;
	AT24_SCL=0;
	for(i=0;i<8;i++)		
	{
    AT24_SDA=(IIC_Byte&0x80)>>7;
    IIC_Byte<<=1; 	 
		delay_us(2);
		AT24_SCL=1;
		delay_us(2);
		AT24_SCL=0;
		delay_us(2);
	}
}

unsigned char IIC_AT24_Read(unsigned char ack)
{
	unsigned char i,receive=0;
	AT24_SDAinMode;//SDA����Ϊ����
  for(i=0;i<8;i++ )
	{
    AT24_SCL=0; 
    delay_us(2);
		AT24_SCL=1;
    receive<<=1;
    if(AT24_SDAin)receive++;   
		delay_us(1); 
	}
	if (!ack)
			IIC_AT24_NAck();//����nACK
	else
			IIC_AT24_Ack(); //����ACK   
	return receive;
}

void IIC_AT24_XIE_DATA(u16 WriteAddr,u8 DataToWrite)
{				   	  	    																 
  IIC_AT24_Start();  
	IIC_AT24_XIE(0XA0+((WriteAddr/256)<<1));   //����������ַ0XA0,д���� 
	AT24_IIC_Wait_Ack();	   
  IIC_AT24_XIE(WriteAddr%256);   //���͵͵�ַ
	AT24_IIC_Wait_Ack(); 	 										  		   
	IIC_AT24_XIE(DataToWrite);     //�����ֽ�							   
	AT24_IIC_Wait_Ack();  		    	   
  IIC_AT24_Stop();//����һ��ֹͣ���� 
	delay_ms(10);	 
}


unsigned char IIC_AT24_Read_DATA(u16 ReadAddr)
{				  
	u8 temp=0; 	    																 
  IIC_AT24_Start();  	 
	IIC_AT24_XIE(0XA0+((ReadAddr/256)<<1));   //����������ַ0XA0,д���� 	 
	AT24_IIC_Wait_Ack(); 
  IIC_AT24_XIE(ReadAddr%256);   //���͵͵�ַ
	AT24_IIC_Wait_Ack();	    
	IIC_AT24_Start();  	 	   
	IIC_AT24_XIE(0XA1);           //�������ģʽ			   
	AT24_IIC_Wait_Ack();	 
  temp=IIC_AT24_Read(0);		   
  IIC_AT24_Stop();//����һ��ֹͣ����	    
	return temp;
}

void Read_Pid(void)
{
	uint8_t AT_KPH,AT_KPL,AT_KDH,AT_KDL,AT_KIH,AT_KIL,p1,p2,p3;
	int32_t p,i,d;
	p1 = IIC_AT24_Read_DATA(0x00);
	delay_ms(50);
	AT_KPH = IIC_AT24_Read_DATA(0x01);
	delay_ms(50);
	AT_KPL = IIC_AT24_Read_DATA(0x02);
	delay_ms(50);
	p2 = IIC_AT24_Read_DATA(0x03);
	delay_ms(50);
	AT_KDH = IIC_AT24_Read_DATA(0x04);
	delay_ms(50);
	AT_KDL = IIC_AT24_Read_DATA(0x05);
	delay_ms(50);
	p3 = IIC_AT24_Read_DATA(0x06);
	delay_ms(50);
	AT_KIH = IIC_AT24_Read_DATA(0x07);
	delay_ms(50);
	AT_KIL = IIC_AT24_Read_DATA(0x08);
	
	p = AT_KPL+AT_KPH*256;
	d = AT_KDL+AT_KDH*256;
	i = AT_KIL+AT_KIH*256;
	
	if(p1==0) p*=-1;
	if(p2==0) d*=-1;
	if(p3==0) i*=-1;
	
//	Ang_L.kp = p;
//	Ang_L.kd = d;
//	Ang_L.ki = i;
//	
//	Ang_R.kp = p;
//	Ang_R.kd = d;
//	Ang_R.ki = i;
	
	OLED_Write(0,0,16,"KP: %d",p);
	OLED_Write(0,2,16,"KD: %d",d);
	OLED_Write(0,4,16,"KI: %d",i);
	
	Pick_Pid();
}

void Wirte_Pid(int32_t Kp, int32_t Kd, int32_t Ki)
{
	uint8_t AT_KPH,AT_KPL,AT_KDH,AT_KDL,AT_KIH,AT_KIL,p1,p2,p3;
	
	if(Kp>0) p1=1;
	else 		 p1=0;
	
	if(Kd>0) p2=1;
	else 		 p2=0;
	
	if(Ki>0) p3=1;
	else 		 p3=0;
	
	Kp=Fabs(Kp);
	Kd=Fabs(Kd);
	Ki=Fabs(Ki);
	
	AT_KPH = (uint8_t)(Kp/256);
	AT_KPL = (uint8_t)(Kp%256);
	AT_KDH = (uint8_t)(Kd/256);
	AT_KDL = (uint8_t)(Kd%256);
	AT_KIH = (uint8_t)(Ki/256);
	AT_KIL = (uint8_t)(Ki%256);
	
	IIC_AT24_XIE_DATA(0x00,p1);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x01,AT_KPH);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x02,AT_KPL);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x03,p2);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x04,AT_KDH);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x05,AT_KDL);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x06,p3);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x07,AT_KIH);
	delay_ms(50);
	IIC_AT24_XIE_DATA(0x08,AT_KIL);
	delay_ms(50);
}

int Pick_EN=0;

void Pick_Pid(void)
{
	if(Pick_EN==1)
	{
		//����KP
		OLED_Write(100,0,16,"<--");
//		while(KEY3)
//		{
//			if(KEY1==0)
//			{
//				Ang_L.kp+=1;
//				OLED_Write(0,0,16,"KP: %d",(int32_t)Ang_L.kp);
//			}
//			if(KEY2==0)
//			{
//				Ang_L.kp-=1;
//				OLED_Write(0,0,16,"KP: %d",(int32_t)Ang_L.kp);
//			}
//			delay_ms(100);
//		}
//		
//		while(!KEY3);
//		delay_ms(100);
//		//����KD
//		OLED_Write(100,0,16,"   ");
//		OLED_Write(100,2,16,"<--");
//		while(KEY3)
//		{
//			if(KEY1==0)
//			{
//				Ang_L.kd+=1;
//				OLED_Write(0,2,16,"KD: %d",(int32_t)Ang_L.kd);
//			}
//			if(KEY2==0)
//			{
//				Ang_L.kd-=1;
//				OLED_Write(0,2,16,"KD: %d",(int32_t)Ang_L.kd);
//			}
//			delay_ms(100);
//		}
//		
//		while(!KEY3);
//		delay_ms(100);
//		//����KI
//		OLED_Write(100,2,16,"   ");
//		OLED_Write(100,4,16,"<--");
//		while(KEY3)
//		{
//			if(KEY1==0)
//			{
//				Ang_L.ki+=1;
//				OLED_Write(0,4,16,"KI: %d",(int32_t)Ang_L.ki);
//			}
//			if(KEY2==0)
//			{
//				Ang_L.ki-=1;
//				OLED_Write(0,4,16,"KI: %d",(int32_t)Ang_L.ki);
//			}
//			delay_ms(100);
//		}
		
//		Wirte_Pid((int32_t)Ang_L.kp,(int32_t)Ang_L.kd,(int32_t)Ang_L.ki);
		OLED_Clear();
		OLED_Write(0,3,16,"PID_Load_OK!");
		delay_ms(500);
		delay_ms(500);
		delay_ms(500);
		OLED_Clear();
	}
}
