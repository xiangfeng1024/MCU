#ifndef _AT24C02_H
#define _AT24C02_H

#include "system.h"

#define  AT24_SDAinMode   {GPIOB->CRH &= 0xfff0ffff;GPIOB->CRH |= 8<<16;}
#define  AT24_SDAoutMode  {GPIOB->CRH &= 0xfff0ffff;GPIOB->CRH |= 3<<16;}

/*  IIC_SCLʱ�Ӷ˿ڡ����Ŷ��� */
#define AT24_IIC_SCL_PORT_RCC	  RCC_APB2Periph_GPIOB
#define AT24_IIC_SCL_PORT 		  GPIOB
#define AT24_IIC_SCL_PIN 			  GPIO_Pin_13

/*  IIC_SDAʱ�Ӷ˿ڡ����Ŷ��� */
#define AT24_IIC_SDA_PORT_RCC		RCC_APB2Periph_GPIOB
#define AT24_IIC_SDA_PORT 			GPIOB  
#define AT24_IIC_SDA_PIN 				GPIO_Pin_12

#define  AT24_SCL  	 PBout(13)
#define  AT24_SDA  	 PBout(12)
#define  AT24_SDAin  PBin(12)

extern int Pick_EN;

void AT24C02_Init(void);
void IIC_AT24_Start(void);
void IIC_AT24_Stop(void);
unsigned char AT24_IIC_Wait_Ack(void);
void IIC_AT24_Ack(void);
void IIC_AT24_NAck(void);
unsigned char IIC_AT24_Read(unsigned char ack);
void IIC_AT24_XIE_DATA(u16 WriteAddr,u8 DataToWrite);
unsigned char IIC_AT24_Read_DATA(u16 ReadAddr);

void Read_Pid(void);
void Wirte_Pid(int32_t Kp, int32_t Kd, int32_t Ki);
void Pick_Pid(void);

#endif

