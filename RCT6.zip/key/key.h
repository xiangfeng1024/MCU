#ifndef _KEY_H
#define _KEY_H

#include "system.h"

#define KEY1      PBin(2) 
#define KEY2      PBin(0) 
#define KEY3      PAin(0)

void KEY_GPIO_Init(void);
void EXTIX_Init(void);

#endif


