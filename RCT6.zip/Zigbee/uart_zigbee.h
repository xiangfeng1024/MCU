#ifndef _UART_ZIGBEE_H
#define _UART_ZIGBEE_H

#include "system.h"

#define   ZIGBEE_DATA_SIZE 11


extern float Debug_zigbee_data[10];
extern int zigbee_data;

void USART1_Init(uint32_t a);
void zigbee_debug_Init(void);
void VOFA_Write(int n,float* a);
void Zigbee_Write(int n);

#endif


